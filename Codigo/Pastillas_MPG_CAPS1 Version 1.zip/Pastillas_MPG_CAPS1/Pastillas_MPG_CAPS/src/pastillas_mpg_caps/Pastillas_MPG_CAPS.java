
package pastillas_mpg_caps;
import Vista.Vista_Login;

public class Pastillas_MPG_CAPS {

    
    public static void main(String[] args) {
        
        Vista_Login login = new Vista_Login();
        login.setVisible(true);
    }
    
}
