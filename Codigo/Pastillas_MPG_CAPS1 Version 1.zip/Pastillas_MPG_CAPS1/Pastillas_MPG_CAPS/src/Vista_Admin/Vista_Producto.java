package Vista_Admin;

import Controlador_Admin.ControladorProducto;
import GUI.Filtro_Letras;
import GUI.Filtro_Numeros;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.text.AbstractDocument;
import javax.swing.JButton;


/**
 *
 * @author User
 */
public class Vista_Producto extends javax.swing.JFrame implements Interfaz_Producto{

    
    public Vista_Producto() {
        initComponents();
        new ControladorProducto(this);
        botonesPersonalizados();
((AbstractDocument) cajaPrecioProducto.getDocument()).setDocumentFilter(new Filtro_Letras());
((AbstractDocument) cajaStockProducto.getDocument()).setDocumentFilter(new Filtro_Letras());
((AbstractDocument) cajaNombreProducto.getDocument()).setDocumentFilter(new Filtro_Numeros());
        
        
    }
    
    @Override
    public String getNombreProducto(){
        return cajaNombreProducto.getText();
    }
    
   
    
    @Override
    public String getCantidadProducto(){
        return cajaStockProducto.getText();
    }
    
    @Override
    public String getPrecioProducto(){
        return cajaPrecioProducto.getText();
    }
    
    
    @Override
    public JTextField getNumeroSerieBuscado(){
        return cajaNumeroSerieBuscado;
    }
    
    @Override
    public String getNumeroSerie(){
        return cajaNumeroSerieBuscado.getText();
    }
    
    
    @Override
    public void getLimpiarProducto(){
        cajaNumeroSerieBuscado.setText("");
        cajaPrecioProducto.setText("");
        cajaNombreProducto.setText("");
        cajaStockProducto.setText("");
        
        
    }
    
    @Override
   public void getMensaje(String mensaje){
       JOptionPane.showMessageDialog(this, mensaje);
   }
    
    @Override
   public int getMensajeConfirmacion(String m){
       return JOptionPane.showConfirmDialog(this, m, "Elija", JOptionPane.YES_NO_OPTION);
   }
   
    @Override
    public JTable getTablaProducto(){
        return TablaProducto;
    }
    
    
    @Override
    public JButton getGuardarProducto(){
        return boton_GuardarProducto; 
    }
    
   
    
    @Override
    public JButton getEditarProducto(){
        return boton_EditarProducto;
    }
    
    @Override
    public JButton getEliminarProducto(){
       return boton_EliminarProducto;
    }
    
    @Override
   public JButton getRegresarProducto(){
       return boton_Regresar;
   }
    
    public void botonesPersonalizados(){
    /*configurarBotones(boton_Buscar, 
        new Color(52,152,219), 
        new Color(41,128,185));*/
        
        configurarBotones(boton_EditarProducto, 
        new Color(46,204,113), 
        new Color(39,174,96));
        
        configurarBotones(boton_EliminarProducto, 
        new Color(231,76,60), 
        new Color(192,57,43));
        
        configurarBotones(boton_GuardarProducto, 
        new Color(215,126,10), 
        new Color(12,127,203));
        
    }
    
    private void configurarBotones(JButton boton, Color normal, Color especial){
        
        boton.setFocusPainted(false);
        boton.setBorderPainted(false);
        boton.setContentAreaFilled(false);
        boton.setOpaque(true);
        boton.setBackground(especial);
        boton.setForeground(Color.WHITE);
        
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        boton.addMouseListener(new MouseAdapter(){
        
            @Override
            public void mouseEntered(MouseEvent e){
                boton.setBackground(especial);
            }
        
            @Override
            public void mouseExited(MouseEvent e){
                boton.setBackground(normal);
            }
        
        });
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaProducto = new javax.swing.JTable();
        boton_EliminarProducto = new javax.swing.JButton();
        boton_EditarProducto = new javax.swing.JButton();
        cajaNumeroSerieBuscado = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        boton_GuardarProducto = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        cajaPrecioProducto = new javax.swing.JTextField();
        cajaStockProducto = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        cajaNombreProducto = new javax.swing.JTextField();
        boton_Regresar = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(242, 245, 252));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Lista Productos"));

        TablaProducto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "N-SERIE", "NOMBRE", "CANTIDAD", "PRECIO UNITARIO"
            }
        ));
        TablaProducto.setGridColor(new java.awt.Color(255, 255, 255));
        jScrollPane1.setViewportView(TablaProducto);

        boton_EliminarProducto.setBackground(new java.awt.Color(239, 68, 68));
        boton_EliminarProducto.setForeground(new java.awt.Color(255, 255, 255));
        boton_EliminarProducto.setText("Eliminar");

        boton_EditarProducto.setText("Editar");

        jLabel5.setText("Buscar por N° Serie");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 18, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(boton_EditarProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(boton_EliminarProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(17, 17, 17))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cajaNumeroSerieBuscado, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(161, 161, 161))))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cajaNumeroSerieBuscado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(boton_EliminarProducto)
                    .addComponent(boton_EditarProducto))
                .addContainerGap())
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 70, 550, 320));

        jPanel3.setBackground(new java.awt.Color(242, 245, 252));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Registro Productos"));

        boton_GuardarProducto.setText("Guardar");

        jLabel4.setText("Ingrese el precio:");

        cajaPrecioProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cajaPrecioProductoActionPerformed(evt);
            }
        });

        cajaStockProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cajaStockProductoActionPerformed(evt);
            }
        });

        jLabel3.setText("Ingrese el Stock:");

        jLabel1.setText("Nombre del Producto:");

        boton_Regresar.setBackground(new java.awt.Color(100, 116, 139));
        boton_Regresar.setForeground(new java.awt.Color(255, 255, 255));
        boton_Regresar.setText("Regresar");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(74, 74, 74)
                        .addComponent(cajaStockProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(62, 62, 62)
                        .addComponent(cajaNombreProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4)
                            .addComponent(boton_Regresar, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(74, 74, 74)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cajaPrecioProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addComponent(boton_GuardarProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)))))
                .addContainerGap(62, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(68, 68, 68)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(cajaNombreProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cajaStockProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cajaPrecioProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(boton_Regresar)
                    .addComponent(boton_GuardarProducto))
                .addGap(35, 35, 35))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 450, 300));

        jPanel4.setBackground(new java.awt.Color(214, 91, 14));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 22)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Administrar Productos");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(418, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(330, 330, 330))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel2)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1020, 60));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1023, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 392, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cajaPrecioProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cajaPrecioProductoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cajaPrecioProductoActionPerformed

    private void cajaStockProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cajaStockProductoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cajaStockProductoActionPerformed

  
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaProducto;
    private javax.swing.JButton boton_EditarProducto;
    private javax.swing.JButton boton_EliminarProducto;
    private javax.swing.JButton boton_GuardarProducto;
    private javax.swing.JButton boton_Regresar;
    private javax.swing.JTextField cajaNombreProducto;
    private javax.swing.JTextField cajaNumeroSerieBuscado;
    private javax.swing.JTextField cajaPrecioProducto;
    private javax.swing.JTextField cajaStockProducto;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
