package Controlador_Admin;

import Vista_Admin.Vista_Admin;
import Vista_Admin.Vista_Producto;

/**
 *
 * @author SEBAS
 */
public class Controlador_Admin {
    Vista_Admin admin;
    public Controlador_Admin(Vista_Admin admin){
        this.admin = admin;
        //Aqui se aniade un actionlistener al boton utilizando funciones lamda
        this.admin.btn_gestionarProductos().addActionListener(e -> gestionProductos());
        
    }
    
    public void gestionProductos() {

        Vista_Producto producto = new Vista_Producto();

        producto.setVisible(true);

        admin.dispose(); // cierra la ventana actual
    }
    
}
