package Controlador_Admin;

import Modelo.Producto;
import Modelo.Repositorio_Producto;
import Vista_Admin.Vista_Admin;
import Vista_Admin.Vista_Producto;
import GUI.Eventos_Tabla;
import javax.swing.table.DefaultTableModel;

public class ControladorProducto {

    private Vista_Producto vista;
    private Repositorio_Producto repositorio_producto = new Repositorio_Producto();
    private DefaultTableModel modelo;
    private Eventos_Tabla filtro_tabla = new Eventos_Tabla();

    public ControladorProducto(Vista_Producto vista) {

        this.vista = vista;

        this.modelo = new DefaultTableModel(
                new Object[][]{},
                new String[]{"N-SERIE", "NOMBRE", "CANTIDAD", "PRECIO UNITARIO"}) {

            @Override
            public boolean isCellEditable(int fila, int columna) {
                return columna != 0;
            }
        };

        vista.getTablaProducto().setModel(modelo);

        filtro_tabla.ordenar_filtar(
                modelo,
                vista.getTablaProducto(),
                vista.getNumeroSerieBuscado(),
                0
        );

        vista.getGuardarProducto().addActionListener(e -> guardar());
        vista.getEditarProducto().addActionListener(e -> editar());
        vista.getEliminarProducto().addActionListener(e -> eliminar());
        vista.getRegresarProducto().addActionListener(e -> regresar());

        repositorio_producto.cargarTabla(modelo);
    }

//guardado1 no pares bola
private void guardar() {

    try {

        String nombre = vista.getNombreProducto().trim();

        if (nombre.isEmpty()
                || vista.getCantidadProducto().isEmpty()
                || vista.getPrecioProducto().isEmpty()) {

            vista.getMensaje("Ingrese todos los datos");
            return;
        }

        int cantidad = Integer.parseInt(vista.getCantidadProducto());
        double precio = Double.parseDouble(vista.getPrecioProducto());

        if (cantidad <= 0 || precio <= 0) {
            vista.getMensaje("Cantidad o precio inválido");
            return;
        }

        // 🔍 Buscar por NOMBRE (sin importar precio)
        Producto existente = repositorio_producto.buscarPorNombre(nombre);

        if (existente != null) {
            // ✅ Ya existe un producto con el mismo nombre
            
            if (existente.getPrecioUnitario() == precio) {
                // Caso 1: Mismo nombre + mismo precio → aumentar cantidad
                int respuesta = javax.swing.JOptionPane.showConfirmDialog(
                    vista,
                    "El producto '" + nombre + "' ya existe con el mismo precio.\n" +
                    "Serie: " + existente.getNumeroSerie() + "\n" +
                    "Cantidad actual: " + existente.getCantidad() + "\n\n" +
                    "¿Deseas aumentar la cantidad en " + cantidad + " unidades?",
                    "Aumentar cantidad",
                    javax.swing.JOptionPane.YES_NO_OPTION
                );

                if (respuesta == javax.swing.JOptionPane.YES_OPTION) {
                    int nuevaCantidad = existente.getCantidad() + cantidad;
                    repositorio_producto.actualizarStock(existente.getNumeroSerie(), nuevaCantidad);
                    repositorio_producto.cargarTabla(modelo);
                    vista.getLimpiarProducto();
                    vista.getMensaje("✅ Cantidad actualizada. Nuevo stock: " + nuevaCantidad);
                }
                return;
                
            } else {
                // Caso 2: Mismo nombre + precio DIFERENTE → preguntar qué hacer
                String[] opciones = {"Actualizar precio", "Crear nuevo producto", "Cancelar"};
                int respuesta = javax.swing.JOptionPane.showOptionDialog(
                    vista,
                    "El producto '" + nombre + "' ya existe con un precio diferente.\n\n" +
                    "Precio actual: $" + existente.getPrecioUnitario() + "\n" +
                    "Nuevo precio: $" + precio + "\n" +
                    "Cantidad a agregar: " + cantidad + "\n\n" +
                    "¿Qué deseas hacer?",
                    "Precio diferente detectado",
                    javax.swing.JOptionPane.YES_NO_CANCEL_OPTION,
                    javax.swing.JOptionPane.QUESTION_MESSAGE,
                    null,
                    opciones,
                    opciones[0]
                );

                if (respuesta == 0) {
                    // Opción 1: Actualizar precio del producto existente y aumentar cantidad
                    int nuevaCantidad = existente.getCantidad() + cantidad;
                    existente.setPrecioUnitario(precio);
                    existente.setCantidad(nuevaCantidad);
                    repositorio_producto.editarProducto(existente, existente.getNumeroSerie());
                    repositorio_producto.cargarTabla(modelo);
                    vista.getLimpiarProducto();
                    vista.getMensaje("Precio actualizado y cantidad aumentada. Nuevo stock: " + nuevaCantidad);
                    
                } else if (respuesta == 1) {
                    // Opción 2: Crear nuevo producto (con el nuevo precio)
                    String numeroSerie = repositorio_producto.generarCodigoProducto();
                    Producto nuevo = new Producto(numeroSerie, nombre, cantidad, precio);
                    repositorio_producto.agregarDocumento(nuevo);
                    repositorio_producto.actualizarCodigoProducto();
                    repositorio_producto.cargarTabla(modelo);
                    vista.getLimpiarProducto();
                    vista.getMensaje("Nuevo producto creado con serie: " + numeroSerie + " (precio $" + precio + ")");
                }
                return;
            }
        }

        // ❌ No existe ningún producto con ese nombre → crear nuevo
        String numeroSerie = repositorio_producto.generarCodigoProducto();

        Producto producto = new Producto(
            numeroSerie,
            nombre,
            cantidad,
            precio
        );

        repositorio_producto.agregarDocumento(producto);
        repositorio_producto.actualizarCodigoProducto();
        repositorio_producto.cargarTabla(modelo);

        vista.getLimpiarProducto();
        vista.getMensaje("Nuevo producto guardado con serie: " + numeroSerie);

    } catch (Exception e) {
        vista.getMensaje("Ingrese datos válidos");
        e.printStackTrace();
    }
}

private void editar() {

    try {

        int fila = vista.getTablaProducto().getSelectedRow();

        if (fila == -1) {
            vista.getMensaje("Seleccione una fila");
            return;
        }

        int filaModelo = vista.getTablaProducto()
                .convertRowIndexToModel(fila);

        String numeroSerieOriginal = modelo.getValueAt(filaModelo, 0).toString();

        String nombreNuevo = vista.getNombreProducto().trim();
        int cantidadNueva = Integer.parseInt(vista.getCantidadProducto());
        double precioNuevo = Double.parseDouble(vista.getPrecioProducto());

        if (nombreNuevo.isEmpty()) {
            vista.getMensaje("Ingrese un nombre válido");
            return;
        }

        if (cantidadNueva <= 0 || precioNuevo <= 0) {
            vista.getMensaje("Cantidad o precio inválido");
            return;
        }

        // ========== VALIDACIÓN: Buscar si existe OTRO producto con el mismo nombre+precio ==========
        Producto existente = repositorio_producto.buscarPorNombreYPrecio(nombreNuevo, precioNuevo);

        // Si existe y NO es el mismo producto que estamos editando → bloquear
        if (existente != null && !existente.getNumeroSerie().equals(numeroSerieOriginal)) {
            vista.getMensaje("No se puede editar. Ya existe otro producto con el nombre '" 
                           + nombreNuevo + "' y precio $" + precioNuevo + "\n"
                           + "Número de serie del producto existente: " + existente.getNumeroSerie());
            return; // ❌ Bloquea la edición
        }

        // ✅ Si pasa la validación → editar normalmente
        Producto productoEditado = new Producto(numeroSerieOriginal, nombreNuevo, cantidadNueva, precioNuevo);
        repositorio_producto.editarProducto(productoEditado, numeroSerieOriginal);
        repositorio_producto.cargarTabla(modelo);
        vista.getLimpiarProducto();
        vista.getMensaje("Producto editado correctamente");

    } catch (NumberFormatException e) {
        vista.getMensaje("Ingrese valores numéricos válidos");
    } catch (Exception e) {
        vista.getMensaje("No se pudo editar: " + e.getMessage());
        e.printStackTrace();
    }
}

    private void eliminar() {

        int fila = vista.getTablaProducto().getSelectedRow();

        if (fila == -1) {
            vista.getMensaje("Seleccione una fila");
            return;
        }

        int filaModelo = vista.getTablaProducto()
                .convertRowIndexToModel(fila);

        String numeroSerie = modelo
                .getValueAt(filaModelo, 0)
                .toString();

        repositorio_producto.eliminarProducto(numeroSerie);

        repositorio_producto.cargarTabla(modelo);

        vista.getMensaje("Producto eliminado");
    }

    private void regresar() {

        Vista_Admin admin = new Vista_Admin();

        admin.setVisible(true);

        vista.dispose();
    }
}