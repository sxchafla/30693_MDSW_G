/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vista_Cliente;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import Controlador_Cliente.Controlador_RegistroCliente;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 *
 * @author javie
 */
public class Registrar_Cliente extends javax.swing.JFrame implements Interfaz_Registrar_Cliente {

    /**
     * Creates new form Registrar_Cliente
     */
    public Registrar_Cliente() {
        initComponents();
        new Controlador_RegistroCliente(this);
        configurarBotones(boton_Registrar, new Color(214,91,14), new Color(214,80,10));
        configurarBotones(boton_Regresar, new Color(214,91,14), new Color(214,80,10));
    }

      @Override
    public String getNombre(){
        return cajaNombre.getText();
    }

    @Override
    public String getCedula(){
        return cajaCedula.getText();
    }

    @Override
    public String getApellido(){
        return cajaApellido.getText();
    }

    @Override
    public String getNumeroTelefonico(){
        return cajaNumero.getText();
    }
    
    
    @Override
    public String getCorreo(){
        return cajaCorreo.getText();
    }
    
    
    @Override
    public String getDireccion(){
        return cajaDireccion.getText();
    }
    
    @Override
  public String getContrasenia(){
      return cajaContrasenia.getText();
  }
    
    @Override
    public void getLimpiar(){
        cajaApellido.setText("");
        cajaCedula.setText("");
        cajaCorreo.setText("");
        cajaDireccion.setText("");
        cajaNombre.setText("");
        cajaNumero.setText("");
        
    }
    
    @Override
    public JButton getRegistrar(){
        return boton_Registrar;
    }
    
  
    
  
    
    
    @Override
    public JButton getRegresar(){
        return boton_Regresar;
    }
    
    @Override
    public void getMensaje(String mensaje){
        JOptionPane.showMessageDialog(this, mensaje);
        
    }
    
    
    
   @Override
    public int getMensajeOpcion(String n){
        Object[] String={
            "Elejir Cliente","Editar"
        };
        return JOptionPane.showOptionDialog(this, "Elija una opcion", n, 0, 0, null, String, 0);
    }
    
    private void configurarBotones(JButton boton, Color normal, Color especial) {

        //Quita el borde cuando le haces click
        boton.setFocusPainted(false);
        //Eliminar el brode 3d
        boton.setBorderPainted(false);
        //Quita el relieve interno
        boton.setContentAreaFilled(false);
        //Permite pintar el fondo
        boton.setOpaque(true);
        //Pinta el fondo
        boton.setBackground(especial);
        //Pinta el texto
        boton.setForeground(Color.WHITE);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(especial);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                boton.setBackground(normal);
            }
        });
      }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        cajaNombre = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        cajaApellido = new javax.swing.JTextField();
        cajaNumero = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        cajaCedula = new javax.swing.JTextField();
        cajaDireccion = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cajaCorreo = new javax.swing.JTextField();
        boton_Registrar = new javax.swing.JButton();
        boton_Regresar = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        cajaContrasenia = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(249, 251, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel2.add(cajaNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 130, 170, -1));

        jLabel6.setText("Nombre:");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 110, 60, -1));

        jLabel1.setText("Apellido:");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 110, 60, -1));
        jPanel2.add(cajaApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 130, 170, -1));

        cajaNumero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cajaNumeroActionPerformed(evt);
            }
        });
        jPanel2.add(cajaNumero, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, 170, -1));

        jLabel4.setText("Numero Telefonico:");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 180, 120, -1));

        jLabel2.setText("Cedula");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 250, 40, -1));
        jPanel2.add(cajaCedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 270, 170, -1));
        jPanel2.add(cajaDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 200, 170, -1));

        jLabel5.setText("Direccion:");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 180, 70, -1));

        jLabel3.setText("Correo Electronico");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 250, 110, -1));
        jPanel2.add(cajaCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 270, 170, -1));

        boton_Registrar.setText("Registrar");
        jPanel2.add(boton_Registrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 390, -1, -1));

        boton_Regresar.setText("Regresar");
        jPanel2.add(boton_Regresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 390, -1, -1));

        jPanel1.setBackground(new java.awt.Color(214, 91, 14));

        jLabel8.setFont(new java.awt.Font("Mongolian Baiti", 3, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Regístrate");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(253, Short.MAX_VALUE)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(247, 247, 247))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(24, Short.MAX_VALUE)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16))
        );

        jPanel2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 580, 70));

        jLabel7.setText("Contraseña:");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 340, -1, -1));
        jPanel2.add(cajaContrasenia, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 340, 170, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 580, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 453, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cajaNumeroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cajaNumeroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cajaNumeroActionPerformed



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton boton_Registrar;
    private javax.swing.JButton boton_Regresar;
    private javax.swing.JTextField cajaApellido;
    private javax.swing.JTextField cajaCedula;
    private javax.swing.JTextField cajaContrasenia;
    private javax.swing.JTextField cajaCorreo;
    private javax.swing.JTextField cajaDireccion;
    private javax.swing.JTextField cajaNombre;
    private javax.swing.JTextField cajaNumero;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
