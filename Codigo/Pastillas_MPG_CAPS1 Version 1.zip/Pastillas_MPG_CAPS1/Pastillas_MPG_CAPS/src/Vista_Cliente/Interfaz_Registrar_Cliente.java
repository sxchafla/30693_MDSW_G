
package Vista_Cliente;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JTextField;


public interface Interfaz_Registrar_Cliente {
    
     
    String getNombre();
    String getCedula();
    String getApellido();
    String getNumeroTelefonico();
    String getCorreo();
    String getDireccion();
    String getContrasenia();
    void getLimpiar();
    
    JButton getRegistrar();

    JButton getRegresar();
    
    void getMensaje(String mensaje);
    int getMensajeOpcion(String n);

}
