/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador_Cliente;

import Modelo.Clientes;
import Modelo.Datos_Cliente;
import Modelo.Repositorio_Clientes;
import Vista.Vista_Login;
import Vista_Cliente.Registrar_Cliente;
import Vista_Cliente.Vista_Cliente;
import javax.swing.table.DefaultTableModel;

public class Controlador_RegistroCliente{
    
    Registrar_Cliente vista;
    Repositorio_Clientes repositorio_cliente = new Repositorio_Clientes();
    Vista_Login login = new Vista_Login();

    
    public Controlador_RegistroCliente(Registrar_Cliente vista) {
        this.vista = vista;

        
        //el Object[][] son las filas x columas que se imprimen vacias debido a {}
        //el String[]{}Define los encabezados de las colmnas
        // luego se crea una clase anonima, osea es una version personalizada del DEfaulTeble model
        //luego el metodod boolean isCellEditable lo llama la tabla cada vez se se hace click, o se presiona enter etc
        //y el return significa que esa columna estara bloquada
       
       
        //Filtra la tabla
        //filtro_tabla.ordenar_filtar(modelo, vista.getTabla(), vista.getCedulaBuscada(),0);
        //Este es el metodo para que de click y se guarde el objeto
        //obtenerCliente();
        this.vista.getRegistrar().addActionListener(e -> registrar());
        this.vista.getRegresar().addActionListener(e -> regresar());


       
    }

    public void registrar() {
      // try {
            String nombre = vista.getNombre();
            String apellido = vista.getApellido();
            String cedula = vista.getCedula();
            String correo = vista.getCorreo();
            String direccion = vista.getDireccion();
            String codigoCliente = repositorio_cliente.generarCodigoCliente();
            String contrasenia = vista.getContrasenia();
            if (nombre.isEmpty() || apellido.isEmpty() || cedula.isEmpty() || correo.isEmpty() || direccion.isEmpty()) {
                vista.getMensaje("Llene los espacios vacios");
                return;
            }
            if(contrasenia.isEmpty()){
                vista.getMensaje("Ingrese la contraseña por favor");
                return;
            }
            if(!validarCedula(cedula)){
                vista.getMensaje("Ingrese una cedula correcta");
                return;
            }
            if(!validarCorreo(correo)){
                vista.getMensaje("Ingrese un correo valido");
                return;
            }
            String numeroTelefonico = vista.getNumeroTelefonico();

            if(!repositorio_cliente.buscarCliente(cedula)){

                Datos_Cliente  cli = new Datos_Cliente(nombre, apellido, cedula, correo, numeroTelefonico, direccion,codigoCliente,contrasenia);
                repositorio_cliente.agregarCliente(cli);

                vista.getLimpiar();
                repositorio_cliente.actualizarCodigoCliente();
            }else{
                System.out.println(codigoCliente);
                vista.getMensaje("La cedula ya esta ingresada");
                return;
            }
            
            vista.getMensaje("Usuario registrado");
            login.setVisible(true);
            vista.dispose();
            
       // } catch (Exception e) {
          // vista.getMensaje("Error al guardar ingrese numeros en el telefono");
       // }
    }
    
    public boolean validarCedula(String cedula) {
        // 1. Validar longitud básica (debe tener 10 dígitos)
        if (cedula.length() != 10) {
            return false;
        }

        // 2. Validar el código de provincia (primeros dos dígitos entre 01 y 24, o 30)
        int provincia = Integer.parseInt(cedula.substring(0, 2));
        if (!((provincia >= 1 && provincia <= 24) || provincia == 30)) {
            return false;
        }

        // 3. Algoritmo de Módulo 10
        //Esto es para multiplicar los primeros 9 digitos los impares *2 y los pares *1
        int[] coeficientes = {2, 1, 2, 1, 2, 1, 2, 1, 2};
        int suma = 0;

        for (int i = 0; i < coeficientes.length; i++) {
            //esta fila convierte el carácter en la posición i a un número entero real para poder hacer cálculos.
            int digito = Character.getNumericValue(cedula.charAt(i));
            int producto = digito * coeficientes[i];

            // Si el producto es mayor a 9, se le resta 9
            if (producto > 9) {
                producto -= 9;
            }
            suma += producto;
        }
        //Obtenemos el último dígito de la cédula (el que está en la posición 10, índice 9)
        
        int digitoVerificadorRecibido = Character.getNumericValue(cedula.charAt(9));
        int residuo = suma % 10;
        //Si el residuo es 0, el verificador debe ser 0. Si no, restamos el residuo de 10 para obtener el número exacto que debería ser el último dígito.
        int digitoVerificadorCalculado = (residuo == 0) ? 0 : 10 - residuo;

        // 4. Comparación final
        return digitoVerificadorCalculado == digitoVerificadorRecibido;
}
    
    public boolean validarCorreo(String correo){
        String ultimosTres = correo.substring(correo.length() - 4);
        if(!correo.contains("@")){
            return false;
        } else
        
        if(!ultimosTres.equals(".com")){
            return false;
        }
        return true;
    }
    
    public void regresar(){
        login.setVisible(true);
        vista.dispose();
    }
}

