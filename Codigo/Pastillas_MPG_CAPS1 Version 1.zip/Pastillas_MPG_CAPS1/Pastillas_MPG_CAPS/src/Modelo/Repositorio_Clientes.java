
package Modelo;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Updates;
import org.bson.Document;

public class Repositorio_Clientes {

    private static MongoCollection<Document> datos;
    private static MongoCollection<Document> id_clientes;

    public Repositorio_Clientes() {

        MongoDatabase db = Conexion_Mongo.getConectarBase();
        this.datos = db.getCollection("Clientes");
        this.id_clientes = db.getCollection("ID_Clientes");

    }

    private Document agregarDocumento(Datos_Cliente c) {
        return new Document("Cedula", c.getCedula())
                .append("Nombres", c.getNombre())
                .append("Apellidos", c.getApellido())
                .append("Correo electronico", c.getCorreoElectronico())
                .append("Numero telefonico", c.getNumeroTelefonico())
                .append("Direccion", c.getDireccion())
                .append("Contrasenia", c.getContrasenia())
                .append("Codigo cliente", c.getCoodigoCliente());

    }

    public void agregarCliente(Datos_Cliente c) {
        datos.insertOne(agregarDocumento(c));
    }

    
// Este metodo es para poder validar si la cedula del cliente ya esta ingresada
    public boolean buscarCliente(String cedulaBuscada) {
        for (Document d : datos.find()) {
            if(d.getString("Cedula").equalsIgnoreCase(cedulaBuscada)){
                return true;
            }
        }
        return false;
    }

    // metodo para modificar
    public void modificar(String codigo, Datos_Cliente c) {
        try {
            for(Document d: datos.find()){
                if(d.getString("Codigo cliente").equals(codigo)){
                    //buscamos el documento por su cedula 
                    Document filtro = new Document("Codigo cliente", codigo);

                    //Preparamos los cambios usando $set 
                    Document cambios = new Document("$set", new Document()
                        .append("Cedula", c.getCedula())
                        .append("Nombres", c.getNombre())
                        .append("Apellidos", c.getApellido())
                        .append("Correo electronico", c.getCorreoElectronico())
                        .append("Numero telefonico", c.getNumeroTelefonico())
                        .append("Direccion", c.getDireccion())
                    );
            // ctualizamos por la cedula selec
                    datos.updateOne(filtro, cambios);
                    System.out.println("Datos editados");
                return;
                }
            }
           

        } catch (Exception ev) {
            System.out.println("Error no se puede ");
        }
    }

    public void eliminarCliente(String codigo) {
        datos.deleteOne(new Document("Codigo cliente", codigo));
    }
    
    
     
     public String generarCodigoCliente(){

        //Esta linea busca con el .find() y con el .projection(Projections.include()).first solamente extrae un solo documento del vampo valor
        Document d = id_clientes.find(Filters.eq("codigo","cli-")).projection(Projections.include("valor")).first();
        if(d == null){
            crearBaseCliente();
            System.out.println("Coleccion creada");

            return "cli-0000";
        }else{
            //se extrae el valor del campo
            int numeroFactura = d.getInteger("valor");
            // Este formato segun entiendo es que despues de Fact- lo demas se rrellena con 5 ceros pero los ultimos digitos son reeplazados 
            //por lo que tenga guardado numeroFactura
            return String.format("cli-%04d", numeroFactura);
        }
    }
    
     
    public void actualizarCodigoCliente(){
        //Lo que hace esta linea es que busca y actualiza al mismo tiempo
        Document buscar = id_clientes.findOneAndUpdate(
                //Esto seleciona el documento que vamos a actualizar
                Filters.eq("codigo", "cli-")
                //Aque aumenta el valor del campo en la base de datos en +1
                ,Updates.inc("valor", 1));
    }
    
    public void crearBaseCliente(){
        Document nuevo = new Document().append("codigo", "cli-")
                .append("valor", 0);
        id_clientes.insertOne(nuevo);
    }
}
