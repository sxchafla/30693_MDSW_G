
package Modelo;


public class DetalleCompra {
    
}
