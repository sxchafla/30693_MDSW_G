
package Controlador_Admin;
import GUI.Eventos_Tabla;
import Modelo.Repositorio_Reporte_Facturas;
import Vista_Admin.Vista_Historial_de_Reportes;
import javax.swing.table.DefaultTableModel;
import Vista_Admin.Vista_Reporte_Detalle_Admin;
//
public class Controlador_Historial_de_Reportes {
    Repositorio_Reporte_Facturas reporte_factura = new Repositorio_Reporte_Facturas();
    DefaultTableModel modelo;
    Vista_Historial_de_Reportes vista;
    private Eventos_Tabla filtro_tabla = new Eventos_Tabla();

    public Controlador_Historial_de_Reportes(Vista_Historial_de_Reportes vist) {
        this.vista = vist;
        modelo = (DefaultTableModel) vista.tablaDetalle().getModel();
        vista.botonDetalle().addActionListener(e -> verDetalle());
        reporte_factura.leerReportesCompletos(modelo);
        filtro_tabla.ordenar_filtar(modelo, vista.tablaDetalle(), vista.cajaFecha(), 0);
        
    }
    
    public void verDetalle(){
        int fila = vista.tablaDetalle().getSelectedRow();

        if (fila == -1) {
            vista.getMensaje("Seleccione una fila");
            return;
        }
        
        int filaMoledo = vista.tablaDetalle().convertRowIndexToModel(fila);
        String numeroFactura = modelo.getValueAt(filaMoledo, 3).toString().trim();
        
        Vista_Reporte_Detalle_Admin reporte = new Vista_Reporte_Detalle_Admin(numeroFactura);
        reporte.setVisible(true);
    }
    
}
