package Controlador_Admin;

import Vista_Admin.Vista_Admin;
import Vista_Admin.Vista_Producto;
import Vista_Admin.Vista_Cliente;
import Vista_Admin.Vista_Historial_de_Reportes;

/**
 *
 * @author SEBAS
 */
public class Controlador_Admin {
    Vista_Admin admin;
    public Controlador_Admin(Vista_Admin admin){
        this.admin = admin;
        //Aqui se aniade un actionlistener al boton utilizando funciones lamda
        this.admin.btn_gestionarProductos().addActionListener(e -> gestionProductos());
        this.admin.btn_gestionarClientes().addActionListener(e -> gestionClientes());
        this.admin.btn_verReportes().addActionListener(e -> verReportes());
        
    }
    
    public void gestionProductos() {

        Vista_Producto producto = new Vista_Producto();

        producto.setVisible(true);

        admin.dispose(); // cierra la ventana actual
    }
    
    public void gestionClientes(){
        
        Vista_Cliente cliente = new Vista_Cliente();
        cliente.setVisible(true);
        admin.dispose();
    }
    
    public void verReportes(){
        Vista_Historial_de_Reportes reportes = new Vista_Historial_de_Reportes();
        reportes.setVisible(true);
        admin.dispose();
    }
}
