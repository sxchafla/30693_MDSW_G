package Controlador_Admin;




import javax.swing.table.DefaultTableModel;
import GUI.Eventos_Tabla;
import Modelo.Datos_Cliente;
import Modelo.Repositorio_Clientes;
import Vista_Admin.Vista_Admin;
import Vista_Admin.Vista_Cliente;
import javax.swing.JOptionPane;


public class ControladorCliente {

    Vista_Cliente vista;
    Repositorio_Clientes repositorio_cliente = new Repositorio_Clientes();
    DefaultTableModel modelo;
    Eventos_Tabla filtro_Tabla = new Eventos_Tabla();

    public ControladorCliente(Vista_Cliente vista) {
        this.vista = vista;
        modelo = (DefaultTableModel) this.vista.getTablaCliente().getModel();
        filtro_Tabla.ordenar_filtar(modelo, vista.getTablaCliente(), vista.getFiltroCedula(),0);
        this.vista.getGuardarCliente().addActionListener(e -> guardar());
        this.vista.getEditarCliente().addActionListener(e -> editar());
        this.vista.getEliminarCliente().addActionListener(e -> eliminar());
        this.vista.getRegresarCliente().addActionListener(e -> regresar());
        repositorio_cliente.cargarTabla(modelo);
    }

    public void guardar() {
        try {
            String nombre = vista.getNombreCliente();
            String apellido = vista.getApellidoCliente();
            String cedula = vista.getCedulaCliente();
            String correo = vista.getCorreoCliente();
            String direccion = vista.getDireccionCliente();
            String numeroTelefonico = vista.getNumeroTelefonicoCliente();

            
             if (nombre.isEmpty()) {
                vista.getMensaje("Ponga el nombre por favor");
                return;
            }
            if (apellido.isEmpty()) {
                vista.getMensaje("Ingrese el apellido por favor");
                return;
            }
            if (cedula.isEmpty()) {
                vista.getMensaje("Ingrese la cedula por favor");
                return;
            }
            if (correo.isEmpty()) {
                vista.getMensaje("Ingrese el correo por favor");
                return;
            }
            if (direccion.isEmpty()) {
                vista.getMensaje("Ingrese la direccion por favor");
                return;
            }
            if(numeroTelefonico.isEmpty()){
                vista.getMensaje("Ingrese el numero telefonico por favor");
                return;
            }
            if(numeroTelefonico.length() < 10){
                vista.getMensaje("ingrese un numero telefonico correcto por favor");
                return;
            }
            if(!validarCedula(cedula)){
                vista.getMensaje("Ingrese una cedula correcta");
                return;
            }
            if(!validarCorreo(correo)){
                vista.getMensaje("Ingrese un correo valido");
                return;
            }
            
            if(!repositorio_cliente.buscarCliente(cedula)){
  
                Datos_Cliente cli = new Datos_Cliente(nombre, apellido, cedula, correo, numeroTelefonico, direccion,"");
                int opcion = vista.getMensajeConfirmacion("Verifique sus datos \n"+" Nombre: "+nombre+" "+apellido+"\n"
                    +" Cedula: " +cedula+"\n"
                    +" Correo: " +correo+"\n"
                    +" Numero Telefonico: " +numeroTelefonico+"\n"
                    +" Direccion: " +direccion);
            
                if(opcion == 0){
                    repositorio_cliente.agregarCliente(cli);
                    repositorio_cliente.cargarTabla(modelo);
                    vista.getLimpiarCliente();
                    vista.getMensaje("Usuario registrado");
                
            }
            }else{

                vista.getMensaje("La cedula ya esta ingresada");
                return;
                
            }
        } catch (Exception e) {
            vista.getMensaje("Ingrese todos los datos por favor");
        }
    }

     public void editar() {
        try {
            //se obtiene una fila selecionada para validar y que no edite si ningun dato fue modificado
            int filaSelecionada = vista.getTablaCliente().getSelectedRow();
            if(filaSelecionada == -1){
                vista.getMensaje("Edite algun dato");
                return;
            }
            
            
            
            int opcion = vista.getMensajeConfirmacion("Seguro que quiere editar?");
            if(opcion == 0){
                
                //Esto permite editar los datos sin esperar una confirmacion como un enter o editar otra celda
                if(vista.getTablaCliente().isEditing()){
                    vista.getTablaCliente().getCellEditor().stopCellEditing();
                }
            
                //Aqui vamos a editar los datos en caso de que se edite en varias filas de la tabla, las filas los obtenemos directamente del modelo
                // no es necesario convertir filas de tabla en filas de modelo
                for(int i = 0; i < modelo.getRowCount(); i++){
                    String cedula = modelo.getValueAt(i, 0).toString().trim();
                    String nombre = modelo.getValueAt(i, 1).toString().trim();
                    String apellido = modelo.getValueAt(i, 2).toString().trim();
                    String correoElectronico = modelo.getValueAt(i, 3).toString().trim();
                    String numeroTelefonico = modelo.getValueAt(i, 4).toString().trim();
                    String direccion = modelo.getValueAt(i, 5).toString().trim();
                   
                    if (nombre.isEmpty()) {
                        vista.getMensaje("Ponga el nombre por favor");
                        return;
                    }
                    if(!nombre.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ]+")){
                        vista.getMensaje("Ingrese solo letras en el nombre por favor");
                        return;
                    }
                    if (apellido.isEmpty()) {
                        vista.getMensaje("Ingrese el apellido por favor");
                        return;
                    }
                    if(!apellido.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ]+")){
                        vista.getMensaje("Ingrese solo letras en el apellido por favor");
                        return;
                    }
                    if (cedula.isEmpty()) {
                        vista.getMensaje("Ingrese la cedula por favor");
                        return;
                    }
                    if (correoElectronico.isEmpty()) {
                        vista.getMensaje("Ingrese el correo por favor");
                        return;
                    }
                    if (direccion.isEmpty()) {
                        vista.getMensaje("Ingrese la direccion por favor");
                        return;
                    }
                    
                    if(numeroTelefonico.isEmpty()){
                        vista.getMensaje("Ingrese el numero telefonico por favor");
                        return;
                    }
                    if(!validarCedula(cedula)){
                        vista.getMensaje("Ingrese una cedula correcta en "+nombre+" "+apellido);
                        return;
                    }
                    
                    if(!validarCorreo(correoElectronico)){
                        vista.getMensaje("Ingrese un correo correcto en "+nombre+" "+apellido);
                        return;
                    }
                    if(numeroTelefonico.length() < 10){
                        vista.getMensaje("Ingrese un numero telefonico correcto");
                        return;
                    }
                    
                    Datos_Cliente cli = new Datos_Cliente(nombre, apellido, cedula, correoElectronico, numeroTelefonico, direccion,"");
                    repositorio_cliente.modificar(cedula, cli);
                    
                }
                vista.getMensaje("Datos del cliente modificado");
                //Llamamos al repositorio pasando el la cedula y el objeto
                // actualizamos la tabla y limpiamos los campos
                repositorio_cliente.cargarTabla(modelo);
                
            }else{
                repositorio_cliente.cargarTabla(modelo);
                return;
            }
        } catch (NumberFormatException e) {
            vista.getMensaje("Caracter Incorrecto");
        } catch (Exception e) {
            vista.getMensaje("Error al modificar");
        }
    }
     
    public void eliminar() {
        //Aqui obtengo la fila selecionada en la tabla
         //utilizamos getSelectedRow y no getSelectedRowCount por que el primero empieza desde el -1 si no se selecciona nada
        // en cambio con el getSelectedRowCount si no se selecionada nada empieza desde el 0
        int filaSelecionada = vista.getTablaCliente().getSelectedRow();
        //Se valida
         if(filaSelecionada == -1){
            vista.getMensaje("Selecione una fila por favor");
            return;
        }
         
         int confirmacion = JOptionPane.showConfirmDialog(
                null,
                "¿Está seguro de eliminar este cliente?",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION
        );

        if (confirmacion != JOptionPane.YES_OPTION) {
            return; // Cancela la eliminación
        }
        
        //Aqui convierto la fila selecionada de la tabla a la fila selecionada del modelo (a la tabla en tiempo real)
        int filaModelo = vista.getTablaCliente().convertRowIndexToModel(filaSelecionada);
        //Aqui obtengo la cedula, convierto a String el dato de tipo Object que obtengo del cajon de la fila y columna selecionada en el modelo (tabla
        // en tiempo real) sin espacios
        String cedula = modelo.getValueAt(filaModelo, 0).toString().trim();
        //Enviamos cedula al metod eliminarClientes del repositorio Clientes
        repositorio_cliente.eliminarCliente(cedula);
        vista.getMensaje("Se elimino correctamente");
        repositorio_cliente.cargarTabla(modelo);
    }

   
    

    public void regresar() {
        Vista_Admin admin = new Vista_Admin();
        admin.setVisible(true);
        vista.dispose();
    }
    
    
     public boolean validarCedula(String cedula) {
        // 1. Validar longitud básica (debe tener 10 dígitos)
        if (cedula.length() != 10) {
            return false;
        }

        // 2. Validar el código de provincia (primeros dos dígitos entre 01 y 24, o 30)
        int provincia = Integer.parseInt(cedula.substring(0, 2));
        if (!((provincia >= 1 && provincia <= 24) || provincia == 30)) {
            return false;
        }

        // 3. Algoritmo de Módulo 10
        //Esto es para multiplicar los primeros 9 digitos los impares *2 y los pares *1
        int[] coeficientes = {2, 1, 2, 1, 2, 1, 2, 1, 2};
        int suma = 0;

        for (int i = 0; i < coeficientes.length; i++) {
            //esta fila convierte el carácter en la posición i a un número entero real para poder hacer cálculos.
            int digito = Character.getNumericValue(cedula.charAt(i));
            int producto = digito * coeficientes[i];

            // Si el producto es mayor a 9, se le resta 9
            if (producto > 9) {
                producto -= 9;
            }
            suma += producto;
        }
        //Obtenemos el último dígito de la cédula (el que está en la posición 10, índice 9)
        
        int digitoVerificadorRecibido = Character.getNumericValue(cedula.charAt(9));
        int residuo = suma % 10;
        //Si el residuo es 0, el verificador debe ser 0. Si no, restamos el residuo de 10 para obtener el número exacto que debería ser el último dígito.
        int digitoVerificadorCalculado = (residuo == 0) ? 0 : 10 - residuo;

        // 4. Comparación final
        return digitoVerificadorCalculado == digitoVerificadorRecibido;
}
    
    public boolean validarCorreo(String correo){
        String ultimosTres = correo.substring(correo.length() - 4);
        if(!correo.contains("@")){
            return false;
        }        
        if(!ultimosTres.equals(".com")){
            return false;
        }
        if(!correo.contains("gmail") && !correo.contains("hotmail")){
            return false;
        }
        
        return true;
        
    }
}
