package Controlador_Admin;

import Modelo.Producto;
import Modelo.Repositorio_Producto;
import Vista_Admin.Vista_Admin;
import Vista_Admin.Vista_Producto;
import GUI.Eventos_Tabla;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class ControladorProducto {

    private Vista_Producto vista;
    private Repositorio_Producto repositorio_producto = new Repositorio_Producto();
    private DefaultTableModel modelo;
    private Eventos_Tabla filtro_tabla = new Eventos_Tabla();
    private JTextField numeroSerieBuscado;
    

    public ControladorProducto(Vista_Producto vista) {

        this.vista = vista;

        this.modelo = new DefaultTableModel(
                new Object[][]{},
                new String[]{"N-SERIE", "NOMBRE", "CANTIDAD", "PRECIO UNITARIO"}) {

            @Override
            public boolean isCellEditable(int fila, int columna) {
                return columna != 0;
            }
        };

        vista.getTablaProducto().setModel(modelo);
        
        numeroSerieBuscado = vista.getNumeroSerieBuscado();
        filtro_tabla.ordenar_filtar(
                modelo,
                vista.getTablaProducto(),
                numeroSerieBuscado,
                0);

        vista.getGuardarProducto().addActionListener(e -> guardar());
        vista.getEditarProducto().addActionListener(e -> editar());
        vista.getEliminarProducto().addActionListener(e -> eliminar());
        vista.getRegresarProducto().addActionListener(e -> regresar());

        repositorio_producto.cargarTabla(modelo);
    }

//guardado1 no pares bola
private void guardar() {

    try {

        String nombre = vista.getNombreProducto().trim();
        String cantidadIngresada = vista.getCantidadProducto().trim();
        String precioIngresado = vista.getPrecioProducto().trim();

        if (nombre.isEmpty()) {
            vista.getMensaje("Ingrese el nombre");
            return;
        }
        if (cantidadIngresada.isEmpty()) {
            vista.getMensaje("Ingrese la cantidad");
            return;
        }
        if (precioIngresado.isEmpty()) {
            vista.getMensaje("Ingrese tel precio");
            return;
        }
        
        int cantidad = Integer.parseInt(vista.getCantidadProducto());
        double precio = Double.parseDouble(vista.getPrecioProducto());

        if ( precio <= 0) {
            vista.getMensaje("Cantidad inválida");
            return;
        }
        
        if (cantidad <= 0) {
            vista.getMensaje("Cantidad inválida");
            return;
        }
        
        if ( precio > 1000) {
            vista.getMensaje("Cantidad inválida");
            return;
        }
        
        if (cantidad > 1000) {
            vista.getMensaje("Cantidad inválida");
            return;
        }
        

        // 🔍 Buscar por NOMBRE (sin importar precio)
        Producto existente = repositorio_producto.buscarPorNombre(nombre);

        if (existente != null) {
            // ✅ Ya existe un producto con el mismo nombre
           
                // Caso 2: Mismo nombre + precio DIFERENTE → preguntar qué hacer
                String[] opciones = {"Actualizar precio", "Crear nuevo producto","Actualizar precio", "Cancelar"};
                int respuesta = javax.swing.JOptionPane.showOptionDialog(
                    vista,
                    "El producto '" + nombre + "' ya existe con un precio diferente.\n\n" +
                    "Precio actual: $" + existente.getPrecioUnitario() + "\n" +
                    "Nuevo precio: $" + precio + "\n" +
                    "Cantidad a agregar: " + cantidad + "\n\n" +
                    "¿Qué deseas hacer?",
                    "Precio diferente detectado",
                    javax.swing.JOptionPane.DEFAULT_OPTION,
                    javax.swing.JOptionPane.QUESTION_MESSAGE,
                    null,
                    opciones,
                    opciones[0]
                );

                if (respuesta == 0) {
                    // Opción 1: Actualizar precio del producto existente y aumentar cantidad
                    int nuevaCantidad = existente.getCantidad() + cantidad;
                    existente.setPrecioUnitario(precio);
                    existente.setCantidad(nuevaCantidad);
                    repositorio_producto.editarProducto(existente, existente.getNumeroSerie());
                    repositorio_producto.cargarTabla(modelo);
                    vista.getLimpiarProducto();
                    vista.getMensaje("Precio actualizado y cantidad aumentada. Nuevo stock: " + nuevaCantidad);
                    
                } else if (respuesta == 1) {
                    // Opción 2: Crear nuevo producto (con el nuevo precio)
                    String numeroSerie = repositorio_producto.generarCodigoProducto();
                    Producto nuevo = new Producto(numeroSerie, nombre, cantidad, precio);
                    repositorio_producto.agregarDocumento(nuevo);
                    repositorio_producto.actualizarCodigoProducto();
                    repositorio_producto.cargarTabla(modelo);
                    vista.getLimpiarProducto();
                    vista.getMensaje("Nuevo producto creado con serie: " + numeroSerie + " (precio $" + precio + ")");
                } else if(respuesta == 2){
                    int nuevaCantidad = existente.getCantidad() + cantidad;
                    repositorio_producto.actualizarStock(existente.getNumeroSerie(), nuevaCantidad);
                    repositorio_producto.cargarTabla(modelo);
                    vista.getLimpiarProducto();
                    vista.getMensaje("✅ Cantidad actualizada. Nuevo stock: " + nuevaCantidad);
                }
                return;
            }
        

        // ❌ No existe ningún producto con ese nombre → crear nuevo
        String numeroSerie = repositorio_producto.generarCodigoProducto();

        Producto producto = new Producto(
            numeroSerie,
            nombre,
            cantidad,
            precio
        );

        repositorio_producto.agregarDocumento(producto);
        repositorio_producto.actualizarCodigoProducto();
        repositorio_producto.cargarTabla(modelo);

        vista.getLimpiarProducto();
        vista.getMensaje("Nuevo producto guardado con serie: " + numeroSerie);

    } catch (Exception e) {
        vista.getMensaje("Ingrese datos válidos");
        e.printStackTrace();
    }
}

private void editar() {

    try{

            int filaSelecionada = vista.getTablaProducto().getSelectedRow();
            if(filaSelecionada == -1){
                vista.getMensaje("Edite algun dato");
                return;
            }
            int opcion = vista.getMensajeConfirmacion("Seguro que quiere editar?");
            if(opcion == 0){
            //Aqui conparo el nombre de la categoria obtenido, luego obtendo su objeto del combobox y lo mando al objetto producto
                //para asi mandarlo a editar
                
            //Esto permite editar los datos sin esperar una confirmacion como un enter o editar otra celda
            if(vista.getTablaProducto().isEditing()){
                vista.getTablaProducto().getCellEditor().stopCellEditing();
            }
            //Aqui vamos a editar los datos en caso de que se edite en varias filas de la tabla, las filas los obtenemos directamente del modelo
            // no es necesario convertir filas de tabla en filas de modelo
            for(int i = 0; i < modelo.getRowCount(); i++){
                String id = modelo.getValueAt(i, 0).toString().trim();
                String nombre = modelo.getValueAt(i, 1).toString().trim();
                String cantidad_Anterior = modelo.getValueAt(i, 2).toString().trim();
                String precio_Anterior = modelo.getValueAt(i, 3).toString().trim();
                if(!cantidad_Anterior.matches("[0-9]+") ){
                    vista.getMensaje("Ingrese solo numeros en la cantidad por favor");
                    return;
                }
           
                if(!precio_Anterior.matches("[0-9]+\\.[0-9]+")){
                    vista.getMensaje("Ingrese solo numeros en el precio por favor");
                    return;
                }
                    
                int cantidad = Integer.parseInt(modelo.getValueAt(i, 2).toString().trim());
                double precio = Double.parseDouble(modelo.getValueAt(i, 3).toString().trim()); 
                
               
                if(!nombre.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ]+")){
                    vista.getMensaje("Ingrese solo letras en el nombre por favor");
                    return;
                }
                Producto p = new Producto(id, nombre, cantidad, precio);
                repositorio_producto.editarProducto(p, id);
                        
            }
                repositorio_producto.cargarTabla(modelo);
            vista.getMensaje("Se edito con exito");
        }else{
                repositorio_producto.cargarTabla(modelo);
                return;
                }
        }catch(Exception e){
            vista.getMensaje("No se pudo conectar a la base de datos, Revise los campos de cantidad y precio, ingrese solo numeros");
            return;
        }
}

    private void eliminar() {

        int fila = vista.getTablaProducto().getSelectedRow();

        if (fila == -1) {
            vista.getMensaje("Seleccione una fila");
            return;
        }
        
        int confirmacion = JOptionPane.showConfirmDialog(
                null,
                "¿Está seguro de eliminar este producto?",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION
        );

        if (confirmacion != JOptionPane.YES_OPTION) {
            return; // Cancela la eliminación
        }
        
        int filaModelo = vista.getTablaProducto()
                .convertRowIndexToModel(fila);
        

        String numeroSerie = modelo
                .getValueAt(filaModelo, 0)
                .toString();

        repositorio_producto.eliminarProducto(numeroSerie);

        repositorio_producto.cargarTabla(modelo);

        vista.getMensaje("Producto eliminado");
    }

    private void regresar() {

        Vista_Admin admin = new Vista_Admin();

        admin.setVisible(true);

        vista.dispose();
    }
}