package Modelo;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Updates;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;
import org.bson.types.Binary;

public class Repositorio_Facturas {

    //Establecida la conexion
    private static MongoCollection<Document> datos_factura;
    private static MongoCollection<Document> id_factura;
    Factura factura;
    ArrayList<Document> documentos = new ArrayList<>();

    public Repositorio_Facturas(Factura factura) {
        this.factura = factura;
        MongoDatabase db = Conexion_Mongo.getConectarBase();
        this.datos_factura = db.getCollection("Detalle_factura");
        this.id_factura = db.getCollection("ID_Factura");

    }

    public void agregaLista(Document d) {
        documentos.add(d);
    }

    public void cargarTabla(DefaultTableModel modelo) {
        modelo.setRowCount(0);
        for (DetalleFactura f : factura.getDetalle()) {
            Object[] filas = {
                f.getNombreProducto(),
                f.getCantidad(),
                f.getPrecioUnitario(),
                f.calcularTotalUnitario()
            };
            modelo.addRow(filas);
        }
    }

    public void aniadirDocumentos() {
        for (DetalleFactura d : factura.getDetalle()) {
            Document doc = new Document()
                    .append("Nombre producto", d.getNombreProducto())
                    .append("Cantidad solicitada", d.getCantidad())
                    .append("Precio Unitario", d.getPrecioUnitario())
                    .append("Precio semitotal", d.calcularTotalUnitario())
                    ;
            documentos.add(doc);
        }
    }

    // metodo que guarda todos los datos de la factura en la base de datos
    public void agregarDetalles() {
        try {
            // 1. Obtenemos la ruta donde está tu proyecto actualmente
            String rutaProyecto = System.getProperty("user.dir");

            // 2. Construimos la ruta hacia la carpeta PDF (dinámicamente)
            // Nota: El espacio después de "Factura" es importante para que coincida con el archivo creado
            String nombrePDF = "Factura " + factura.getIdFactura() + ".pdf";

            // Ruta Final: Proyecto + carpeta PDF + nombre del archivo
            // Usamos File.separator para que funcione igual en Windows o Linux
            String rutaArchivo = rutaProyecto + java.io.File.separator + "PDF" + java.io.File.separator + nombrePDF;

            // --- FIN DE LA CORRECCIÓN ---
            // (Opcional) Imprimir para verificar que la ruta es correcta
            System.out.println("Intentando guardar en Mongo el PDF: " + rutaArchivo);

            // 3. Convertir a bytes (Esto ya lo tenías, solo asegúrate de usar la variable 'rutaArchivo')
            byte[] pdfBytes = java.nio.file.Files.readAllBytes(java.nio.file.Paths.get(rutaArchivo));

            aniadirDocumentos();
            Document documento = new Document()
                    //este siempre le vamos a mandar vigente, el administrador podra anularlo
                    
                    .append("Estado de factura", "Vigente")
                    .append("Numero de factura", factura.getIdFactura())
                    .append("Fecha", factura.getLocaldate())
                    .append("Cedula", factura.getDatos_cliente().getCedula())
                    .append("Apellidos cliente", factura.getDatos_cliente().getApellido())
                    .append("Nombres cliente", factura.getDatos_cliente().getNombre())
                    .append("Numero de telefono", factura.getDatos_cliente().getNumeroTelefonico())
                    .append("Direccion", factura.getDatos_cliente().getDireccion())
                    .append("Correo electronico", factura.getDatos_cliente().getCorreoElectronico())
                    .append("Detalles productos", documentos)
                    .append("Subtotal", factura.calcularSubtotal())
                    .append("Total", factura.precioTotal())
                    .append("pdf", new Binary(pdfBytes));

            datos_factura.insertOne(documento);
        } catch (IOException e) {
            System.out.println("No se encontro la ruta");
        }

    }

     public void crearCollecionIDFactura() {
        Document nuevo = new Document().append("codigo", "Fact-")
                .append("valor", 0);
        id_factura.insertOne(nuevo);
    }
     
    public String generarCodigoFactura() {

        //Esta linea busca con el .find() y con el .projection(Projections.include()).first solamente un solo documento del vampo valor
        Document d = id_factura.find(Filters.eq("codigo", "Fact-")).projection(Projections.include("valor")).first();
        //se extrae el valor del campo
        if (d == null) {
            crearCollecionIDFactura();
            System.out.println("Coleccion creada");
            return "Fact-00000";
        }
        int numeroFactura = d.getInteger("valor");
        // Este formato segun entiendo es que despues de Fact- lo demas se rrellena con 5 ceros pero los ultimos digitos son reeplazados 
        //por lo que tenga guardado numeroFactura
        return String.format("Fact-%05d", numeroFactura);
    }

    
    public void actualizarCodigoFactura() {
        //Lo que hace esta linea es que busca y actualiza al mismo tiempo
        Document buscar = id_factura.findOneAndUpdate(
                //Esto seleciona el documento que vamos a actualizar
                Filters.eq("codigo", "Fact-") //Aque aumenta el valor del campo en la base de datos en +1
                ,
                 Updates.inc("valor", 1));
    }

}
