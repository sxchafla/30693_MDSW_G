
package Modelo;

//Esta clase sera abstracta y clase padre de Administrador y Cliente
public abstract class Usuario {
    
    protected String usuario;
    protected String contrasenia;
    
    
    public Usuario(String usuario, String contrasenia) {
        this.usuario = usuario;
        this.contrasenia = contrasenia;
    }
    
    public abstract boolean ingreso(String usuario, String contrasenia);
}
