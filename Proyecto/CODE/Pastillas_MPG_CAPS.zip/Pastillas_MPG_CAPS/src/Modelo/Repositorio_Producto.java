package Modelo;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Updates;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

public class Repositorio_Producto {

    private static MongoCollection<Document> datos_Productos;
    private static MongoCollection<Document> id_productos;
    private ArrayList<Producto> lista_producto = new ArrayList<>();

    public Repositorio_Producto() {

        MongoDatabase db = Conexion_Mongo.getConectarBase();

        this.datos_Productos = db.getCollection("Producto");
        this.id_productos = db.getCollection("ID_Productos");
        agregarListaProducto();
    }

    private Document agregarMongo(Producto p) {

        return new Document("NumeroSerie", p.getNumeroSerie())
                .append("Nombre", p.getNombre())
                .append("Cantidad", p.getCantidad())
                .append("PrecioUnitario", p.getPrecioUnitario());
    }

    public static MongoCollection<Document> getDatos_Productos() {
        return datos_Productos;
    }

    public void agregarDocumento(Producto p) {
        datos_Productos.insertOne(agregarMongo(p));
    }

    // Verifica si ya existe el número de serie
    public boolean buscarProducto(String numeroSerie) {

        for (Document d : datos_Productos.find()) {

            if (d.getString("NumeroSerie").equalsIgnoreCase(numeroSerie)) {
                return true;
            }
        }

        return false;
    }

    // Busca y devuelve el producto completo
    public Producto buscarCapsula(String numeroSerie) {

        for (Document d : datos_Productos.find()) {

            if (d.getString("NumeroSerie").equalsIgnoreCase(numeroSerie)) {

                return new Producto(
                        d.getString("NumeroSerie"),
                        d.getString("Nombre"),
                        d.getInteger("Cantidad"),
                        d.getDouble("PrecioUnitario")
                );
            }
        }

        return null;
    }

    // Editar producto
    public void editarProducto(Producto p, String numeroSerieBuscado) {

        Document filtro = new Document("NumeroSerie", numeroSerieBuscado);

        Document nuevo = new Document("$set",
                new Document()
                        .append("Nombre", p.getNombre())
                        .append("Cantidad", p.getCantidad())
                        .append("PrecioUnitario", p.getPrecioUnitario()));

        datos_Productos.updateOne(filtro, nuevo);
        
        
    }

    // Eliminar producto
    public void eliminarProducto(String numeroSerie) {

        datos_Productos.deleteOne(
                new Document("NumeroSerie", numeroSerie)
        );
    }

    // Actualizar stock
    public void editarStock(Producto p, String numeroSerie) {

        Document filtro = new Document("NumeroSerie", numeroSerie);

        Document nuevo = new Document("$set",
                new Document("Cantidad", p.getCantidad()));

        datos_Productos.updateOne(filtro, nuevo);
    }

    // Cargar tabla
    public void cargarTabla(DefaultTableModel modelo) {

        modelo.setRowCount(0);

        for (Document d : datos_Productos.find()) {

            Object[] filas = {
                d.getString("NumeroSerie"),
                d.getString("Nombre"),
                d.getInteger("Cantidad"),
                d.getDouble("PrecioUnitario")
            };

            modelo.addRow(filas);
        }
    }

    // Actualizar stock directamente
    public void actualizarStock(String numeroSerie, int nuevoStock) {

        Document filtro = new Document("NumeroSerie", numeroSerie);

        Document actualizacion = new Document(
                "$set",
                new Document("Cantidad", nuevoStock)
        );

        datos_Productos.updateOne(filtro, actualizacion);
    }

    // Generador de serie automática
    public String generarCodigoProducto() {

        Document d = id_productos
                .find(Filters.eq("codigo", "MPG-"))
                .projection(Projections.include("valor"))
                .first();

        if (d == null) {

            crearColeccionProducto();
            System.out.println("Coleccion creada");

            return "MPG-0000";

        } else {

            int numeroProducto = d.getInteger("valor");

            return String.format("MPG-%04d", numeroProducto);
        }
    }

    public void actualizarCodigoProducto() {

        id_productos.findOneAndUpdate(
                Filters.eq("codigo", "MPG-"),
                Updates.inc("valor", 1)
        );
    }

    public void crearColeccionProducto() {

        Document nuevo = new Document()
                .append("codigo", "MPG-")
                .append("valor", 0);

        id_productos.insertOne(nuevo);
    }
    
// Buscar producto por NOMBRE + PRECIO (para evitar duplicados)
public Producto buscarPorNombreYPrecio(String nombre, double precioUnitario) {
    
    for (Document d : datos_Productos.find()) {
        
        if (d.getString("Nombre").equalsIgnoreCase(nombre) 
                && d.getDouble("PrecioUnitario") == precioUnitario) {
            
            return new Producto(
                d.getString("NumeroSerie"),
                d.getString("Nombre"),
                d.getInteger("Cantidad"),
                d.getDouble("PrecioUnitario")
            );
        }
    }
    
    return null; // No existe
}

// Buscar producto por NOMBRE (para detectar si ya existe, sin importar precio)
public Producto buscarPorNombre(String nombre) {
    
    for (Document d : datos_Productos.find()) {
        
        if (d.getString("Nombre").equalsIgnoreCase(nombre)) {
            
            return new Producto(
                d.getString("NumeroSerie"),
                d.getString("Nombre"),
                d.getInteger("Cantidad"),
                d.getDouble("PrecioUnitario")
            );
        }
    }
    
    return null; // No existe
}

public void agregarListaProducto(){
    for(Document d: datos_Productos.find()){
        Producto p = new Producto(d.getString("NumeroSerie"), d.getString("Nombre"), d.getInteger("Cantidad"), d.getDouble("PrecioUnitario"));
        lista_producto.add(p);
    }
}

    public ArrayList<Producto> getLista(){
        return lista_producto;
    }
    
    public void buscar_reducirStock(List<DetalleFactura> detalle){
        for(Document d: datos_Productos.find()){
            for(DetalleFactura de: detalle){
                if(d.getString("Nombre").equals(de.getNombreProducto())){
                    Producto p  = new Producto(d.getString("NumeroSerie")
                            , d.getString("Nombre")
                            , d.getInteger("Cantidad")
                            , d.getDouble("PrecioUnitario"));
                    p.reducirStock(de.getCantidad());
                    editarStock(p, d.getString("NumeroSerie"));
                }
            }
        }
    }
}