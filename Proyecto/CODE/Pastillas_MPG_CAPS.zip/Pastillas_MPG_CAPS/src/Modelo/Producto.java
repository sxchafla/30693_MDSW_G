package Modelo;

public class Producto {

    private String numeroSerie;
    private String nombre;
    private int cantidad;
    private double precioUnitario;

    public Producto(String numeroSerie, String nombre, int cantidad, double precioUnitario) {
        this.numeroSerie = numeroSerie;
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
    }

    public String getNumeroSerie() {
        return numeroSerie;
    }

    public void setNumeroSerie(String numeroSerie) {
        this.numeroSerie = numeroSerie;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public void reducirStock(int reduccion) {
        this.cantidad -= reduccion;
    }
    
    public void devolverStock(int aumentar){
         this.cantidad += aumentar;
    }
    
}