
package Modelo;
import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class MensajeCorreo {


    // Configuración de las credenciales (¡Usa la contraseña de aplicación!)
    private static final String REMITENTE = "javierchafla90@gmail.com";
    private static final String CLAVE_APLICACION = "xmuvnckhyutbuvoy"; 

    public static void enviarCorreoBienvenida(String correoCliente, String nombreCliente) {
        
        // 1. Configurar las propiedades del servidor SMTP de Gmail
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        
        // 2. Autenticarse en el servidor
            Session sesion = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(REMITENTE, CLAVE_APLICACION);
            }
        });

        try {
            // 3. Crear el mensaje
            Message mensaje = new MimeMessage(sesion);
            mensaje.setFrom(new InternetAddress(REMITENTE));
            mensaje.setRecipients(Message.RecipientType.TO, InternetAddress.parse(correoCliente));
            
            // Asunto
            mensaje.setSubject("¡Bienvenido a EcoWeb Quantum - MPG-CAPS!");
            
            // Cuerpo del mensaje (Puedes usar HTML para que se vea elegante)
            String cuerpoHtml = "<h2>¡Hola, " + nombreCliente + "!</h2>"
                    + "<p>Tu registro se ha completado con éxito en nuestro sistema.</p>"
                    + "<p>Ya puedes ingresar al catálogo y optimizar el rendimiento de tu combustible.</p>"
                    + "<br><p>Saludos cordiales,<br>El equipo de MPG-CAPS.</p>";
            
            mensaje.setContent(cuerpoHtml, "text/html; charset=utf-8");

            // 4. Enviar el correo
            Transport.send(mensaje);
            System.out.println("Correo enviado con éxito a: " + correoCliente);

        } catch (MessagingException e) {
            System.out.println("Error al enviar el correo: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
   

