
package Modelo;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;


public class Repositorio_Reporte_Facturas {
    
    
    MongoCollection<Document> datos_reporte;

    public Repositorio_Reporte_Facturas() {
        MongoDatabase db = Conexion_Mongo.getConectarBase();
        datos_reporte = db.getCollection("Detalle_factura");
    }
    
    public void leerReportes(DefaultTableModel modelo,String correo){
        boolean encontrado = false;
        modelo.setRowCount(0);
        for(Document d: datos_reporte.find()){
            if(d.getString("Estado de factura").equals("Vigente")){
                if(d.getString("Correo electronico").equals(correo)){
                    Object[] filas = {
                    d.getString("Fecha"),
                    d.getString("Numero de factura"),
                    d.getDouble("Total")
                };
                modelo.addRow(filas);
                encontrado = true;
                }
                
            }
        }
        if(!encontrado){
            JOptionPane.showMessageDialog(null, "No tiene registro de compras");
        }
    }
    
    
    public void leerReportesCompletos(DefaultTableModel modelo){
        modelo.setRowCount(0);
        for(Document d: datos_reporte.find()){
            if(d.getString("Estado de factura").equals("Vigente")){
                    Object[] filas = {
                    d.getString("Fecha"),
                    d.getString("Nombres cliente") +" "+ d.getString("Apellidos cliente"),
                    d.getString("Cedula"),
                    d.getString("Numero de factura"),
                    d.getDouble("Total"),
                };
                modelo.addRow(filas); 
            }
        }
    }
    
    
    public void anularReportes(String codigoFactura){
        Document filtro = new Document("Numero de factura",codigoFactura);
        Document nuevo = new Document("$set", new Document().
                append("Estado de factura", "Anulado"));
        datos_reporte.updateMany(filtro, nuevo);
    }
    
    // metodo para buscar por el numero de factura en la base de datos
    public Document buscarFacturaPorNumero(String numeroFactura) {
        Document filtro = new Document("Numero de factura", numeroFactura);
        return datos_reporte.find(filtro).first();
    }

    
    /*.append("Estado de factura", factura.estadoFactura())
                .append("Numero de factura", factura.getIdFatura())
                .append("Fecha", factura.getLocaldate())
                .append("Cedula", factura.getCliente().getCedula())
                .append("Apellidos cliente", factura.getCliente().getApellido())
                .append("Nombres cliente", factura.getCliente().getNombre())
                .append("Numero de telefono", factura.getCliente().getNumeroTelefonico())
                .append("Direccion", factura.getCliente().getDireccion())
                .append("Correo electronico", factura.getCliente().getCorreoElectronico())
                .append("Detalles productos", documentos)
                .append("Subtotal", factura.calcularSubtotal())
                .append("Total", factura.precioTotal());*/
}
