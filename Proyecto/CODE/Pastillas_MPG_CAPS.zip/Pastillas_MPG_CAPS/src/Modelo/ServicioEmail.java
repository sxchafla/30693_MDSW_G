package Modelo;

 // Asegúrate que coincida con tu paquete

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
import java.io.File;
import java.io.UnsupportedEncodingException;

public class ServicioEmail {

    // Configuración de tu cuenta GMAIL
    private final String miCorreo = "javierchafla90@gmail.com"; // TU CORREO COMPLETO

    // IMPORTANTE: Aquí NO va tu contraseña normal. 
    // Va la "Contraseña de Aplicación" de 16 letras que generaste en Google
    private final String miContrasena = "xmuvnckhyutbuvoy";

    public boolean enviarFactura(String destinatario, String rutaArchivoPdf) {
        // Aquí le decimos a Java CÓMO y a DÓNDE conectarse
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        
        //Creamos una sesión que recuerda nuestro usuario y contraseña
        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                // OJO: Aquí va tu correo REAL y tu Contraseña de Aplicación (16 letras)
                return new PasswordAuthentication(miCorreo, miContrasena);
            }
        });

        try {
            Message message = new MimeMessage(session);

            // AQUÍ EL TRUCO PROFESIONAL:
            message.setFrom(new InternetAddress(miCorreo, "Sistema de Facturación"));

            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
            message.setSubject("Tu Factura de Compra");

            // Cuerpo del mensaje
            Multipart multipart = new MimeMultipart();

            // Parte 1: Texto
            BodyPart textoParte = new MimeBodyPart();
            textoParte.setText("Estimado cliente, adjunto su factura. Gracias por su preferencia.");
            multipart.addBodyPart(textoParte);

            // Parte 2: PDF
            BodyPart adjuntoParte = new MimeBodyPart();
            File archivo = new File(rutaArchivoPdf);
            if (!archivo.exists()) {
                System.out.println("No encontré el archivo en: " + rutaArchivoPdf);
                return false;
            }
            DataSource source = new FileDataSource(rutaArchivoPdf);
            adjuntoParte.setDataHandler(new DataHandler(source));
            adjuntoParte.setFileName(archivo.getName());
            multipart.addBodyPart(adjuntoParte);

            message.setContent(multipart);
            Transport.send(message);

            System.out.println("¡Correo enviado correctamente!");
            return true;

        } catch (UnsupportedEncodingException | MessagingException e) { // Usamos Exception para atrapar TODO
            System.out.println("Error enviando: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    
    
    
}
