
package Modelo;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;


public class Factura {
    
    private String idFactura;
    private Datos_Cliente datos_cliente;
    private ArrayList<DetalleFactura> detalle = new ArrayList<>();
    
    LocalDate hoy = LocalDate.now();
    private String localdate = hoy.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));

    public String getIdFactura() {
        return idFactura;
    }

    public void setIdFactura(String idFactura) {
        this.idFactura = idFactura;
    }

    public Datos_Cliente getDatos_cliente() {
        return datos_cliente;
    }

    public void setDatos_cliente(Datos_Cliente datos_cliente) {
        this.datos_cliente = datos_cliente;
    }

    public ArrayList<DetalleFactura> getDetalle() {
        return detalle;
    }

    public void setDetalle(ArrayList<DetalleFactura> detalle) {
        this.detalle = detalle;
    }

    public void agregarDetalle(DetalleFactura d){
        detalle.add(d);
    }

    public String getLocaldate() {
        return localdate;
    }

    public void setLocaldate(String localdate) {
        this.localdate = localdate;
    }
    
    
     public double calcularSubtotal(){
        double precio = 0;
        for(DetalleFactura d: detalle){
            precio += d.getCantidad()*d.getPrecioUnitario();
        }
        return precio;
    }
    
      public double subTotalIva(){
        double precio = 0 ;
        double precioIva = 0;
        for(DetalleFactura d: detalle){
            precio += d.getCantidad()*d.getPrecioUnitario();
            precioIva = precio*0.15;
        }
        return precioIva;
    }
    
    //En este metodo se calcula el precio total por unidad y devuelve un double solamente con 2 decimales
    public double precioTotal(){  
        //Obtiene el decimal que se puede generar con la operacion y solamente lo transformay lo mantiene con 2 decimales
        return BigDecimal.valueOf(calcularSubtotal()+subTotalIva())
        .setScale(2, RoundingMode.HALF_UP)
        .doubleValue();
    }

}
