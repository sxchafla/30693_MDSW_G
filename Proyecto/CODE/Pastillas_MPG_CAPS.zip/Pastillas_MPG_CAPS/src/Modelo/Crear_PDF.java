package Modelo;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import javax.swing.JTable;

public class Crear_PDF {

    // CAMBIO 1: Cambiamos 'void' por 'String' para devolver la ruta
    public String generarPDF(/*JTable tabla,*/ Factura datos) {

        // CAMBIO 2: Usamos ruta relativa (carpeta PDF dentro del proyecto)
        String nombreArchivo = "Factura " + datos.getIdFactura() + ".pdf";
        String rutaDestino = "PDF/" + nombreArchivo;

        BaseColor azulFondo = new BaseColor(0, 51, 120);
        BaseColor blanco = BaseColor.WHITE;

        try {
            // CAMBIO 3: Crear la carpeta PDF si no existe (para evitar errores)
            File carpeta = new File("PDF");
            if (!carpeta.exists()) {
                carpeta.mkdir();
            }

            Document documento = new Document(PageSize.A4.rotate(), 0, 0, 30, 30);
            PdfWriter.getInstance(documento, new FileOutputStream(rutaDestino));

            documento.open();

            // --- 1. ENCABEZADO ---
            PdfPTable banner = new PdfPTable(2);
            banner.setWidthPercentage(100);
            banner.setWidths(new float[]{60, 40});

            PdfPCell cellTitulo = new PdfPCell(new Phrase("FACTURA", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 32, blanco)));
            cellTitulo.setBackgroundColor(azulFondo);
            cellTitulo.setBorder(Rectangle.NO_BORDER);
            cellTitulo.setPadding(30);
            banner.addCell(cellTitulo);

            PdfPCell cellNum = new PdfPCell(new Phrase("Número: " + datos.getIdFactura(), FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14, blanco)));
            cellNum.setBackgroundColor(azulFondo);
            cellNum.setBorder(Rectangle.NO_BORDER);
            cellNum.setPadding(30);
            cellNum.setHorizontalAlignment(Element.ALIGN_RIGHT);
            cellNum.setVerticalAlignment(Element.ALIGN_BOTTOM);
            banner.addCell(cellNum);

            documento.add(banner);

            // --- 2. DATOS DEL CLIENTE ---
            PdfPTable infoSeccion = new PdfPTable(2);
            infoSeccion.setWidthPercentage(90);
            infoSeccion.setSpacingBefore(20);

            Font fNegrita = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12);
            Font fNormal = FontFactory.getFont(FontFactory.HELVETICA, 11);

            Paragraph p = new Paragraph();
            p.add(new Chunk("Datos del Cliente:\n", fNegrita));
            p.add(new Chunk("Nombre: " + datos.getDatos_cliente().getApellido() + " " + datos.getDatos_cliente().getNombre() + "\n", fNormal));
            p.add(new Chunk("Cédula: " + datos.getDatos_cliente().getCedula() + "\n", fNormal));
            p.add(new Chunk("Correo: " + datos.getDatos_cliente().getCorreoElectronico() + "\n", fNormal));
            p.add(new Chunk("Dirección: " + datos.getDatos_cliente().getDireccion() + "\n", fNormal));

            PdfPCell celdaDatos = new PdfPCell(p);
            celdaDatos.setBorder(Rectangle.NO_BORDER);
            infoSeccion.addCell(celdaDatos);

            // Logo (Opcional)
            try {
                Image logo = Image.getInstance("");
                logo.scaleToFit(100, 100);
                PdfPCell celdaLogo = new PdfPCell(logo);
                celdaLogo.setBorder(Rectangle.NO_BORDER);
                celdaLogo.setHorizontalAlignment(Element.ALIGN_RIGHT);
                infoSeccion.addCell(celdaLogo);
            } catch (Exception e) {
                // Si no hay logo, ponemos una celda vacía
                PdfPCell c = new PdfPCell(new Phrase(""));
                c.setBorder(Rectangle.NO_BORDER);
                infoSeccion.addCell(c);
            }
            documento.add(infoSeccion);

            // Fecha
            Paragraph fecha = new Paragraph("Fecha de emisión: " + datos.getLocaldate(), fNormal);
            fecha.setIndentationLeft(30);
            fecha.setSpacingBefore(10);
            documento.add(fecha);

          /*  // --- 3. TABLA DE PRODUCTOS ---
            PdfPTable tablaPdf = new PdfPTable(tabla.getColumnCount());
            tablaPdf.setWidthPercentage(90);
            tablaPdf.setSpacingBefore(20);
            
            // Ajustamos anchos solo si coinciden las columnas (evita errores)
            if(tabla.getColumnCount() == 4) {
                tablaPdf.setWidths(new float[]{40, 10, 15, 15});
            }

            Font fEnca = FontFactory.getFont("Tahoma", 10, Font.BOLD, BaseColor.WHITE);
            Font fDato = FontFactory.getFont("Tahoma", 10, Font.NORMAL, BaseColor.BLACK);

            // Cabecera
            for (int i = 0; i < tabla.getColumnCount(); i++) {
                PdfPCell c = new PdfPCell(new Phrase(tabla.getColumnName(i), fEnca));
                c.setBackgroundColor(azulFondo);
                c.setHorizontalAlignment(Element.ALIGN_CENTER);
                c.setPadding(5);
                tablaPdf.addCell(c);
            }

            // Datos
            for (int f = 0; f < tabla.getRowCount(); f++) {
                for (int c = 0; c < tabla.getColumnCount(); c++) {
                    String val = (tabla.getValueAt(f, c) != null) ? tabla.getValueAt(f, c).toString() : "";
                    PdfPCell cell = new PdfPCell(new Phrase(val, fDato));
                    if (f % 2 != 0) cell.setBackgroundColor(new BaseColor(240, 240, 240)); // Filas alternas
                    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                    cell.setPadding(5);
                    tablaPdf.addCell(cell);
                }
            }
            documento.add(tablaPdf);*/

            // --- 4. TOTALES (CORREGIDO) ---
            // Usamos una sola tabla para alinear a la derecha
            PdfPTable tablaTotales = new PdfPTable(2);
            tablaTotales.setWidthPercentage(90);
            tablaTotales.setWidths(new float[]{70, 30});
            tablaTotales.setSpacingBefore(10);

            // Subtotal
            PdfPCell cSub = new PdfPCell(new Phrase("Subtotal:  $ " + String.format("%.2f", datos.calcularSubtotal()), fNegrita));
            cSub.setHorizontalAlignment(Element.ALIGN_RIGHT);
            cSub.setBorder(Rectangle.NO_BORDER);
            
            tablaTotales.addCell(celdaVacia()); // Celda izquierda vacía
            tablaTotales.addCell(cSub);         // Celda derecha con dato

            // Total
            PdfPCell cTotal = new PdfPCell(new Phrase("TOTAL:  $ " + String.format("%.2f", datos.precioTotal()), 
                    FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, blanco)));
            cTotal.setBackgroundColor(azulFondo);
            cTotal.setHorizontalAlignment(Element.ALIGN_RIGHT);
            cTotal.setPadding(5);

            tablaTotales.addCell(celdaVacia());
            tablaTotales.addCell(cTotal);

            documento.add(tablaTotales);

            // Cierre
            Paragraph fin = new Paragraph("\n\nGracias por su compra!", fNegrita);
            fin.setAlignment(Element.ALIGN_CENTER);
            documento.add(fin);

            documento.close();
            System.out.println("PDF creado en: " + rutaDestino);

            // CAMBIO 4: ¡Retornamos la ruta!
            return rutaDestino;

        } catch (DocumentException | FileNotFoundException e) {
            //e.printStackTrace();
            return null; // Retornamos null si falló
        } catch (Exception e) {
            //e.printStackTrace();
            return null;
        }
    }

    // Auxiliar para celdas vacías
    private PdfPCell celdaVacia() {
        PdfPCell c = new PdfPCell(new Phrase(""));
        c.setBorder(Rectangle.NO_BORDER);
        return c;
    }
}