
package Modelo;

import java.math.BigDecimal;
import java.math.RoundingMode;


public class DetalleFactura {
    
    private String  nombreProducto;
    private int cantidad;
    private double precioUnitario;

    public DetalleFactura(String nombreProducto, int cantidad, double precioUnitario) {
        this.nombreProducto = nombreProducto;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
      
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

   public void aumentarCantidad(int cantidad){
       this.cantidad +=cantidad;
   }

    public double calcularTotalUnitario(){
        //Obtiene el decimal que se puede generar con la operacion y solamente lo transformay lo mantiene con 2 decimales
        return BigDecimal.valueOf(cantidad * precioUnitario)
        .setScale(2, RoundingMode.HALF_UP)
        .doubleValue();
    }
    
}
