
package Modelo;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Updates;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

public class Repositorio_Clientes {

    private static MongoCollection<Document> datos_cliente;
    private static MongoCollection<Document> id_clientes;

    public Repositorio_Clientes() {

        MongoDatabase db = Conexion_Mongo.getConectarBase();
        this.datos_cliente = db.getCollection("Clientes");


    }

    private Document agregarDocumento(Datos_Cliente c) {
        return new Document("Cedula", c.getCedula())
                .append("Nombres", c.getNombre())
                .append("Apellidos", c.getApellido())
                .append("Correo electronico", c.getCorreoElectronico())
                .append("Numero telefonico", c.getNumeroTelefonico())
                .append("Direccion", c.getDireccion())
                .append("Contrasenia", c.getContrasenia());


    }

    public void agregarCliente(Datos_Cliente c) {
        datos_cliente.insertOne(agregarDocumento(c));
    }

    
// Este metodo es para poder validar si la cedula del cliente ya esta ingresada
    public boolean buscarCliente(String cedulaBuscada) {
        for (Document d : datos_cliente.find()) {
            if(d.getString("Cedula").equalsIgnoreCase(cedulaBuscada)){
                return true;
            }
        }
        return false;
    }

    
    public boolean buscarIngresoCliente(String correo, String contrasenia) {
        for (Document d : datos_cliente.find()) {
            if(d.getString("Correo electronico").equals(correo) && d.getString("Contrasenia").equals(contrasenia)){
                return true;
            }
        }
        return false;
    }
    
    // metodo para modificar
    public void modificar(String cedula, Datos_Cliente c) {
        try {
            for(Document d: datos_cliente.find()){
                if(d.getString("Cedula").equals(cedula)){
                    //buscamos el documento por su cedula 
                    Document filtro = new Document("Cedula", cedula);

                    //Preparamos los cambios usando $set 
                    Document cambios = new Document("$set", new Document()
                        .append("Cedula", c.getCedula())
                        .append("Nombres", c.getNombre())
                        .append("Apellidos", c.getApellido())
                        .append("Correo electronico", c.getCorreoElectronico())
                        .append("Numero telefonico", c.getNumeroTelefonico())
                        .append("Direccion", c.getDireccion())
                    );
            // ctualizamos por la cedula selec
                    datos_cliente.updateOne(filtro, cambios);
                return;
                }
            }
           

        } catch (Exception ev) {
            System.out.println("Error no se puede ");
        }
    }

    public void eliminarCliente(String cedula) {
        datos_cliente.deleteOne(new Document("Cedula", cedula));
    }
    
   
    public void crearBaseCliente(){
        Document nuevo = new Document().append("codigo", "cli-")
                .append("valor", 0);
        id_clientes.insertOne(nuevo);
    }
    
     public void cargarTabla(DefaultTableModel modelo) {

        modelo.setRowCount(0);

        for (Document d : datos_cliente.find()) {

            Object[] filas = {
                d.getString("Cedula"),
                d.getString("Nombres"),
                d.getString("Apellidos"),
                d.getString("Correo electronico"),
                d.getString("Numero telefonico"),
                d.getString("Direccion")
            };

            modelo.addRow(filas);
        }
    }
     
     public Datos_Cliente datosCliente(String correo){
         for(Document d : datos_cliente.find()){
             if(d.getString("Correo electronico").equals(correo)){
                 return new Datos_Cliente(d.getString("Nombres"), 
                d.getString("Apellidos"),d.getString("Cedula"),
                d.getString("Correo electronico"),
                d.getString("Numero telefonico"),
                d.getString("Direccion"),"");
             }
         }
         return null;
     }
}

