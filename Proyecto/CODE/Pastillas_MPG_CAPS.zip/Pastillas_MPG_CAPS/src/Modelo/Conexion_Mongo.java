
package Modelo;


import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

public class Conexion_Mongo {

    public static String URL = "mongodb+srv://sxchafla:Pastillas2026@cluster0.gydjlnn.mongodb.net/?appName=Cluster0";
    public static String data = "Pastillas_MPG_CAPS";
    public static MongoClient creacion;

    public static MongoDatabase getConectarBase() {
        try {
            if (creacion == null) {
                creacion = MongoClients.create(URL);
                System.out.println("Conexion exitosa");
            }
        } catch (Exception e) {
            System.out.println("Ocurrio un Error");
        }
        return creacion.getDatabase(data);
    }

    
}

