
package Modelo;


public class Administrador extends Usuario{

    //Aqui en este contructor iniciamos directamente las credenciales que queremos ponerle y se quedan fijas
    //Solamente se las pueden cambiar por aqui
    public Administrador() {
        super("Admin", "Admin");
    }

    
    //este es el metodo abstracto de la clase padre donde compara las credenciales y devuelve un boolean
    @Override
    public boolean ingreso(String usuario, String contrasenia) {
        return this.usuario.equals(usuario) && this.contrasenia.equals(contrasenia);
    }
    
    
}
