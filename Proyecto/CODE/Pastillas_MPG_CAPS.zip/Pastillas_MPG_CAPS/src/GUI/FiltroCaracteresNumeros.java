/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

/**
 *
 * @author javie
 */
public class FiltroCaracteresNumeros extends DocumentFilter{
    
    /*
    . FilterBypass fb da permiso para escribir en el documento
    . offset da posición del cursor
    . texto es lo que se intenta escribir
    . attr es un  estilo del texto (no nos importa aquí)
    */
    // Este metodo se ejecuta cuando se inenta esctibir algo en la caja de texto
    @Override
    public void insertString(DocumentFilter.FilterBypass fb, int offset, String texto, AttributeSet attr) 
            // se utiliza esa Exception si se intenta excribir algo fuera de lo requerido
            throws BadLocationException{

            // esto valida si el texto ingresado cumple lo siguiente:         
            // caracteres del 0 al 9 y el punto
            // el + Sirve para dejar que se escriba 1 o mas caracteres
            if(texto.matches("[A-Za-z ]+")){
                // Aqui se permite que el texto ingrese 
                super.insertString(fb, offset, texto, attr);
        }
            
    }
    
    //Este metodo sirve cuando se reemplaza texto, cuando se pega texto, o cuando se borra y se escribe
    @Override
    public void replace(DocumentFilter.FilterBypass fb, int offset, int leght, String texto,AttributeSet attr)
        throws BadLocationException{
        
            // esto valida si el texto ingresado cumple lo siguiente:         
            // caracteres del 0 al 9 y el punto
            // el * Sirve para dejar que se escriba 0 o mas caracteres
            if(texto.matches("[A-Za-z ]*")){
                //Aqui se autoriza el reemplazo
                super.replace(fb, offset, leght, texto, attr);
            }
        }
}
