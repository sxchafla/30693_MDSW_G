
package GUI;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;


public class Eventos_Tabla {
    
    public void ordenar_filtar(DefaultTableModel modelo, JTable tabla, JTextField cajaTexto, int columna){
        //El TableRowSorter<> se encarga de ordenar, filtrar y cambiar el orden de lass filas dentro de la tabla
        TableRowSorter<DefaultTableModel> filtro = new TableRowSorter<>(modelo);
        //Aqui hacemos la coneccion con la tabla, aqui la tabla obedecera al filtro (sorter)/
        tabla.setRowSorter(filtro);  
        
        //Aqui le asignamos en KeyListener donde escucha eventos del teclado
        //El KeyAdapter evita utilizar los 3 metodos del KerListeer, solo se usa el que necesita
         cajaTexto.addKeyListener(new KeyAdapter(){
             //este metodo se ejecuta cuando la tecla se suelta, bueno para en tiempo real
             @Override
             public void keyReleased(KeyEvent e){
                 //Se obtiene lo ingresado en la caja
                 String palabra = cajaTexto.getText();
                 //
                 if(palabra.length() == 0){
                   filtro.setRowFilter(null);
                 }else{
                     //El rowFilter define que filas pasan y que filas no
                     //El regexFilter usa la cedula para filtrar y encontrar coincidencias, y el cero es la columna
                     filtro.setRowFilter(RowFilter.regexFilter("(?i)" + java.util.regex.Pattern.quote(palabra), columna));
                 }
             }
         });
    }
    
    
    public void ordenar_filtar_2(DefaultTableModel modelo, JTable tabla, JTextField cajaTexto, JTextField cajaTexto2, int columna, int columna2){
        //El TableRowSorter<> se encarga de ordenar, filtrar y cambiar el orden de lass filas dentro de la tabla
        TableRowSorter<DefaultTableModel> filtro = new TableRowSorter<>(modelo);
        //Aqui hacemos la coneccion con la tabla, aqui la tabla obedecera al filtro (sorter)/
        tabla.setRowSorter(filtro);  
        
        //Aqui le asignamos en KeyListener donde escucha eventos del teclado
        //El KeyAdapter evita utilizar los 3 metodos del KerListeer, solo se usa el que necesita
         cajaTexto.addKeyListener(new KeyAdapter(){
             //este metodo se ejecuta cuando la tecla se suelta, bueno para en tiempo real
             @Override
             public void keyReleased(KeyEvent e){
                 //Se obtiene lo ingresado en la caja
                 String palabra = cajaTexto.getText();
                 //
                 if(palabra.length() == 0){
                   filtro.setRowFilter(null);
                 }else{
                     //El rowFilter define que filas pasan y que filas no
                     //El regexFilter usa la cedula para filtrar y encontrar coincidencias, y el cero es la columna
                     filtro.setRowFilter(RowFilter.regexFilter("(?i)" + java.util.regex.Pattern.quote(palabra), columna));
                 }
             }
         });
          cajaTexto2.addKeyListener(new KeyAdapter(){
             //este metodo se ejecuta cuando la tecla se suelta, bueno para en tiempo real
             @Override
             public void keyReleased(KeyEvent e){
                 //Se obtiene lo ingresado en la caja
                 String palabra = cajaTexto2.getText();
                 //
                 if(palabra.length() == 0){
                   filtro.setRowFilter(null);
                 }else{
                     //El rowFilter define que filas pasan y que filas no
                     //El regexFilter usa la cedula para filtrar y encontrar coincidencias, y el cero es la columna
                     filtro.setRowFilter(RowFilter.regexFilter("(?i)" + java.util.regex.Pattern.quote(palabra), columna2));
                 }
             }
         });
    }
     /*  public void obtenerProducto(JTable tabla, DetalleFactura d, Vista_Venta vista, Factura factura){
        // Aqui le agrego un evento que escurche el clik del mouse
        tabla.addMouseListener(new MouseAdapter(){
            //Este metodo se va a ejecutar cuando haga click
            //El mouse event tiene todas las funciones del clickeo
            @Override
            public void mouseClicked( MouseEvent e){
                if(e.getClickCount() == 1 ){
                    
                    Vista_Venta ventas = new Vista_Venta(factura);
                    ventas.setNombreProducto(d.getNombreProducto());
                    ventas.setCantidadProducto(String.valueOf(d.getCantidad()));
                    ventas.setPrecioProducto(String.valueOf(d.getPrecioUnitario()));
                    ventas.setNombreCategoria(d.getNombreCategoria());
                    ventas.setVisible(true);
                    vista.dispose();
                }
            }
        });
       }*/
    
}
