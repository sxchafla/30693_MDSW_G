
package GUI;

import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;


public class Filtro_ParaFechas extends DocumentFilter{
    
      @Override
    public void insertString(DocumentFilter.FilterBypass fb, int offset, String texto, AttributeSet attr) 
            // se utiliza esa Exception si se intenta excribir algo fuera de lo requerido
            throws BadLocationException{

            // esto valida si el texto ingresado cumple lo siguiente:         
            // caracteres del 0 al 9 y el punto
            // el + Sirve para dejar que se escriba 1 o mas caracteres
            if(texto.matches("[0-9/]+")){
                // Aqui se permite que el texto ingrese 
                super.insertString(fb, offset, texto, attr);
        }
            
    }
    
    //Este metodo sirve cuando se reemplaza texto, cuando se pega texto, o cuando se borra y se escribe
    @Override
    public void replace(DocumentFilter.FilterBypass fb, int offset, int leght, String texto,AttributeSet attr)
        throws BadLocationException{
        
            // esto valida si el texto ingresado cumple lo siguiente:         
            // caracteres del 0 al 9 y el punto
            // el * Sirve para dejar que se escriba 0 o mas caracteres
            if(texto.matches("[0-9/]*")){
                //Aqui se autoriza el reemplazo
                super.replace(fb, offset, leght, texto, attr);
            }
        }
}
