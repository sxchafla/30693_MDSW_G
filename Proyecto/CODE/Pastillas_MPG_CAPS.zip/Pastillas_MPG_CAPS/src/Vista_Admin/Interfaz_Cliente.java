
package Vista_Admin;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JTextField;


public interface Interfaz_Cliente {
    
    JTextField getFiltroCedula();
    
    String getNombreCliente();
    String getCedulaCliente();
    String getApellidoCliente();
    String getNumeroTelefonicoCliente();
    String getCorreoCliente();
    String getDireccionCliente();
    
    void setNombreCliente(String m);
    void setCedulaCliente(String m);
    void setApellidoCliente(String m);
    void setNumeroTelefonicoCliente(String m);
    void setCorreoCliente(String m);
    void setDireccionCliente(String m);
    
    /*JTextField getCajaNombre();
    JTextField getCajaCedula();
    JTextField getCajaApellido();
    JTextField getCajaNumeroTelefonico();
    JTextField getCajaCorreo();
    JTextField getCajaDireccion();
    */
    void getLimpiarCliente();
    void getMensaje(String mensaje);
    int  getMensajeConfirmacion(String m);
    
    JButton getGuardarCliente();
    JButton getRegresarCliente();
    JButton getEditarCliente();
    JButton getEliminarCliente();
    
    JTable getTablaCliente();
}
