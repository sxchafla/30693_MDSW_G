package Vista_Admin;

import javax.swing.JButton;

/**
 *
 * @author SEBAS
 */
public interface Interfaz_Vista_Admin {
    public JButton btn_gestionarProductos();
    public JButton btn_gestionarClientes();
    public JButton btn_verReportes();
         
}
