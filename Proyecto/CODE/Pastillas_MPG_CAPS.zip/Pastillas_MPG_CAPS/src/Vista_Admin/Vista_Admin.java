/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vista_Admin;

import Controlador_Admin.Controlador_Admin;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.nio.file.Paths;

/**
 *
 * @author javie
 */
public class Vista_Admin extends javax.swing.JFrame implements Interfaz_Vista_Admin{

    /**
     * Creates new form Vista_Admin
     */
    public Vista_Admin() {
        initComponents();
        new Controlador_Admin(this);
        setLocationRelativeTo(null);
        setResizable(false);
    }

    @Override
    public JButton btn_gestionarProductos(){
        return btn_GestionarProductos;
    }
    
    @Override
    public JButton btn_gestionarClientes(){
        return btn_GestionarClientes;
    }
  
    @Override
    public JButton btn_verReportes(){
        return boton_Reportes;
    }
    
    public static class JPanelConFondo extends javax.swing.JPanel {
        private Image fondo;
        
        public JPanelConFondo(String rutaImagen) {
            try {
                java.io.File imagenFile = new java.io.File(rutaImagen);
                if (!imagenFile.exists()) {
                    // Intentar desde build/classes
                    imagenFile = new java.io.File("build/classes/Imagenes/" + java.nio.file.Paths.get(rutaImagen).getFileName());
                }
                if (imagenFile.exists()) {
                    ImageIcon imagen = new ImageIcon(imagenFile.getAbsolutePath());
                    fondo = imagen.getImage();
                } else {
                    System.err.println("Imagen no encontrada: " + rutaImagen);
                }
            } catch (Exception e) {
                System.err.println("Error al cargar la imagen: " + e.getMessage());
            }
        }
        
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (fondo != null) {
                g.drawImage(fondo, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btn_GestionarProductos = new javax.swing.JButton();
        btn_GestionarClientes = new javax.swing.JButton();
        boton_Reportes = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(51, 51, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI Semibold", 3, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("INTERFAZ DEL ADMINISTRADOR");
        jLabel1.setOpaque(true);
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 720, -1));

        btn_GestionarProductos.setText("Gestionar Producto");
        jPanel1.add(btn_GestionarProductos, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 140, -1, -1));

        btn_GestionarClientes.setText("Gestionar Cliente");
        jPanel1.add(btn_GestionarClientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 140, -1, -1));

        boton_Reportes.setText("Ver reportes de ventas");
        jPanel1.add(boton_Reportes, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 270, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 412, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton boton_Reportes;
    private javax.swing.JButton btn_GestionarClientes;
    private javax.swing.JButton btn_GestionarProductos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
