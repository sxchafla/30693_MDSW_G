
package Vista_Admin;

import javax.swing.JButton;

/**
 *
 * @author User
 */
public interface Interfaz_Detalle {


    // Métodos básicos de control
    void iniciar();

    void cerrar();

    JButton getBotonRegresar();

 

    public void setContenidoHTML(String html);
}
