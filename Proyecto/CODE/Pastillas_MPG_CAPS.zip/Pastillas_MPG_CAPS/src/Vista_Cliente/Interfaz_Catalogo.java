
package Vista_Cliente;

import javax.swing.JButton;


public interface Interfaz_Catalogo {
    
    /*JButton botonAgregar1();
    JButton botonAgregar2();
    JButton botonAgregar3();*/
    JButton botonDetalle();
    JButton botonHistorial();
   /* String cajaCantidad1();
    String cajaCantidad2();
    String cajaCantidad3();*/
   
    // End of variables declaration             
}
