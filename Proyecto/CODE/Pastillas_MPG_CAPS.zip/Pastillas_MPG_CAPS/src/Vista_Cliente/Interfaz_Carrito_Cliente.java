/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Vista_Cliente;

/**
 *
 * @author javie
 */
public interface Interfaz_Carrito_Cliente {
    
}
