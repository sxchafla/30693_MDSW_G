
package Vista_Cliente;

import javax.swing.JButton;

/**
 *
 * @author User
 */
public interface Interfaz_Previsualizar {

    //con este boton generamos la factura y limpia los datos para una nueva factura
    JButton getNuevaFactura();

    //regresar por si los datos del clientes estan mal para modificarlos
    JButton getRegresar();

    int getMensajeOpcion(String n);
    void getMensaje(String m);
    
    public void setContenidoHTML(String html);

}
