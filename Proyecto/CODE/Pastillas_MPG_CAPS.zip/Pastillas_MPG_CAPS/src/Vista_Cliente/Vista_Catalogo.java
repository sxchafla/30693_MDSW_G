
package Vista_Cliente;

import Controlador_Cliente.Controlador_Catalogo;
import Modelo.Factura;
import Modelo.Repositorio_Producto;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author javie
 */
public class Vista_Catalogo extends javax.swing.JFrame implements Interfaz_Catalogo{

    Factura factura;

    
    public Vista_Catalogo(String correo, Factura factura, Repositorio_Producto productos) {
        initComponents();
        this.factura = factura;
        this.setLocationRelativeTo(null);
        new Controlador_Catalogo(this, factura,correo,productos);
        
    }

    
    public JPanel panelCatalogo(){
        return panelCatalogo;
    }
    
    
    public void getMensaje(String m){
        JOptionPane.showMessageDialog(this, m);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        botonDetalle = new javax.swing.JButton();
        botonHistorial = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        panelCatalogo = new javax.swing.JPanel();
        boton_Comprar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        botonDetalle.setText("Detalle Compra");

        botonHistorial.setText("Ver historial de compra");

        panelCatalogo.setLayout(new java.awt.GridLayout(1, 3));
        jScrollPane1.setViewportView(panelCatalogo);

        boton_Comprar.setText("Comprar");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(303, Short.MAX_VALUE)
                .addComponent(botonHistorial)
                .addGap(18, 18, 18)
                .addComponent(botonDetalle)
                .addGap(48, 48, 48)
                .addComponent(boton_Comprar)
                .addGap(28, 28, 28))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonDetalle)
                    .addComponent(botonHistorial)
                    .addComponent(boton_Comprar))
                .addGap(43, 43, 43)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 460, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
 /*   @Override
    public JButton botonAgregar1(){
    return botonAgregar1;
};

    @Override
    public JButton botonAgregar2(){
    return botonAgregar2;
};

    @Override
    public JButton botonAgregar3(){
    return botonAgregar3;
};
*/
    @Override
    public JButton botonDetalle(){
    return botonDetalle;
};

     @Override
    public JButton botonHistorial(){
    return botonHistorial;
};
    
    public JButton botonComprar(){
    return boton_Comprar;
};
    
  /*  
    @Override
    public String cajaCantidad1(){
    return cajaCantidad1.getText();
};

    @Override
    public String cajaCantidad2(){
    return cajaCantidad2.getText();
};

    @Override
    public String cajaCantidad3(){
    return cajaCantidad3.getText();
};
    
    @Override
    public JButton botonHistorial(){
    return botonHistorial;
};*/

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonDetalle;
    private javax.swing.JButton botonHistorial;
    private javax.swing.JButton boton_Comprar;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel panelCatalogo;
    // End of variables declaration//GEN-END:variables
}
