
package Vista_Cliente;


public interface Interfaz_Registro_Compras {
    
}
