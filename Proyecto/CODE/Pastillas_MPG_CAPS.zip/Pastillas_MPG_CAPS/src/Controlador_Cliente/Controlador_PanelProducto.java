
package Controlador_Cliente;

import Modelo.DetalleFactura;
import Modelo.Factura;
import Modelo.Producto;
import Vista_Cliente.PanelProducto;
import java.util.ArrayList;


public class Controlador_PanelProducto {
    
    Factura factura;
    PanelProducto vista;
    DetalleFactura detalle;
    Producto producto;

    public Controlador_PanelProducto(Factura factura, PanelProducto vista, Producto p) {
        this.factura = factura;
        this.vista = vista;
        this.vista.botonAgregar().addActionListener(e -> agregar());
 
        producto = p;
    }
    
    
    public void agregar(){
        try{
            String cantidad_ingresada = vista.getCantidad();
            if(cantidad_ingresada.isEmpty()){
                vista.getMensaje("Ingrese la cantidad por favor");
                return;
            }
            int cantidad = Integer.parseInt(cantidad_ingresada);
            if(cantidad == 0){
                vista.getMensaje("Ingrese una cantidad mayor a 0 por favor");
                vista.limpiarCaja();
                return;
            }
            
            if(cantidad < 0){
                vista.getMensaje("Ingrese una cantidad mayor a 0 por favor");
                vista.limpiarCaja();
                return;
            }
            
            if(cantidad > producto.getCantidad()){
                vista.getMensaje("Stock insuficiente");
                return;
            }
        
            
            if(factura.getDetalle().isEmpty()){
                detalle = new DetalleFactura(producto.getNombre(),cantidad,producto.getPrecioUnitario());
                    factura.agregarDetalle(detalle);
                    producto.reducirStock(cantidad);
                    vista.getMensaje("Producto añadido al carrito");
                    vista.mostrarTextos(producto.getNombre(), producto.getPrecioUnitario(), producto.getCantidad());
                    vista.limpiarCaja();
                    System.out.println("Que mas ve");
                    return;
            }
            
            /*vista.mostrarTextos(producto.getNombre(), producto.getPrecioUnitario(), producto.getCantidad());
            vista.getMensaje("Producto añadido al carrito");
            vista.limpiarCaja();*/
            for(DetalleFactura d: factura.getDetalle()){
                
                if(d.getNombreProducto().equals(producto.getNombre())){
                    d.aumentarCantidad(cantidad);
                    vista.getMensaje("Producto añadido al carrito");
                    producto.reducirStock(cantidad);
                    vista.mostrarTextos(producto.getNombre(), producto.getPrecioUnitario(), producto.getCantidad());
                    vista.limpiarCaja();
                    System.out.println("Hola chucha");
                    return;
                }
                     
            }
            
            detalle = new DetalleFactura(producto.getNombre(),cantidad,producto.getPrecioUnitario());
            factura.agregarDetalle(detalle);
            producto.reducirStock(cantidad);
            vista.mostrarTextos(producto.getNombre(), producto.getPrecioUnitario(), producto.getCantidad());
            vista.getMensaje("Producto añadido al carrito");
            vista.limpiarCaja();
            System.out.println("Zorro");
    
        } catch (NumberFormatException e){
            vista.getMensaje("Ingrese una cantidad valida por favor");
            vista.limpiarCaja();
        }
    }
}
    
   

