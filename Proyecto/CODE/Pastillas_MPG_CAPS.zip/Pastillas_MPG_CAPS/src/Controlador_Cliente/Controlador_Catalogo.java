
package Controlador_Cliente;
import Modelo.Crear_PDF;
import Modelo.Factura;
import Modelo.Producto;
import Vista_Cliente.Vista_Catalogo;
import Vista_Cliente.Vista_Previsualizar;
import Modelo.Repositorio_Producto;
import Modelo.Repositorio_Clientes;
import Modelo.Repositorio_Facturas;
import Vista_Cliente.PanelProducto;
import Vista_Cliente.Vista_DetalleCompra;
import Vista_Cliente.Vista_Historial;
import java.util.ArrayList;



public class Controlador_Catalogo {
    Vista_Catalogo vista;
    Repositorio_Producto repositorio_producto;
    Repositorio_Clientes clientes = new Repositorio_Clientes();
    Factura factura;

    Repositorio_Facturas repositorio_facturas;

    public Controlador_Catalogo(Vista_Catalogo catalogo, Factura factura,String correo,Repositorio_Producto productos) {
        this.factura = factura;
        this.factura.setDatos_cliente(clientes.datosCliente(correo));
        this.vista = catalogo;
        vista.botonDetalle().addActionListener(e -> mostrarDetalle(correo));
        vista.botonHistorial().addActionListener(e -> verHistorial(correo));
        vista.botonComprar().addActionListener(e -> comprar());
        repositorio_facturas = new Repositorio_Facturas(factura);
        this.repositorio_producto = productos;
        crearCatalogo(repositorio_producto.getLista());
        
    }
    
    public Controlador_Catalogo(Factura factura){
        this.factura = factura;
    }
    
    
    public void crearCatalogo(ArrayList<Producto> lista_producto){
        vista.panelCatalogo().removeAll();
        for(Producto p: lista_producto){
            PanelProducto panel  = new PanelProducto(factura,p);
            vista.panelCatalogo().add(panel);
        }
        vista.panelCatalogo().revalidate();
        vista.panelCatalogo().repaint();
    }
    
    public void mostrarDetalle(String correo){
        /*Vista_Previsualizar previsualizar = new Vista_Previsualizar(factura);
        previsualizar.setVisible(true);*/
        /*if(factura.getDetalle().isEmpty()){
            vista.getMensaje("Ingrese un producto por favor");
            return;
        }*/
        Vista_DetalleCompra detalle = new Vista_DetalleCompra(factura,repositorio_producto,correo);
        detalle.setVisible(true);
        vista.dispose();
    }
    
    public void verHistorial(String correo){
        
        Vista_Historial historial = new Vista_Historial(correo);
        historial.setVisible(true);
        
    }
    
    public void comprar(){
        
        if(factura.getDetalle().isEmpty()){
            vista.getMensaje("Por favor ingrese un producto");
            return;
        }
        Vista_Previsualizar previsualizar = new Vista_Previsualizar(factura);
        previsualizar.setVisible(true);
        
    }
    
}
