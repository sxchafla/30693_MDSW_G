package Controlador_Cliente;

import Controlador_Admin.*;
import Modelo.Repositorio_Reporte_Facturas;
import Vista_Cliente.Vista_Reporte_Detalle_Cliente;
import java.io.File;
import java.io.FileOutputStream;
import org.bson.Document;
import java.util.List;
import javax.swing.JFileChooser;
import org.bson.types.Binary;
import java.text.DecimalFormat;

public class Controlador_Reporte_Detalle_Cliente {

    private Vista_Reporte_Detalle_Cliente vista;
    private Repositorio_Reporte_Facturas repositorio = new Repositorio_Reporte_Facturas();

    public Controlador_Reporte_Detalle_Cliente(Vista_Reporte_Detalle_Cliente vista, String numeroFactura) {
        this.vista = vista;

        // Listeners
        this.vista.getBotonRegresar().addActionListener(e -> this.vista.cerrar());
        

        // IMPORTANTE: Cargar los datos visualmente al iniciar
        mostrarDetalleHTML(numeroFactura);
    }

    // --- NUEVO MÉTODO CON HTML (Reemplaza al anterior) ---
    // --- MÉTODO CORREGIDO CON IVA ---
    public void mostrarDetalleHTML(String numeroFactura) {
        // 1. Buscar en BD
        org.bson.Document doc = repositorio.buscarFacturaPorNumero(numeroFactura);

        if (doc == null) {
            return;
        }

        java.text.DecimalFormat df = new java.text.DecimalFormat("$ #,##0.00");
        StringBuilder html = new StringBuilder();

        // Colores
        String colorCeleste = "#3399FF";
        String grisFondo = "#f5f5f5";

        html.append("<html>");
        html.append("<body style='font-family: Sans-serif; font-size: 11px; color: #333; margin:0; padding:5px;'>");

        // 1. ENCABEZADO
        html.append("<table width='100%' cellpadding='5' cellspacing='0' bgcolor='").append(colorCeleste).append("'>");
        html.append("<tr>");
        html.append("  <td width='70%'><b style='color: white; font-size: 14px;'>DETALLE DE FACTURA</b></td>");
        html.append("  <td width='30%' align='right'><b style='color: white;'>").append(doc.getString("Numero de factura")).append("</b></td>");
        html.append("</tr>");
        html.append("</table>");

        // 2. DATOS DEL CLIENTE
        html.append("<div style='padding: 10px; background-color: #f9f9f9;'>");
        html.append("  <table width='100%' cellpadding='2'>");
        html.append("    <tr><td><b>Fecha:</b></td><td>").append(doc.getString("Fecha")).append("</td></tr>");
        html.append("    <tr><td><b>Cliente:</b></td><td>").append(doc.getString("Nombres cliente")).append(" ").append(doc.getString("Apellidos cliente")).append("</td></tr>");
        html.append("    <tr><td><b>Cédula:</b></td><td>").append(doc.getString("Cedula")).append("</td></tr>");
        String dir = doc.getString("Direccion") != null ? doc.getString("Direccion") : "Sin dirección";
        html.append("    <tr><td><b>Dirección:</b></td><td>").append(dir).append("</td></tr>");
        html.append("  </table>");
        html.append("</div>");

        // 3. TABLA DE PRODUCTOS
        html.append("<br><b style='color: #555; font-size: 12px;'>PRODUCTOS:</b>");
        html.append("<table width='100%' cellpadding='3' cellspacing='0' border='1' style='border-collapse: collapse; border-color: #ccc;'>");

        html.append("<tr bgcolor='#eee'>");
        html.append("  <th width='15%'>Cant.</th>");
        html.append("  <th width='60%'>Descripción</th>");
        html.append("  <th width='25%'>Total</th>");
        html.append("</tr>");

        java.util.List<org.bson.Document> productos = (java.util.List<org.bson.Document>) doc.get("Detalles productos");
        if (productos != null) {
            for (org.bson.Document prod : productos) {
                html.append("<tr>");
                html.append("  <td align='center'>").append(prod.get("Cantidad solicitada")).append("</td>");
                html.append("  <td style='padding-left:5px;'>").append(prod.getString("Nombre producto")).append("</td>");

                try {
                    Double precio = prod.getDouble("Precio semitotal");
                    html.append("  <td align='right'>").append(df.format(precio)).append("</td>");
                } catch (Exception e) {
                    html.append("  <td align='right'>").append(prod.get("Precio semitotal")).append("</td>");
                }
                html.append("</tr>");
            }
        }
        html.append("</table>");

        // 4. TOTALES (AQUÍ ESTÁ EL IVA AGREGADO)
        html.append("<br><table width='100%' cellpadding='4' cellspacing='0'>");

        // --- SUBTOTAL ---
        html.append("<tr>");
        html.append("  <td align='right' width='70%'>Subtotal:</td>");
        try {
            html.append("  <td align='right' width='30%'>").append(df.format(doc.getDouble("Subtotal"))).append("</td>");
        } catch (Exception e) {
            html.append("  <td align='right' width='30%'>$ ").append(doc.get("Subtotal")).append("</td>");
        }
        html.append("</tr>");

        // --- IVA (CALCULADO O RECUPERADO) ---
        // Opción A: Si guardaste el IVA en Mongo, úsalo: doc.getDouble("IVA")
        // Opción B: Si no, lo calculamos aquí restando Total - Subtotal
        double total = 0.0;
        double subtotal = 0.0;
        double iva = 0.0;
        try {
            total = doc.getDouble("Total");
            subtotal = doc.getDouble("Subtotal");
            iva = total - subtotal; // Calculamos la diferencia
        } catch (Exception e) {
            iva = 0.0;
        }

        html.append("<tr>");
        html.append("  <td align='right' width='70%'>IVA (15%):</td>");
        html.append("  <td align='right' width='30%'>").append(df.format(iva)).append("</td>");
        html.append("</tr>");

        // --- TOTAL FINAL ---
        html.append("<tr bgcolor='").append(colorCeleste).append("' style='color:white;'>");
        html.append("  <td align='right' width='70%'><b>TOTAL PAGADO:</b></td>");
        html.append("  <td align='right' width='30%'><b>").append(df.format(total)).append("</b></td>");
        html.append("</tr>");

        html.append("</table>");

        html.append("</body></html>");

        // ENVIAR A LA VISTA
        vista.setContenidoHTML(html.toString());
    }

    // en este metodo lo que hace es recoger el pdf y poder descargarlo en una carpeta asi bien arrecha
    
}
