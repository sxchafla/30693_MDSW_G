
package Vista_Login;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 *
 * @author javie
 */
public class Vista_Login extends javax.swing.JFrame implements Interfaz_Login{

  
    public Vista_Login() {
        initComponents();
        //Aqui llamamos al contructor de login
        new Controlador_Login.Controlador_Login(this);
        //Esto es para accionar el boton al darle enter
        this.getRootPane().setDefaultButton(boton_Ingresar);
        setLocationRelativeTo(null);
        setResizable(false);
        configurarBotones(boton_Ingresar, new Color(214,91,14), new Color(214,80,10));
        configurarBotones(boton_Registrar, new Color(214,91,14), new Color(214,80,10));
    }
  /*  
    @Override
public void setVisible(boolean visible) {
    // 1. Primero le decimos a Java: "Dibuja la ventana en la pantalla"
    super.setVisible(visible); 
    
    // 2. Una vez dibujada, la ventana ya sabe cuánto mide el JLabel
    if (visible) { 
        // ¡Aquí activamos la magia! Cambia 'lblFotoLogin' por el nombre de tu variable JLabel
        adaptarImagen(lblImagen, "/Imagenes/logo3MGPCAPS.png"); 
    }
}
    */
    //Todos estos metodos se los llaman y utilizan en el contructor de login

    // Devuelve el texto de la caja usuario
    @Override
  public String cajaUsuario(){
      return cajaUsuario.getText();
  }
  
  // Devuelve el texto de la caja contrasenia
    @Override
  public String cajaContrasenia(){
      return cajaContrasenia.getText();
  }
    
  // Devuelve el boton ingresar
    @Override
  public JButton boton_Ingresar(){
      return boton_Ingresar;
  }
  
      @Override
  public JButton boton_Registrar(){
      return boton_Registrar;
  }
  
    @Override
  public void estadoBoton_Ingresar(boolean estado){
      boton_Ingresar.setEnabled(estado);
  }
  
  // Limpia las cajas de texto
    @Override
  public void limpiar(){
      cajaContrasenia.setText("");
      cajaUsuario.setText("");
  }
  
  // Muestra un mensaje en el JFrame
    @Override
  public void mostrarMensaje(String mensaje){
      JOptionPane.showMessageDialog(this, mensaje);
  }
  
  //public void setControlador()      
  
  // Este método toma tu JLabel, mide su tamaño real y estira la imagen para que encaje
public void adaptarImagen(javax.swing.JLabel label, String rutaImagen) {
    try {
        // 1. Carga la imagen desde tus carpetas
        java.net.URL url = getClass().getResource(rutaImagen);
        if (url != null) {
            javax.swing.ImageIcon iconoOriginal = new javax.swing.ImageIcon(url);
            
            // 2. Toma el tamaño REAL del JLabel en ese instante y ajusta la imagen
            java.awt.Image imagenEscalada = iconoOriginal.getImage().getScaledInstance(
                label.getWidth(), 
                label.getHeight(), 
                java.awt.Image.SCALE_SMOOTH
            );
            
            // 3. Le pone la imagen ya estirada al JLabel
            label.setIcon(new javax.swing.ImageIcon(imagenEscalada));
        } else {
            System.err.println("No se encontró la imagen en la ruta: " + rutaImagen);
        }
    } catch (Exception e) {
        System.err.println("Error al cargar la imagen: " + e.getMessage());
    }
}

   private void configurarBotones(JButton boton, Color normal, Color especial) {

        //Quita el borde cuando le haces click
        boton.setFocusPainted(false);
        //Eliminar el brode 3d
        boton.setBorderPainted(false);
        //Quita el relieve interno
        boton.setContentAreaFilled(false);
        //Permite pintar el fondo
        boton.setOpaque(true);
        //Pinta el fondo
        boton.setBackground(especial);
        //Pinta el texto
        boton.setForeground(Color.WHITE);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(especial);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                boton.setBackground(normal);
            }
        });
      }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        cajaContrasenia = new javax.swing.JTextField();
        cajaUsuario = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        boton_Ingresar = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        boton_Registrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(247, 251, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cajaContrasenia.setBorder(null);
        jPanel1.add(cajaContrasenia, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 460, 140, -1));

        cajaUsuario.setBorder(null);
        cajaUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cajaUsuarioActionPerformed(evt);
            }
        });
        jPanel1.add(cajaUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 420, 140, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel1.setText("Contraseña:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 460, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel2.setText("Usuario:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 420, -1, -1));

        boton_Ingresar.setText("Ingresar");
        jPanel1.add(boton_Ingresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 520, -1, -1));

        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 480, 140, 10));

        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 440, 140, 10));

        boton_Registrar.setText("Registrar");
        jPanel1.add(boton_Registrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 520, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 677, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 566, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cajaUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cajaUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cajaUsuarioActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton boton_Ingresar;
    private javax.swing.JButton boton_Registrar;
    private javax.swing.JTextField cajaContrasenia;
    private javax.swing.JTextField cajaUsuario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    // End of variables declaration//GEN-END:variables

    
}
