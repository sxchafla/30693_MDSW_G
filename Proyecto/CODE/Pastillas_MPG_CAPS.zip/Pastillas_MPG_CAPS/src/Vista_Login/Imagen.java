
package Vista_Login;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Imagen {
    
public void setImagenAdaptada(JLabel label, String rutaPorDefecto) {
    // 1. Cargamos la imagen desde los recursos del proyecto
    ImageIcon iconoOriginal = new ImageIcon(getClass().getResource(""));
    
    // 2. Extraemos el objeto Image para poder manipularlo
    Image imagenOriginal = iconoOriginal.getImage();
    
    // 3. Escalamos la imagen usando el ancho y alto ACTUAL del JLabel
    // Usamos SCALE_SMOOTH para que no pierda calidad (antialiasing)
    Image imagenEscalada = imagenOriginal.getScaledInstance(
        label.getWidth(), 
        label.getHeight(), 
        Image.SCALE_SMOOTH
    );
    
    // 4. Creamos el nuevo icono con la imagen escalada y se lo pasamos al label
    ImageIcon iconoEscalado = new ImageIcon(imagenEscalada);
    label.setIcon(iconoEscalado);
}
}
