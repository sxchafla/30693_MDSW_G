
package Vista_Login;

import java.awt.event.ActionListener;
import javax.swing.JButton;

//Esta interfaz funciona como un contrato con el JFrame, es como una clase abstracta
//Cualquier cosa que quieran aniadir a la vista login lo hacen primero aqui
// El jFrame de la vista login es como una clase hija para esta interfaz
public interface Interfaz_Login {
    
    //Todos estos metodos son metodos abstractos para utilizarlos en el Jframe de Login
    String cajaUsuario();
    String cajaContrasenia();
    
    JButton boton_Ingresar();
    JButton boton_Registrar();
    
    //Metodo para bloquear el boton
    void estadoBoton_Ingresar(boolean estado);
    //
    //void setControlador(ActionListener action);
    
    void limpiar();
    void mostrarMensaje(String mensaje);
    
    //Etiqueta fija
    String ACCION_LOGIN = "Iniciar sesion";
}
