
package Controlador_Cliente;
import Modelo.Crear_PDF;
import Modelo.Factura;
import Modelo.Producto;
import Vista_Cliente.Vista_Catalogo;
import Vista_Cliente.Vista_Previsualizar;
import Modelo.Repositorio_Producto;
import Modelo.Repositorio_Clientes;
import Modelo.Repositorio_Facturas;
import Vista_Cliente.PanelProducto;
import Vista_Cliente.Vista_DetalleCompra;
import Vista_Cliente.Vista_Historial;
import java.util.ArrayList;



public class Controlador_Catalogo {
    Vista_Catalogo vista;
    Repositorio_Producto repositorio_producto;
    Repositorio_Clientes clientes = new Repositorio_Clientes();
    Factura factura;

    //Repositorio_Facturas repositorio_facturas;

    public Controlador_Catalogo(Vista_Catalogo catalogo, Factura factura,String correo,Repositorio_Producto productos) {
        this.factura = factura;
        this.factura.setDatos_cliente(clientes.datosCliente(correo));
        this.vista = catalogo;
        vista.botonDetalle().addActionListener(e -> mostrarDetalle(correo));
        vista.botonHistorial().addActionListener(e -> verHistorial(correo));
        vista.botonComprar().addActionListener(e -> comprar());
        this.repositorio_producto = productos;
        crearCatalogo(repositorio_producto.getLista());
        
    }
    
    public void crearCatalogo(ArrayList<Producto> lista_producto){
        vista.panelCatalogo().removeAll();
        for(Producto p: lista_producto){
            PanelProducto panel  = new PanelProducto(factura,p);
            vista.panelCatalogo().add(panel);
            
        }
        vista.panelCatalogo().revalidate();
        vista.panelCatalogo().repaint();
    }
    
    public void mostrarDetalle(String correo){
        
       Vista_DetalleCompra detalle = new Vista_DetalleCompra(factura,repositorio_producto,correo);
        detalle.setVisible(true);
        vista.dispose();
 
    }
    
    
    public void verHistorial(String correo){
        
        Vista_Historial historial = new Vista_Historial(correo);
        historial.setVisible(true);
        
    }
    
    public void comprar(){
        
        if(factura.getDetalle().isEmpty()){
            vista.getMensaje("Por favor ingrese un producto");
            return;
        }
        
        Vista_Previsualizar previsualizar = new Vista_Previsualizar(factura);
        previsualizar.setVisible(true);
            // 1. Deshabilitamos el botón temporalmente para que no le den mil clics mientras carga
  /*  vista.botonComprar().setEnabled(false);

    // 2. Creamos un hilo secundario para hacer el viaje a internet y armar el HTML
    Thread hiloCompra = new Thread(() -> {
        try {
            // Creamos la vista de previsualización (oculta por ahora)
            Vista_Previsualizar vistaPrev= new Vista_Previsualizar(factura);
            
            // 🔥 AQUÍ PASA LA MAGIA: El constructor viaja a Mongo Atlas y genera el HTML en segundo plano
            Controlador_Previsualizar controladorPrev = new Controlador_Previsualizar(vistaPrev, this.factura);
            
            // 3. Cuando termina todo el proceso pesado, volvemos al hilo principal para mostrar la ventana
            java.awt.EventQueue.invokeLater(() -> {
                vistaPrev.setVisible(true); // Muestra la factura bonita ya cargada
                vista.botonComprar().setEnabled(true); // Reactivamos el botón del catálogo
                // Si quieres cerrar el catálogo al comprar, descomenta la línea de abajo:
                // vista.dispose(); 
            });

        } catch (Exception ex) {
            ex.printStackTrace();
            java.awt.EventQueue.invokeLater(() -> vista.botonComprar().setEnabled(true));
        }
    });*/
        
    }
    
}
