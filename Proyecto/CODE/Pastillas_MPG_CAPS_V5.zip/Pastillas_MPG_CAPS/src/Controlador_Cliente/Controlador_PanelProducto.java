
package Controlador_Cliente;

import Modelo.ConvertirImagen;
import Modelo.DetalleFactura;
import Modelo.Factura;
import Modelo.Producto;
import Vista_Cliente.PanelProducto;
import java.util.ArrayList;
import javax.swing.ImageIcon;


public class Controlador_PanelProducto {
    
    ConvertirImagen convertirImagen = new ConvertirImagen();
    Factura factura;
    PanelProducto vista;
    DetalleFactura detalle;
    Producto producto;
    ImageIcon imagen = new ImageIcon();

    public Controlador_PanelProducto(Factura factura, PanelProducto vist, Producto p) {
        this.factura = factura;
        this.vista = vist;
        this.vista.botonAgregar().addActionListener(e -> agregar());
        producto = p;
        aniadirImagen(p);
    }
    
    //144,147
    public void agregar(){
        try{
            String cantidad_ingresada = vista.getCantidad();
            if(cantidad_ingresada.isEmpty()){
                vista.getMensaje("Ingrese la cantidad por favor");
                return;
            }
            int cantidad = Integer.parseInt(cantidad_ingresada);
            if(cantidad == 0){
                vista.getMensaje("Ingrese una cantidad mayor a 0 por favor");
                vista.limpiarCaja();
                return;
            }
            
            if(cantidad < 0){
                vista.getMensaje("Ingrese una cantidad mayor a 0 por favor");
                vista.limpiarCaja();
                return;
            }
            
            if(cantidad > producto.getCantidad()){
                vista.getMensaje("Stock insuficiente");
                return;
            }
        
            
            if(factura.getDetalle().isEmpty()){
                detalle = new DetalleFactura(producto.getNombre(),cantidad,producto.getPrecioUnitario());
                    factura.agregarDetalle(detalle);
                    producto.reducirStock(cantidad);
                    vista.getMensaje("Producto añadido al carrito");
                    vista.mostrarTextos(producto.getNombre(), producto.getPrecioUnitario(), producto.getCantidad());
                    vista.limpiarCaja();
   
                    return;
            }
            
            /*vista.mostrarTextos(producto.getNombre(), producto.getPrecioUnitario(), producto.getCantidad());
            vista.getMensaje("Producto añadido al carrito");
            vista.limpiarCaja();*/
            for(DetalleFactura d: factura.getDetalle()){
                
                if(d.getNombreProducto().equals(producto.getNombre())){
                    d.aumentarCantidad(cantidad);
                    vista.getMensaje("Producto añadido al carrito");
                    producto.reducirStock(cantidad);
                    vista.mostrarTextos(producto.getNombre(), producto.getPrecioUnitario(), producto.getCantidad());
                    vista.limpiarCaja();
                    
                    return;
                }
                     
            }
            
            detalle = new DetalleFactura(producto.getNombre(),cantidad,producto.getPrecioUnitario());
            factura.agregarDetalle(detalle);
            producto.reducirStock(cantidad);
            vista.mostrarTextos(producto.getNombre(), producto.getPrecioUnitario(), producto.getCantidad());
            vista.getMensaje("Producto añadido al carrito");
            vista.limpiarCaja();
         
        } catch (NumberFormatException e){
            vista.getMensaje("Ingrese una cantidad válida por favor");
            vista.limpiarCaja();
        }
    }
    
    public void aniadirImagen(Producto p){
        if (p.getImagen64() != null && !p.getImagen64().isEmpty()) {
        // Decodifica la cadena y ajusta el tamaño (ej: 120x120 píxeles, cámbialo según tu diseño)
        /*int anchoLabel = lblImagenProducto.getWidth() > 0 ? lblImagenProducto.getWidth() : 120;
        int altoLabel = lblImagenProducto.getHeight() > 0 ? lblImagenProducto.getHeight() : 120;*/
        
        ImageIcon fotoProducto = ConvertirImagen.decodificarAIcono(p.getImagen64(),179 , 164);
        if (fotoProducto != null) {
            vista.lblImagen().setText(""); // Quita cualquier texto por defecto
            vista.lblImagen().setIcon(fotoProducto); // Setea la imagen
        }
        } else {
            // Imagen por defecto (No-Image) si el producto se guardó sin foto
            vista.lblImagen().setText("Sin Foto");
            // O puedes setear un icono por defecto: lblImagenProducto.setIcon(new ImageIcon("src/icons/box.png"));
    }
        
    }
}

    
   

