package Controlador_Cliente;

import Modelo.Crear_PDF;
import Vista_Cliente.Vista_Previsualizar;
import Modelo.Factura;
import Modelo.DetalleFactura;
import Modelo.Repositorio_Facturas;
import Modelo.Repositorio_Producto;
import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public class Controlador_Previsualizar {

    private Vista_Previsualizar vista;
    //private Controlador_Catalogo controladorPrincipal_venta;
    private Factura factura;
    Repositorio_Facturas repositorio_facturas;
    Crear_PDF crearPDF;
    Repositorio_Producto repositorio_producto = new Repositorio_Producto();

    public Controlador_Previsualizar(Vista_Previsualizar vista, Factura factura) {
        this.vista = vista;
        this.factura = factura;
        repositorio_facturas = new Repositorio_Facturas(factura);
        crearPDF = new Crear_PDF();
        this.vista.getRegresar().addActionListener(e -> vista.dispose());
        this.vista.getNuevaFactura().addActionListener(e -> generarFactura());
        
        String numeroFactura = repositorio_facturas.generarCodigoFactura();
            factura.setIdFactura(numeroFactura);
            
        // Generar
        generarReporteHTML();
    }

    public void generarFactura() {
        //llamamos al metodo del controlador vente 
        //controladorPrincipal_venta.generarFactura();
        try {
                int confirmacion = JOptionPane.showConfirmDialog(vista,"Quiere realizar la compra?","",JOptionPane.YES_NO_OPTION);
                if(confirmacion == JOptionPane.YES_OPTION){
                   // 1. Preparar el ID (Esto debe ser lo primero)

                    // 2. GENERAR EL PDF PRIMERO (¡CRUCIAL!)
                    // Ahora el archivo existirá físicamente en la carpeta PDF
                    String rutaPdf = crearPDF.generarPDF(/*vista.getTabla(),*/ factura);

                    // 3. AHORA SÍ, Guardar en Base de Datos
                    // Como el PDF ya existe, el repositorio lo encontrará y lo guardará en Mongo
                    repositorio_facturas.agregarDetalles();

                    // 4. Reducir stock y actualizar contadores
                    repositorio_producto.buscar_reducirStock(factura.getDetalle());
                    repositorio_facturas.actualizarCodigoFactura();

                    // 5. Verificar y enviar correo
                    if (rutaPdf != null) {

                        Modelo.Datos_Cliente clienteActual = factura.getDatos_cliente();

                        if (clienteActual != null && clienteActual.getCorreoElectronico() != null
                        && !clienteActual.getCorreoElectronico().isEmpty()) {

                            String correoDestino = clienteActual.getCorreoElectronico();

                            new Thread(() -> {
                                Modelo.ServicioEmail servicio = new Modelo.ServicioEmail();
                                System.out.println("Enviando a: " + correoDestino);
                                boolean enviado = servicio.enviarFactura(correoDestino, rutaPdf);
                            }).start();
                            nuevaFactura();
                            vista.getMensaje("Compra realizada, factura enviada al correo "+factura.getDatos_cliente().getCorreoElectronico());
                        } else {
                            vista.getMensaje("El cliente no tiene correo registrado, no se envía email");
                        }
                    } else {
                        vista.getMensaje("Error: No se pudo generar el PDF");
                    }
                //llamamos el metodo para limpiar

                //limpiarVenta();
            
                }
                                   
        } catch (Exception e) {
           vista.getMensaje("Error en la venta: " + e.getMessage());
        }
    
        vista.dispose();
    }
    
    public void nuevaFactura(){
        this.factura.getDetalle().clear();
        
    }

    private void generarReporteHTML() {
        DecimalFormat df = new DecimalFormat("$ #,##0.00");
        StringBuilder html = new StringBuilder();
        // --- COLORES ---
        // Celeste brillante tomado de tu imagen (Botón Buscar / Cabecera Tabla)
        String coloNaranja = "#F77A15"; 
        String blancoFondo    = "#ffffff";// #FFF5EB
        String pastel       = "#FFF5EB";

        html.append("<html>");
        // Ajuste: font-size 10px (más pequeño) y márgenes reducidos
        html.append("<body style='font-family: Sans-serif; font-size: 10px; color: #333; margin:0; padding:5px;'>");

        // 1. ENCABEZADO COMPACTO
        html.append("<table width='100%' cellpadding='5' cellspacing='0' bgcolor='").append(coloNaranja).append("'>");
        html.append("<tr>");
        html.append("  <td width='60%' align='left'>");
        // Título más pequeño (16px)
        html.append("    <b style='color: white; font-size: 16px;'>FACTURA DE VENTA</b>");
        html.append("  </td>");
        html.append("  <td width='40%' align='right' valign='middle'>");
        html.append("    <b style='color: white; font-size: 12px;'>N° ").append(factura.getIdFactura()).append("</b>");
        html.append("  </td>");
        html.append("</tr>");
        html.append("</table>");

        // 2. DATOS DEL CLIENTE (Más pegaditos)
        html.append("<div style='padding: 8px;'>"); // Menos padding
        html.append("  <table width='100%' cellpadding='2'>"); // Menos espacio entre celdas
        html.append("    <tr><td width='70'><b>Cliente:</b></td><td>").append(factura.getDatos_cliente().getNombre()).append(" ")
                .append(factura.getDatos_cliente().getApellido()).append("</td></tr>");
        html.append("    <tr><td><b>Cédula:</b></td><td>").append(factura.getDatos_cliente().getCedula()).append("</td></tr>");
        html.append("    <tr><td><b>Correo:</b></td><td>").append(factura.getDatos_cliente().getCorreoElectronico()).append("</td></tr>");
        html.append("    <tr><td><b>Fecha:</b></td><td>").append(factura.getLocaldate()).append("</td></tr>");
        html.append("  </table>");
        html.append("</div>");

        // 3. TABLA DE PRODUCTOS
        html.append("<div style='padding: 0 5px;'>");
        html.append("<table width='100%' border='0' cellpadding='3' cellspacing='0' style='border-collapse: collapse;'>");

        // Encabezado Tabla (Celeste)
        html.append("<tr bgcolor='").append(coloNaranja).append("' style='color: white;'>");
        html.append("  <th align='center' width='10%'>Cant.</th>");
        html.append("  <th align='left' width='55%'>Descripción</th>");
        html.append("  <th align='right' width='15%'>P. Unit</th>");
        html.append("  <th align='right' width='20%'>Total</th>");
        html.append("</tr>");

        // Filas
        boolean par = false;
        if (factura.getDetalle() != null) {
            for (DetalleFactura item : factura.getDetalle()) {
                String bg = par ? blancoFondo : pastel;
                html.append("<tr bgcolor='").append(bg).append("'>");
                html.append("  <td align='center'>").append(item.getCantidad()).append("</td>");
                html.append("  <td>").append(item.getNombreProducto()).append("</td>");
                html.append("  <td align='right'>").append(df.format(item.getPrecioUnitario())).append("</td>");
                html.append("  <td align='right'><b>").append(df.format(item.calcularTotalUnitario())).append("</b></td>");
                html.append("</tr>");
                par = !par;
            }
        }
        html.append("</table>");
        html.append("</div>");

        // 4. TOTALES COMPACTOS
        html.append("<br>");
        html.append("<table width='100%' cellpadding='0' cellspacing='0'>");
        html.append("<tr>");
        // Ajuste: Reduje el espacio vacío para que se vea más lleno
        html.append("  <td width='45%'></td>"); 
        html.append("  <td width='55%'>"); // La tabla de totales ahora ocupa el 55% del ancho

        // Tabla interna de totales
        html.append("    <table width='100%' cellpadding='3' cellspacing='0' style='border: 1px solid #ccc;'>");
        
        // Subtotal
        html.append("      <tr>");
        html.append("        <td align='right' style='color:#555; font-size: 10px;'>Subtotal:</td>");
        html.append("        <td align='right' style='font-size: 10px;'>").append(df.format(factura.calcularSubtotal())).append("</td>");
        html.append("      </tr>");

        // IVA
        html.append("      <tr>");
        html.append("        <td align='right' style='color:#555; font-size: 10px;'>IVA:</td>");
        html.append("        <td align='right' style='font-size: 10px;'>").append(df.format(factura.subTotalIva())).append("</td>");
        html.append("      </tr>");

        // TOTAL FINAL (Barra celeste)
        html.append("      <tr bgcolor='").append(coloNaranja).append("' style='color: white;'>");
        html.append("        <td align='right' style='font-size: 12px;'><b>TOTAL:</b></td>");
        html.append("        <td align='right' style='font-size: 12px;'><b>").append(df.format(factura.precioTotal())).append("</b></td>");
        html.append("      </tr>");

        html.append("    </table>");
        html.append("  </td>");
        html.append("</tr>");
        html.append("</table>");

        // Pie de página pequeño
        html.append("<div style='text-align: center; color: #999; margin-top: 15px; font-size: 9px;'>");
        html.append("Gracias por su compra");
        html.append("</div>");

        html.append("</body></html>");

        vista.setContenidoHTML(html.toString());
    }
}