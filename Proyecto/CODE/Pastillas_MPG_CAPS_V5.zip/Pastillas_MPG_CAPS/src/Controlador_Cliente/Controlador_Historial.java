
package Controlador_Cliente;
import GUI.Eventos_Tabla;
import Modelo.Repositorio_Reporte_Facturas;
import Vista_Cliente.Vista_Catalogo;
import Vista_Cliente.Vista_Reporte_Detalle_Cliente;
import Vista_Cliente.Vista_Historial;
import javax.swing.table.DefaultTableModel;
//
public class Controlador_Historial {
    private Repositorio_Reporte_Facturas reporte_factura = new Repositorio_Reporte_Facturas();
    private DefaultTableModel modelo;
    private Vista_Historial vista;
    private Eventos_Tabla filtro_tabla = new Eventos_Tabla();
    private Vista_Catalogo catalogo;

    public Controlador_Historial(Vista_Historial vist, String correo) {
        
        this.vista = vist;
        modelo = (DefaultTableModel) vista.tablaDetalle().getModel();
        vista.botonDetalle().addActionListener(e -> verDetalle());
        //vista.botonRegresar().addActionListener(e -> regresar());
        reporte_factura.leerReportes(modelo,correo);
        filtro_tabla.ordenar_filtar(modelo, vista.tablaDetalle(), vista.cajaFecha(), 0);
        
    }
    
    public void verDetalle(){
        int fila = vista.tablaDetalle().getSelectedRow();

        if (fila == -1) {
            vista.getMensaje("Seleccione una fila");
            return;
        }
        
        int filaMoledo = vista.tablaDetalle().convertRowIndexToModel(fila);
        String numeroFactura = modelo.getValueAt(filaMoledo, 1).toString().trim();
        
        Vista_Reporte_Detalle_Cliente reporte = new Vista_Reporte_Detalle_Cliente(numeroFactura);
        reporte.setVisible(true);
    }
    
   /* public void regresar(){
        catalogo = new Vista_Catalogo(correo, factura, productos);
    }*/
}
