
package Controlador_Cliente;

import Modelo.DetalleFactura;
import Modelo.Factura;
import Modelo.Producto;
import Modelo.Repositorio_Producto;
import Vista_Cliente.Vista_Catalogo;
import Vista_Cliente.Vista_DetalleCompra;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class Controlador_DetalleCompra {
    
    Factura factura;
    Vista_DetalleCompra vista;
    DefaultTableModel modelo;
    //ArrayList<Producto> lista_producto;
    Repositorio_Producto repositorio_Producto;

    public Controlador_DetalleCompra(Factura factura, Vista_DetalleCompra vist/*ArrayList<Producto> lista_producto*/,Repositorio_Producto repositorio,String correo) {
        this.factura = factura;
        this.vista = vist;
        vista.botonActualizar().addActionListener(e -> actualizarProducto());
        vista.botonEliminar().addActionListener(e -> eliminarProducto());
        vista.botonRegresar().addActionListener(e -> regresar(correo));
        modelo = (DefaultTableModel) this.vista.getTablaProducto().getModel();
        //this.lista_producto = lista_producto;
        this.repositorio_Producto = repositorio;
        mostrarProductos(modelo);
    }
    
    public void mostrarProductos(DefaultTableModel modelo){
        modelo.setRowCount(0);
        for(DetalleFactura d: factura.getDetalle()){
             Object[] filas = {
                d.getNombreProducto(),
                d.getCantidad(),
                d.getPrecioUnitario(),
                d.calcularTotalUnitario()
            };
            modelo.addRow(filas);
        }
    }
    
    public void actualizarProducto(){
        
    try{    int filaSelecionada = vista.getTablaProducto().getSelectedRow();
            if(filaSelecionada == -1){
                vista.getMensaje("Edite algun dato");
                return;
            }
            int opcion = vista.getMensajeConfirmacion("Seguro que quiere editar?");
            if(opcion == 0){
            //Aqui conparo el nombre de la categoria obtenido, luego obtendo su objeto del combobox y lo mando al objetto producto
                //para asi mandarlo a editar
                
            //Esto permite editar los datos sin esperar una confirmacion como un enter o editar otra celda
            if(vista.getTablaProducto().isEditing()){
                vista.getTablaProducto().getCellEditor().stopCellEditing();
            }
            //Aqui vamos a editar los datos en caso de que se edite en varias filas de la tabla, las filas los obtenemos directamente del modelo
            // no es necesario convertir filas de tabla en filas de modelo
            for(int i = 0; i < modelo.getRowCount(); i++){
                String nombre = modelo.getValueAt(i, 0).toString().trim();
                String cantidad_Anterior = modelo.getValueAt(i, 1).toString().trim();
                
                if(!cantidad_Anterior.matches("[0-9]+") ){
                    vista.getMensaje("Ingrese solo numeros en la cantidad por favor");
                    return;
                }
           
                
                    
                int cantidad = Integer.parseInt(modelo.getValueAt(i, 1).toString().trim());
                if(cantidad == 0){
                    vista.getMensaje("Ingrese una cantidad correcta o elimine el producto");
                    mostrarProductos(modelo);
                    return;
                    
                }

                for(DetalleFactura d: factura.getDetalle()){
                    if(d.getNombreProducto().equals(nombre)){
                        int nuevaCantidad = d.getCantidad() - cantidad;
                        for(Producto p : repositorio_Producto.getLista()){
                            if(p.getNombre().equals(d.getNombreProducto()))
                                p.devolverStock(nuevaCantidad);
                            }
                        d.setCantidad(cantidad);
                    }
                }
            }
               
            vista.getMensaje("Se edito con exito");
                mostrarProductos(modelo);
        }else{
               mostrarProductos(modelo);
                return;
            }
    }catch (NumberFormatException e){
                    vista.getMensaje("Ingrese una cantidad correcta por favor");
                    }
    }
    
    public void eliminarProducto(){
        
        int fila = vista.getTablaProducto().getSelectedRow();

        if (fila == -1) {
            vista.getMensaje("Seleccione una fila");
            return;
        }
        
        int confirmacion = vista.getMensajeConfirmacion("Seguro que quiere eliminar el producto del carrito?");
        

        if (confirmacion != 0) {
            return; // Cancela la eliminación
        }
        
        int filaMoledo = vista.getTablaProducto().convertRowIndexToModel(fila);
        int cantidad = Integer.parseInt(modelo.getValueAt(filaMoledo, 1).toString().trim());
        String nombre = modelo.getValueAt(filaMoledo, 0).toString().trim();
        
        int opcion = vista.getMensajeConfirmacion("Seguro que quiere eliminar?");
        
        if(opcion == 0){
            for (int i = 0; i < factura.getDetalle().size(); i++) {
                if (i == filaMoledo) {
                    factura.getDetalle().remove(i);
                    vista.getMensaje("Producto removido con exito");
                    for(Producto p: repositorio_Producto.getLista()){
                        if(p.getNombre().equals(nombre)){
                            
                            p.devolverStock(cantidad);
                        }
                    }
                    mostrarProductos(modelo);
                    return;
                }
            }
        }else{
            mostrarProductos(modelo);
            return;
        }      
    }
    
    public void regresar(String correo){
        Vista_Catalogo catalogo = new Vista_Catalogo(correo, factura,repositorio_Producto);
        catalogo.setVisible(true);
        vista.dispose();
    }
    
    
}
