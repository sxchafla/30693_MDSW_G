
package Vista_Login;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 *
 * @author javie
 */
public class Vista_Login extends javax.swing.JFrame implements Interfaz_Login{

  
    public Vista_Login() {
        initComponents();
        //Aqui llamamos al contructor de login
        new Controlador_Login.Controlador_Login(this);
        //Esto es para accionar el boton al darle enter
        this.getRootPane().setDefaultButton(boton_Ingresar);
        setLocationRelativeTo(null);
        setResizable(false);
        configurarBotones(boton_Ingresar, new Color(214,91,14), new Color(214,80,10));
        configurarBotones(boton_Registrar, new Color(214,91,14), new Color(214,80,10));
        
        lblDescripcion.setText("<html><center><b>MPG-CAPS™</b><br>" +
        "El Ahorro de Combustible en una Cápsula<br>" +
        "¡Es hora de ir más allá y maximizar el potencial de tu vehículo!</center></html>");
        
        cajasDisenio();
        adaptarImagen(lblImagen, "/Imagenes/logo3MGPCAPS.png");
    }
  /*  
    @Override
public void setVisible(boolean visible) {
    // 1. Primero le decimos a Java: "Dibuja la ventana en la pantalla"
    super.setVisible(visible); 
    
    // 2. Una vez dibujada, la ventana ya sabe cuánto mide el JLabel
    if (visible) { 
        // ¡Aquí activamos la magia! Cambia 'lblFotoLogin' por el nombre de tu variable JLabel
        adaptarImagen(lblImagen, "/Imagenes/logo3MGPCAPS.png"); 
    }
}
    */
    //Todos estos metodos se los llaman y utilizan en el contructor de login

    // Devuelve el texto de la caja usuario
    @Override
  public String cajaUsuario(){
      return cajaUsuario.getText();
  }
  
  // Devuelve el texto de la caja contrasenia
    @Override
  public String cajaContrasenia(){
      return cajaContrasenia.getText();
  }
    
  // Devuelve el boton ingresar
    @Override
  public JButton boton_Ingresar(){
      return boton_Ingresar;
  }
  
      @Override
  public JButton boton_Registrar(){
      return boton_Registrar;
  }
  
    @Override
  public void estadoBoton_Ingresar(boolean estado){
      boton_Ingresar.setEnabled(estado);
  }
  
  // Limpia las cajas de texto
    @Override
  public void limpiar(){
      cajaContrasenia.setText("");
      cajaUsuario.setText("");
  }
  
  // Muestra un mensaje en el JFrame
    @Override
  public void mostrarMensaje(String mensaje){
      JOptionPane.showMessageDialog(this, mensaje);
  }
  
  //public void setControlador()      
  
  // Este método toma tu JLabel, mide su tamaño real y estira la imagen para que encaje
public void adaptarImagen(javax.swing.JLabel label, String rutaImagen) {
    try {
        // 1. Carga la imagen desde tus carpetas
        java.net.URL url = getClass().getResource(rutaImagen);
        if (url != null) {
            javax.swing.ImageIcon iconoOriginal = new javax.swing.ImageIcon(url);
            
            // 2. Toma el tamaño REAL del JLabel en ese instante y ajusta la imagen
            java.awt.Image imagenEscalada = iconoOriginal.getImage().getScaledInstance(
                label.getWidth(), 
                label.getHeight(), 
                java.awt.Image.SCALE_SMOOTH
            );
            
            // 3. Le pone la imagen ya estirada al JLabel
            label.setIcon(new javax.swing.ImageIcon(imagenEscalada));
        } else {
            System.err.println("No se encontró la imagen en la ruta: " + rutaImagen);
        }
    } catch (Exception e) {
        System.err.println("Error al cargar la imagen: " + e.getMessage());
    }
}

   private void configurarBotones(JButton boton, Color normal, Color especial) {

        //Quita el borde cuando le haces click
        boton.setFocusPainted(false);
        //Eliminar el brode 3d
        boton.setBorderPainted(false);
        //Quita el relieve interno
      //  boton.setContentAreaFilled(false);
        //Permite pintar el fondo
        boton.setOpaque(true);
        //Pinta el fondo
        boton.setBackground(normal);
        //Pinta el texto
        boton.setForeground(Color.WHITE);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(especial);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                boton.setBackground(normal);
            }
        });
      }
   

   
 
   
   public void cajasDisenio() {
    this.setLocationRelativeTo(null); 

    // 1. Forzar a FlatLaf a usar su borde redondeado con color naranja (RGB: 245, 124, 0)
    com.formdev.flatlaf.ui.FlatRoundBorder bordeNaranja = new com.formdev.flatlaf.ui.FlatRoundBorder();
    
    // Asignar el borde redondeado de FlatLaf
    cajaUsuario.setBorder(bordeNaranja);
    cajaContrasenia.setBorder(bordeNaranja);

    // 2. Aplicar el redondeado (arc = 20 para esquinas suaves tipo cápsula)
    cajaUsuario.putClientProperty("JComponent.roundRect", Boolean.TRUE);
    cajaContrasenia.putClientProperty("JComponent.roundRect", Boolean.TRUE);

    // 3. Pintar el borde de naranja usando el 'outline' de FlatLaf o enfocando el color
    cajaUsuario.putClientProperty("JComponent.outline", new java.awt.Color(245, 124, 0));
    cajaContrasenia.putClientProperty("JComponent.outline", new java.awt.Color(245, 124, 0));

    // 4. Textos de ayuda (Placeholders)
    cajaUsuario.putClientProperty("JTextField.placeholderText", "Usuario o correo");
    cajaContrasenia.putClientProperty("JTextField.placeholderText", "Contraseña");

    // 5. Botón para ver/ocultar contraseña (JPasswordField)
    cajaContrasenia.putClientProperty("JPasswordField.showRevealButton", Boolean.TRUE);

    // 6. Redondear el botón de Ingresar
    boton_Ingresar.putClientProperty("JButton.buttonType", "roundRect");

    // 7. Refrescar la ventana
    this.revalidate();
    this.repaint();
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        cajaUsuario = new javax.swing.JTextField();
        cajaContrasenia = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        boton_Ingresar = new javax.swing.JButton();
        lblImagen = new javax.swing.JLabel();
        lblDescripcion = new javax.swing.JLabel();
        boton_Registrar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(247, 251, 255));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEmptyBorder(30, 40, 30, 40));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Usuario:");

        cajaUsuario.setBorder(null);
        cajaUsuario.setMargin(new java.awt.Insets(6, 10, 6, 10));
        cajaUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cajaUsuarioActionPerformed(evt);
            }
        });

        cajaContrasenia.setBorder(null);
        cajaContrasenia.setMargin(new java.awt.Insets(6, 10, 6, 10));
        cajaContrasenia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cajaContraseniaActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("Contraseña:");

        boton_Ingresar.setFont(new java.awt.Font("DejaVu Serif", 0, 14)); // NOI18N
        boton_Ingresar.setText("Ingresar");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(boton_Ingresar, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblImagen, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(lblDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(32, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cajaContrasenia, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cajaUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(37, 37, 37))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblImagen, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblDescripcion, javax.swing.GroupLayout.DEFAULT_SIZE, 84, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cajaUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cajaContrasenia, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addComponent(boton_Ingresar, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        boton_Registrar.setText("Registrate aqui!");

        jLabel3.setText("¿No tienes cuenta?");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(39, Short.MAX_VALUE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(86, 86, 86)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(boton_Registrar)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(53, 53, 53))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(boton_Registrar)
                    .addComponent(jLabel3))
                .addGap(25, 25, 25))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cajaUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cajaUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cajaUsuarioActionPerformed

    private void cajaContraseniaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cajaContraseniaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cajaContraseniaActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton boton_Ingresar;
    private javax.swing.JButton boton_Registrar;
    private javax.swing.JTextField cajaContrasenia;
    private javax.swing.JTextField cajaUsuario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblDescripcion;
    private javax.swing.JLabel lblImagen;
    // End of variables declaration//GEN-END:variables

    
}
