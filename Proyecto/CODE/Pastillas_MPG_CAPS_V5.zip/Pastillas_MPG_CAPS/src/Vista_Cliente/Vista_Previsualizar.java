
package Vista_Cliente;

import Modelo.Factura;
import Controlador_Cliente.Controlador_Previsualizar;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JOptionPane;


public class Vista_Previsualizar extends javax.swing.JFrame implements Interfaz_Previsualizar{

    Factura factura;
    public Vista_Previsualizar(Factura factura) {
        initComponents();
        this.factura = factura;
        this.setDefaultCloseOperation(javax.swing.WindowConstants.HIDE_ON_CLOSE);
        this.setLocationRelativeTo(null);
         configurarBotones(boton_Guardar, new Color(46,204,113), new Color(39,174,96));
         configurarBotones(boton_Regresar, Color.gray, new Color(100,116,139));
       new Controlador_Previsualizar(this, this.factura);
    }
    
    @Override
    public JButton getNuevaFactura(){
        return boton_Guardar;
    }
    
    @Override
    public JButton getRegresar(){
        return boton_Regresar;
    }
    
    @Override
    public int getMensajeOpcion(String n){
        Object[] String={
            "Generar Factura","Regresar"
        };
        return JOptionPane.showOptionDialog(this, "Elija una opcion", n, 0, 0, null, String, 0);
    }
    
    @Override
    public void getMensaje(String m){
        JOptionPane.showMessageDialog(this, m);
    }
    @Override
    public void setContenidoHTML(String html) {
        // 1. Asignamos el texto HTML al componente
        txtVisor.setText(html);
        
        // 2. Truco PRO: Mover el scroll al inicio (arriba)
        // A veces al cargar mucho texto, el scroll se queda abajo. Esto lo arregla.
        txtVisor.setCaretPosition(0);
    }

       private void configurarBotones(JButton boton, Color normal, Color especial) {
        //Quita el borde cuando le haces click
        boton.setFocusPainted(false);
        //Eliminar el brode 3d
        boton.setBorderPainted(false);
        //Quita el relieve interno
       // boton.setContentAreaFilled(false);
        //Permite pintar el fondo
        boton.setOpaque(true);
        //Pinta el fondo
        boton.setBackground(especial);
        //Pinta el texto
        boton.setForeground(Color.WHITE);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(especial);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                boton.setBackground(normal);
            }
        });
      }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        boton_Guardar = new javax.swing.JButton();
        boton_Regresar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtVisor = new javax.swing.JTextPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(242, 245, 252));

        boton_Guardar.setText("Comprar");

        boton_Regresar.setText("Regresar");

        txtVisor.setEditable(false);
        txtVisor.setContentType("text/html"); // NOI18N
        jScrollPane2.setViewportView(txtVisor);

        jScrollPane1.setViewportView(jScrollPane2);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(boton_Regresar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(boton_Guardar)
                .addGap(73, 73, 73))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(10, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 327, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(boton_Guardar)
                    .addComponent(boton_Regresar))
                .addGap(24, 24, 24))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton boton_Guardar;
    private javax.swing.JButton boton_Regresar;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextPane txtVisor;
    // End of variables declaration//GEN-END:variables
}
