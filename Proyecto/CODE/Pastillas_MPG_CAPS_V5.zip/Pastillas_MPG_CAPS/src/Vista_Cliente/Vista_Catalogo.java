
package Vista_Cliente;

import Controlador_Cliente.Controlador_Catalogo;
import Modelo.Factura;
import Modelo.Repositorio_Producto;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author javie
 */
public class Vista_Catalogo extends javax.swing.JFrame implements Interfaz_Catalogo{

    Factura factura;

    
    public Vista_Catalogo(String correo, Factura factura, Repositorio_Producto productos) {
        initComponents();
        this.factura = factura;
        this.setLocationRelativeTo(null);
        new Controlador_Catalogo(this, factura,correo,productos);
        configurarBotones(botonDetalle, new Color(239,58,55), Color.pink);
        configurarBotones(botonHistorial, new Color(146,58,55), Color.pink);
        configurarBotones(boton_Comprar, new Color(41,213,84), new Color(35,213,24));
    }

    
    public JPanel panelCatalogo(){
        return panelCatalogo;
    }
    
    
    public void getMensaje(String m){
        JOptionPane.showMessageDialog(this, m);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        panelCatalogo = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        botonHistorial = new javax.swing.JButton();
        botonDetalle = new javax.swing.JButton();
        boton_Comprar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(250, 255, 245));

        panelCatalogo.setLayout(new java.awt.GridLayout(1, 3));
        jScrollPane1.setViewportView(panelCatalogo);

        jPanel2.setBackground(new java.awt.Color(247, 122, 21));

        botonHistorial.setText("Ver historial de compra");

        botonDetalle.setText("Carrito de Compra");

        boton_Comprar.setText("Comprar");

        jLabel1.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("MPG-Caps");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 128, Short.MAX_VALUE)
                .addComponent(botonHistorial)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonDetalle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(boton_Comprar)
                .addGap(41, 41, 41))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonHistorial)
                    .addComponent(botonDetalle)
                    .addComponent(boton_Comprar))
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(27, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 453, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
 /*   @Override
    public JButton botonAgregar1(){
    return botonAgregar1;
};

    @Override
    public JButton botonAgregar2(){
    return botonAgregar2;
};

    @Override
    public JButton botonAgregar3(){
    return botonAgregar3;
};
*/
    @Override
    public JButton botonDetalle(){
    return botonDetalle;
};

     @Override
    public JButton botonHistorial(){
    return botonHistorial;
};
    
    public JButton botonComprar(){
    return boton_Comprar;
};
    
     private void configurarBotones(JButton boton, Color normal, Color especial) {

        //Quita el borde cuando le haces click
        boton.setFocusPainted(false);
        //Eliminar el brode 3d
        boton.setBorderPainted(false);
        //Quita el relieve interno
      //  boton.setContentAreaFilled(false);
        //Permite pintar el fondo
        boton.setOpaque(true);
        //Pinta el fondo
        boton.setBackground(normal);
        //Pinta el texto
        boton.setForeground(Color.WHITE);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(especial);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                boton.setBackground(normal);
            }
        });
      }
    
  /*  
    @Override
    public String cajaCantidad1(){
    return cajaCantidad1.getText();
};

    @Override
    public String cajaCantidad2(){
    return cajaCantidad2.getText();
};

    @Override
    public String cajaCantidad3(){
    return cajaCantidad3.getText();
};
    
    @Override
    public JButton botonHistorial(){
    return botonHistorial;
};*/

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonDetalle;
    private javax.swing.JButton botonHistorial;
    private javax.swing.JButton boton_Comprar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel panelCatalogo;
    // End of variables declaration//GEN-END:variables
}
