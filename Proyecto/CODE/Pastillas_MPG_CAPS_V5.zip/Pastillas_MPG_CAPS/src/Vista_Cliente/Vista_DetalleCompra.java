
package Vista_Cliente;

import Controlador_Cliente.Controlador_DetalleCompra;
import Modelo.Factura;
import Modelo.Producto;
import Modelo.Repositorio_Producto;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTable;

public class Vista_DetalleCompra extends javax.swing.JFrame {

    public Vista_DetalleCompra(Factura factura, Repositorio_Producto repo, String correo) {
        initComponents();
        configurarBotones(boton_Eliminar, new Color(231,76,60), new Color(192,57,43));
        configurarBotones(boton_Actualizar, new Color(215,126,10), new Color(12,127,203));
        configurarBotones(boton_Regresar, Color.gray, new Color(100,116,139));
        disenioDetalleCompra();
        new Controlador_DetalleCompra(factura,this,repo,correo);
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tabla = new javax.swing.JTable();
        boton_Actualizar = new javax.swing.JButton();
        boton_Eliminar = new javax.swing.JButton();
        boton_Regresar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        Tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "NOMBRE PRODUCTO", "CANTIDAD", "PRECIO", "TOTAL"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(Tabla);

        boton_Actualizar.setText("Actualizar");

        boton_Eliminar.setText("Eliminar");

        boton_Regresar.setText("Regresar");

        jPanel2.setBackground(new java.awt.Color(94, 176, 255));

        jLabel1.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Carrito de compra");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(183, 183, 183)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(boton_Regresar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(boton_Actualizar)
                        .addGap(18, 18, 18)
                        .addComponent(boton_Eliminar))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 523, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(22, Short.MAX_VALUE))
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(boton_Actualizar)
                    .addComponent(boton_Eliminar)
                    .addComponent(boton_Regresar))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public JTable getTablaProducto(){
        return Tabla;
    }
    
    public JButton botonEliminar(){
        return boton_Eliminar;
    }
    
    public JButton botonActualizar(){
        return boton_Actualizar;
    }
    
    public JButton botonRegresar(){
        return boton_Regresar;
    }
    
    public void getMensaje(String m){
        JOptionPane.showMessageDialog(this, m);
    }
    
    public int getMensajeConfirmacion(String m){
        return JOptionPane.showConfirmDialog(this, m, "Elija", JOptionPane.YES_NO_OPTION);
    }
    
     private void configurarBotones(JButton boton, Color normal, Color especial) {

        //Quita el borde cuando le haces click
        boton.setFocusPainted(false);
        //Eliminar el brode 3d
        boton.setBorderPainted(false);
        //Quita el relieve interno
      //  boton.setContentAreaFilled(false);
        //Permite pintar el fondo
        boton.setOpaque(true);
        //Pinta el fondo
        boton.setBackground(normal);
        //Pinta el texto
        boton.setForeground(Color.WHITE);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        boton.putClientProperty("JButton.buttonType", "roundRect");

        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(especial);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                boton.setBackground(normal);
            }
        });
      }
     
     public void disenioDetalleCompra() {
    this.setLocationRelativeTo(null);

    // ========================================================
    // 1. MEJORAR LA TABLA (JTable y JScrollPane)
    // ========================================================
    // Nota: Reemplaza 'tablaDetalle' y 'scrollPaneTabla' con los nombres de tus variables
    
    // Darle más "aire" a las filas aumentando su altura (Padding vertical)
    Tabla.setRowHeight(30);
    
    // Mostrar solo líneas horizontales sutiles (opcional, para un look más limpio)
    Tabla.setShowHorizontalLines(true);
    Tabla.setShowVerticalLines(false);
    Tabla.setGridColor(new java.awt.Color(230, 235, 240));

    // Desactivar el borde cuadrado del JScrollPane
    
    
    // Estilizar el encabezado de la tabla (JTableHeader) con FlatLaf
    Tabla.getTableHeader().putClientProperty("FlatLaf.style", 
        "separatorColor: #E2E8F0; font: bold 12 $sansserif.font;");
    
    // ========================================================
// COLORES PASTEL PARA LA TABLA
// ========================================================
// Fondo general de la tabla (Blanco o un hueso muy suave)
java.awt.Color fondoTabla = new java.awt.Color(255, 255, 255);

// Color Pastel para filas alternas (Celeste pastel / Menta suave)
// Puedes probar con: 
// - Celeste Pastel: new Color(240, 244, 248)
// - Verde Menta Pastel: new Color(242, 248, 245)
java.awt.Color filaPastelAlterna = new java.awt.Color(240, 244, 248); 

// Color de selección (Cuando haces clic en una fila - Azul pastel más marcado)
java.awt.Color seleccionPastel = new java.awt.Color(217, 230, 242);
java.awt.Color textoSeleccion = new java.awt.Color(30, 41, 59); // Gris oscuro para que se lea bien

// Aplicar los colores a la JTable
Tabla.setBackground(fondoTabla);
Tabla.setSelectionBackground(seleccionPastel);
Tabla.setSelectionForeground(textoSeleccion);

// Habilitar el renderizado alterno nativo de FlatLaf
Tabla.putClientProperty("JTable.alternateRowColor", filaPastelAlterna);

// ========================================================
// ESTILIZAR EL ENCABEZADO (Header) CON TONO PASTEL
// ========================================================
// Un gris/azul pastel sutil para los títulos de las columnas
java.awt.Color headerPastel = new java.awt.Color(226, 232, 240); 
java.awt.Color headerTexto = new java.awt.Color(71, 85, 105);

Tabla.getTableHeader().setBackground(headerPastel);
Tabla.getTableHeader().setForeground(headerTexto);

// Ajustes de líneas adicionales para look moderno
Tabla.setShowHorizontalLines(true);
Tabla.setShowVerticalLines(false); // Quitar líneas verticales se ve más minimalista
Tabla.setGridColor(new java.awt.Color(241, 245, 249)); // Línea divisoria muy tenue
     }
     
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Tabla;
    private javax.swing.JButton boton_Actualizar;
    private javax.swing.JButton boton_Eliminar;
    private javax.swing.JButton boton_Regresar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables

   
}
