
package Vista_Cliente;

import Modelo.Factura;
import Controlador_Cliente.Controlador_PanelProducto;
import Modelo.Producto;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
/**
 *
 * @author javie
 */
public class PanelProducto extends javax.swing.JPanel {


    Factura factura;
    public PanelProducto( Factura factura, Producto p) {
        initComponents();
        //lblNombre.setText(nombre);
        //lblCantidad.setText("Precio: " + precio + "      Stock disponible:"+cantidad);
        this.factura = factura;
        mostrarTextos(p.getNombre(), p.getPrecioUnitario(), p.getCantidad());
        configurarBotones(botonAgregar, new Color(150,180,180), new Color(140,170,180));
        actualizarBarraStock(barraCantidad, p.getCantidad(), 100);
        botonAgregar.putClientProperty("JButton.buttonType", "roundRect");
        new Controlador_PanelProducto(factura, this,p);
        
    }

    
    public JButton botonAgregar(){
      return botonAgregar;
    }
    
    public String getCantidad(){
        return cajaCantidad.getText();
    }
    
    public JLabel lblNombre(){
        return lblNombre;
    }
    
    public void limpiarCaja(){
        cajaCantidad.setText("");
    }
    
    public JLabel lblImagen(){
        return lblImagen;
    }
    
    public void getMensaje(String m){
        JOptionPane.showMessageDialog(this, m);
    }
   
    public void mostrarTextos(String nombre, double precio, int cantidad){
        lblNombre.setText(nombre);
        lblCantidad.setText("Stock disponible: "+cantidad);
        lblPrecio.setText("Precio: "+precio);
    }
    
    private void configurarBotones(JButton boton, Color normal, Color especial) {

        //Quita el borde cuando le haces click
        boton.setFocusPainted(false);
        //Eliminar el brode 3d
        boton.setBorderPainted(false);
        //Quita el relieve interno
       // boton.setContentAreaFilled(false);
        //Permite pintar el fondo
        boton.setOpaque(true);
        //Pinta el fondo
        boton.setBackground(especial);
        //Pinta el texto
        boton.setForeground(Color.WHITE);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(especial);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                boton.setBackground(normal);
            }
        });
      }
    
    public void actualizarBarraStock(JProgressBar barra, int stockActual, int stockMaximo) {
    barra.setMaximum(stockMaximo);
    barra.setValue(stockActual);
    
    if (stockActual > 10) {
        // Verde si hay buen stock
        barra.setForeground(new java.awt.Color(46, 204, 113)); 
    } else if (stockActual > 0) {
        // Naranja/Amarillo si queda poco
        barra.setForeground(new java.awt.Color(241, 196, 15)); 
    } else {
        // Rojo si está agotado
        barra.setForeground(new java.awt.Color(231, 76, 60)); 
    }
    
}
    
    public void adaptarImagen(javax.swing.JLabel label, String rutaImagen) {
    try {
        // 1. Carga la imagen desde tus carpetas
        java.net.URL url = getClass().getResource(rutaImagen);
        if (url != null) {
            javax.swing.ImageIcon iconoOriginal = new javax.swing.ImageIcon(url);
            
            // 2. Toma el tamaño REAL del JLabel en ese instante y ajusta la imagen
            java.awt.Image imagenEscalada = iconoOriginal.getImage().getScaledInstance(
                label.getWidth(), 
                label.getHeight(), 
                java.awt.Image.SCALE_SMOOTH
            );
            
            // 3. Le pone la imagen ya estirada al JLabel
            label.setIcon(new javax.swing.ImageIcon(imagenEscalada));
        } else {
            System.err.println("No se encontró la imagen en la ruta: " + rutaImagen);
        }
    } catch (Exception e) {
        System.err.println("Error al cargar la imagen: " + e.getMessage());
    }
}
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        lblImagen = new javax.swing.JLabel();
        lblNombre = new javax.swing.JLabel();
        botonAgregar = new javax.swing.JButton();
        cajaCantidad = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        lblCantidad = new javax.swing.JLabel();
        lblPrecio = new javax.swing.JLabel();
        barraCantidad = new javax.swing.JProgressBar();

        jLabel2.setText("jLabel2");

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        lblNombre.setFont(new java.awt.Font("Engravers MT", 0, 12)); // NOI18N

        botonAgregar.setFont(new java.awt.Font("Segoe UI Emoji", 1, 12)); // NOI18N
        botonAgregar.setForeground(new java.awt.Color(255, 255, 255));
        botonAgregar.setText("Agregar");
        botonAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarActionPerformed(evt);
            }
        });

        jLabel3.setText("Cantidad");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblCantidad, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(barraCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addGap(31, 31, 31)
                                        .addComponent(cajaCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 8, Short.MAX_VALUE)))
                        .addGap(57, 57, 57))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(82, 82, 82)
                            .addComponent(botonAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(32, 32, 32)
                            .addComponent(lblImagen, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(42, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblImagen, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(lblNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(barraCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(lblCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cajaCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(botonAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void botonAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_botonAgregarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JProgressBar barraCantidad;
    private javax.swing.JButton botonAgregar;
    private javax.swing.JTextField cajaCantidad;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel lblCantidad;
    private javax.swing.JLabel lblImagen;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblPrecio;
    // End of variables declaration//GEN-END:variables
}
