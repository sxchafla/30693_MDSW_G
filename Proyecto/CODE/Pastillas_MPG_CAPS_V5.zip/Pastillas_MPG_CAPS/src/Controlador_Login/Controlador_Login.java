
package Controlador_Login;

import Modelo.Administrador;
import Modelo.Clientes;
import Vista_Login.Vista_Login;
import Vista_Admin.Vista_Admin;
import Vista_Cliente.Registrar_Cliente;
import Vista_Cliente.Vista_Catalogo;
import Modelo.Repositorio_Clientes;
import Modelo.Factura;
import Modelo.Repositorio_Producto;



public class Controlador_Login {
    
    //Se declara las instancias de cada clase o JFrame
    Vista_Login login;
    Vista_Admin vista_admin;
    Vista_Catalogo vista_cliente;
    Administrador admin;
    Clientes cliente;
    int intentosFallidos;
    Repositorio_Clientes repositorio_clientes = new Repositorio_Clientes();
    Factura factura = new Factura();
    Repositorio_Producto repositorio_producto = new Repositorio_Producto();

    //Este controlador se lo llama al JFrame de login
    public Controlador_Login(Vista_Login login) {
        //Aqui se declara yy asigna el JFrame de Vista_login para poder acceder a su interfaz y a sus cajas y botones y poder enviar mensajes
        this.login = login;
        //Aqui se aniade un actionlistener al boton utilizando funciones lamda
        this.login.boton_Ingresar().addActionListener(e -> ingresar());
        this.login.boton_Registrar().addActionListener(e -> registrar());
        intentosFallidos = 3;
        
    }
    
    //Aqui se obtiene los datos desde el JFrame
    public void ingresar(){
        
        //Se obtienen los datos
        String usuario = login.cajaUsuario();
        String contrasenia = login.cajaContrasenia();
        
        //Se crean instancias de la clase Vendedor y cliente
        admin = new Administrador();
        cliente = new Clientes();
        
        //Se verifica si las credenciales coinciden, revisen las clases de Administrador y Cliente
        if(admin.ingreso(usuario, contrasenia)){
            
            vista_admin = new Vista_Admin();
            vista_admin.setVisible(true);
            login.dispose();
            
            //cliente.ingreso(usuario, contrasenia) ||
        }else if(cliente.ingreso(usuario, contrasenia) || repositorio_clientes.buscarIngresoCliente(usuario, contrasenia)){
            
            vista_cliente = new Vista_Catalogo(usuario,factura,repositorio_producto);
            vista_cliente.setVisible(true);
            login.dispose();
            
        }else{
            
            intentosFallidos--;
            //Muestra un mensaje al JFrame
            login.mostrarMensaje("Credenciales incorrectas, te quedan "+intentosFallidos+" intentos");
            login.limpiar();
            
            //Condicion por si los intentos fallido llegaron a 3
            if(intentosFallidos == 0){
                login.mostrarMensaje("Has alcanzado el número de intentos permitoos, acceso restringido por 5 minutos");
                login.estadoBoton_Ingresar(false);
                                
                int cincoMinutosMilisegundos = 5*60*1000;
                
                javax.swing.Timer temporizador = new javax.swing.Timer(cincoMinutosMilisegundos, e -> {
                    // Este código de aquí adentro corre AUTOMÁTICAMENTE cuando pasen los 5 minutos:
                    login.boton_Ingresar().setEnabled(true); // Revive el botón
                    intentosFallidos = 3; // Reiniciamos el contador a 0 para que tenga 3 vidas de nuevo
                    System.out.println("Botón desbloqueado automáticamente.");
                });
                
                //Aqui le decimos el timer que no entre en bucle y que se repita una sola vez
                temporizador.setRepeats(false);
                //Aqui se arranca la cuenta regresiva
                temporizador.start();
            }
        }
        
        login.limpiar();
    }
    
    public void registrar(){
        Registrar_Cliente re = new Registrar_Cliente();
        re.setVisible(true);
        login.dispose();
    }
}
