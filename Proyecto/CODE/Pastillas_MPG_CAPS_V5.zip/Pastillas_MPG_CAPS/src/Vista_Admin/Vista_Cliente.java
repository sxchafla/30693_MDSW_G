
package Vista_Admin;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import Controlador_Admin.ControladorCliente;
import GUI.FiltroCaracteresNumeros;
import GUI.Filtro_Caracteres;
import GUI.Filtro_Letras;
import GUI.Filtro_Numeros;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import javax.swing.table.JTableHeader;
import javax.swing.text.AbstractDocument;


public class Vista_Cliente extends javax.swing.JFrame implements Interfaz_Cliente {

    /**
     * Creates new form Vista_Cliente
     */
    public Vista_Cliente() {
        initComponents();
        new ControladorCliente(this);
        setLocationRelativeTo(null);
        setResizable(false);
        personalizarBotones();
         ((AbstractDocument) cajaApellido.getDocument()).setDocumentFilter(new FiltroCaracteresNumeros());
        ((AbstractDocument) cajaNombre.getDocument()).setDocumentFilter(new FiltroCaracteresNumeros());
        ((AbstractDocument) cajaCedula.getDocument()).setDocumentFilter(new Filtro_Letras());
        ((AbstractDocument) cajaNumero.getDocument()).setDocumentFilter(new Filtro_Letras());
        ((AbstractDocument) cajaDireccion.getDocument()).setDocumentFilter(new Filtro_Caracteres());
       
    }

    @Override
    public String getNombreCliente(){
        return cajaNombre.getText();
    }

    @Override
    public String getCedulaCliente(){
        return cajaCedula.getText();
    }

    @Override
    public String getApellidoCliente(){
        return cajaApellido.getText();
    }

    @Override
    public String getNumeroTelefonicoCliente(){
        return cajaNumero.getText();
    }
    
    
    @Override
    public String getCorreoCliente(){
        return cajaCorreo.getText();
    }
    
    
    @Override
    public String getDireccionCliente(){
        return cajaDireccion.getText();
    }
    
  
    @Override
    public void setNombreCliente(String m){
        cajaNombre.setText("");
    }
    
    @Override
    public void setCedulaCliente(String m){
        cajaCedula.setText("");
    }
    
    @Override
    public void setApellidoCliente(String m){
        cajaApellido.setText("");
    }
    
    @Override
    public void setNumeroTelefonicoCliente(String m){
        cajaNumero.setText("");
    }
    
    @Override
    public void setCorreoCliente(String m){
        cajaCorreo.setText("");
    }
    
    @Override
    public void setDireccionCliente(String m){
        cajaDireccion.setText("");
    }
    
    @Override
    public int getMensajeConfirmacion(String m){
        return JOptionPane.showConfirmDialog(rootPane, m,"",JOptionPane.YES_NO_OPTION);
    }
    
    @Override
    public JTextField getFiltroCedula(){
        return cajaCedulaBuscada;
    }
    
   
    
  /*  public JTextField getCajaNombre(){
        return cajaNombre;
    }
    
    public JTextField getCajaCedula(){
        return cajaCedula;
    }
    
    public JTextField getCajaApellido(){
        return cajaApellido;
    }
    
    JTextField getCajaNumeroTelefonico();
    JTextField getCajaCorreo();
    JTextField getCajaDireccion();
    */
    @Override
    public void getLimpiarCliente(){
        cajaApellido.setText("");
        cajaCedula.setText("");
        cajaCorreo.setText("");
        cajaDireccion.setText("");
        cajaNombre.setText("");
        cajaNumero.setText("");
        
    }
    
    @Override
    public JButton getGuardarCliente(){
        return boton_Guardar;
    }
    
    @Override
    public JButton getRegresarCliente(){
        return boton_Regresar;
    }
    
    @Override
    public JButton getEditarCliente(){
        return boton_Editar;
    }
    
    @Override
    public JButton getEliminarCliente(){
        return boton_Eliminar;
    }
  
    
    @Override
    public void getMensaje(String mensaje){
        JOptionPane.showMessageDialog(this, mensaje);
        
    }
    
    @Override
    public JTable getTablaCliente(){
        return tabla;
    }
    
    
    
    private void configurarBotones(JButton boton , Color normal, Color especial){
        
        //Quita el borde cuando le haces click
        boton.setFocusPainted(false);
        //Eliminar el brode 3d
        boton.setBorderPainted(false);
        //Quita el relieve interno
        //boton.setContentAreaFilled(false);
        //Permite pintar el fondo
        boton.setOpaque(true);
        //Pinta el fondo
        boton.setBackground(especial);
        //Pinta el texto
        boton.setForeground(Color.WHITE);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        boton.putClientProperty("JButton.buttonType", "roundRect");

        boton.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseEntered(MouseEvent e) {
            boton.setBackground(especial);
        }

        @Override
        public void mouseExited(MouseEvent e) {
            boton.setBackground(normal);
        }
    });
    }
    
   private void tablaPersonalizada(){
         JTableHeader centroCabeceras =  tabla.getTableHeader();
        centroCabeceras.setBackground(new Color(72,133,198));
        centroCabeceras.setForeground(Color.WHITE);
        centroCabeceras.setFont(new Font("Mongolian Baiti",Font.BOLD,13));
        tabla.getTableHeader().setReorderingAllowed(false);
     }
    
   private void personalizarBotones(){    
         configurarBotones(boton_Guardar, new Color(58,186,244), new Color(58,162,244)); 
         configurarBotones(boton_Editar, new Color(46,204,113), new Color(39,174,96));
         configurarBotones(boton_Eliminar,new Color(231,76,60), new Color(192,57,43));
     }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        boton_Eliminar = new javax.swing.JButton();
        boton_Editar = new javax.swing.JButton();
        boton_Regresar = new javax.swing.JButton();
        cajaCedulaBuscada = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        cajaNumero = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cajaDireccion = new javax.swing.JTextField();
        boton_Guardar = new javax.swing.JButton();
        cajaCorreo = new javax.swing.JTextField();
        cajaCedula = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cajaNombre = new javax.swing.JTextField();
        cajaApellido = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(242, 245, 252));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Gestión Clientes"));

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "CÉDULA", "NOMBRE", "APELLIDOS", "CORRÉO ELECTRÓNICO", "NÚMERO TELEFÓNICO", "DIRECCIÓN"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, true, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tabla);

        boton_Eliminar.setBackground(new java.awt.Color(239, 68, 68));
        boton_Eliminar.setForeground(new java.awt.Color(255, 255, 255));
        boton_Eliminar.setText("Eliminar");

        boton_Editar.setText("Editar");

        boton_Regresar.setBackground(new java.awt.Color(100, 116, 139));
        boton_Regresar.setForeground(new java.awt.Color(255, 255, 255));
        boton_Regresar.setText("Regresar");

        jLabel7.setText("Buscar por cédula");

        jPanel3.setBackground(new java.awt.Color(242, 245, 252));

        jLabel4.setText("Número Telefónico");

        jLabel5.setText("Dirección");

        boton_Guardar.setText("Guardar");

        jLabel2.setText("Cédula");

        jLabel3.setText("Corréo Electrónico");

        jLabel1.setText("Apellido");

        jLabel6.setText("Nombre:");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cajaNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cajaApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(57, 57, 57)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cajaCedula, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cajaCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(60, 60, 60)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cajaNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cajaDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 170, Short.MAX_VALUE)
                        .addComponent(boton_Guardar)
                        .addGap(45, 45, 45))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel2)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cajaNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cajaCedula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cajaNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(cajaApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1)
                            .addComponent(boton_Guardar))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cajaCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cajaDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 826, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(boton_Regresar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(boton_Eliminar)
                                .addGap(18, 18, 18)
                                .addComponent(boton_Editar)
                                .addGap(11, 11, 11))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addComponent(jLabel7)
                                .addGap(33, 33, 33)
                                .addComponent(cajaCedulaBuscada, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(32, 32, 32)
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(cajaCedulaBuscada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(boton_Regresar)
                    .addComponent(boton_Editar)
                    .addComponent(boton_Eliminar))
                .addGap(38, 38, 38))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 840, 460));

        jPanel4.setBackground(new java.awt.Color(44, 111, 210));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 22)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Administrar Clientes");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(310, Short.MAX_VALUE)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(258, 258, 258))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel8)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 60));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 530, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton boton_Editar;
    private javax.swing.JButton boton_Eliminar;
    private javax.swing.JButton boton_Guardar;
    private javax.swing.JButton boton_Regresar;
    private javax.swing.JTextField cajaApellido;
    private javax.swing.JTextField cajaCedula;
    private javax.swing.JTextField cajaCedulaBuscada;
    private javax.swing.JTextField cajaCorreo;
    private javax.swing.JTextField cajaDireccion;
    private javax.swing.JTextField cajaNombre;
    private javax.swing.JTextField cajaNumero;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabla;
    // End of variables declaration//GEN-END:variables
}
