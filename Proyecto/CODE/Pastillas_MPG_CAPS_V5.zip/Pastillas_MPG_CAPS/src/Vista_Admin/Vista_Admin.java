/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vista_Admin;

import Controlador_Admin.Controlador_Admin;
import com.formdev.flatlaf.ui.FlatDropShadowBorder;
import java.awt.Color;
import java.awt.Cursor;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.nio.file.Paths;
import javax.swing.SwingConstants;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;

/**
 *
 * @author javie
 */
public class Vista_Admin extends javax.swing.JFrame implements Interfaz_Vista_Admin{

    /**
     * Creates new form Vista_Admin
     */
    public Vista_Admin() {
        initComponents();
        aplicarEfecto3D();
        new Controlador_Admin(this);
        setLocationRelativeTo(null);
        setResizable(false);
        configurarBotones(boton_Reportes, new Color(242,38,77), new Color(230,38,70));
        configurarBotones(btn_GestionarClientes, new Color(46,204,113),  new Color(39,174,96));
        configurarBotones(btn_GestionarProductos,  new Color(247,122,21), new Color(214,91,22));
    }

    @Override
    public JButton btn_gestionarProductos(){
        return btn_GestionarProductos;
    }
    
    @Override
    public JButton btn_gestionarClientes(){
        return btn_GestionarClientes;
    }
  
    @Override
    public JButton btn_verReportes(){
        return boton_Reportes;
    }
    
    public static class JPanelConFondo extends javax.swing.JPanel {
        private Image fondo;
        
        public JPanelConFondo(String rutaImagen) {
            try {
                java.io.File imagenFile = new java.io.File(rutaImagen);
                if (!imagenFile.exists()) {
                    // Intentar desde build/classes
                    imagenFile = new java.io.File("build/classes/Imagenes/" + java.nio.file.Paths.get(rutaImagen).getFileName());
                }
                if (imagenFile.exists()) {
                    ImageIcon imagen = new ImageIcon(imagenFile.getAbsolutePath());
                    fondo = imagen.getImage();
                } else {
                    System.err.println("Imagen no encontrada: " + rutaImagen);
                }
            } catch (Exception e) {
                System.err.println("Error al cargar la imagen: " + e.getMessage());
            }
        }
        
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (fondo != null) {
                g.drawImage(fondo, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }
    
    
    public void aplicarEfecto3D() {
    // Definimos los botones
    JButton[] botones = {boton_Reportes, btn_GestionarClientes, btn_GestionarProductos};

    // Sombra de FlatLaf
    FlatDropShadowBorder sombra = new FlatDropShadowBorder(
        new Color(0, 0, 0, 50), // Color de sombra suave
        new Insets(6, 6, 8, 8),  // Insets/Tamaño de la sombra
        0.3f
    );

    // Padding interno para que el texto NO toque los bordes ni la sombra
    EmptyBorder margenInterno = new EmptyBorder(10, 20, 10, 20);

    for (JButton btn : botones) {
        // 1. Unir la sombra con el margen interno (resuelve que el texto se salga)
        btn.setBorder(new CompoundBorder(sombra, margenInterno));

        // 2. Centrar el texto en el botón (o usar SwingConstants.LEFT si quieres con icono)
        btn.setHorizontalAlignment(SwingConstants.CENTER);

        // 3. Forzar el redondeado de esquinas (Arc)
        btn.putClientProperty("JButton.buttonType", "roundRect");
        btn.putClientProperty("Component.arc", 20); // Grado de curvatura

        // 4. Color de fondo suave y quitar el recuadro de foco al hacer clic
        btn.setBackground(new Color(245, 247, 250));
        btn.setFocusPainted(false);
    }

    this.revalidate();
    this.repaint();
}
    
     private void configurarBotones(JButton boton , Color normal, Color especial){
        
        //Quita el borde cuando le haces click
        boton.setFocusPainted(false);
        //Eliminar el brode 3d
        boton.setBorderPainted(false);
        //Quita el relieve interno
        //boton.setContentAreaFilled(false);
        //Permite pintar el fondo
        boton.setOpaque(true);
        //Pinta el fondo
        boton.setBackground(especial);
        //Pinta el texto
        boton.setForeground(Color.WHITE);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        boton.putClientProperty("JButton.buttonType", "roundRect");

        boton.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseEntered(MouseEvent e) {
            boton.setBackground(especial);
        }

        @Override
        public void mouseExited(MouseEvent e) {
            boton.setBackground(normal);
        }
    });
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btn_GestionarProductos = new javax.swing.JButton();
        btn_GestionarClientes = new javax.swing.JButton();
        boton_Reportes = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(245, 251, 255));

        jLabel1.setBackground(new java.awt.Color(51, 146, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI Semibold", 3, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("INTERFAZ DEL ADMINISTRADOR");
        jLabel1.setOpaque(true);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        btn_GestionarProductos.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_GestionarProductos.setText("Gestionar Producto");

        btn_GestionarClientes.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_GestionarClientes.setText("Gestionar Cliente");

        boton_Reportes.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        boton_Reportes.setText("Ver reportes de ventas");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(63, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(boton_Reportes, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_GestionarClientes, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_GestionarProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(69, 69, 69))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(btn_GestionarProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(btn_GestionarClientes, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(boton_Reportes, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 452, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton boton_Reportes;
    private javax.swing.JButton btn_GestionarClientes;
    private javax.swing.JButton btn_GestionarProductos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
