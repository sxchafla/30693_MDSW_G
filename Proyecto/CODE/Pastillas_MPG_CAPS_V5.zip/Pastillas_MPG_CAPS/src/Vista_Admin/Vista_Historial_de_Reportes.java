
package Vista_Admin;


import Controlador_Admin.Controlador_Historial_de_Reportes;
import GUI.Filtro_Caracteres;
import GUI.Filtro_Numeros;
import GUI.Filtro_ParaFechas;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.text.AbstractDocument;


public class Vista_Historial_de_Reportes extends javax.swing.JFrame {

  
    public Vista_Historial_de_Reportes() {
        initComponents();
        ((AbstractDocument) cajaFecha.getDocument()).setDocumentFilter(new Filtro_ParaFechas());
        ((AbstractDocument) cajaBusquedaNombre.getDocument()).setDocumentFilter(new Filtro_Numeros());
        this.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        this.setLocationRelativeTo(null);
        disenioDetalleCompra();
        configurarBotones(boton_Regresar,new Color(58,186,244), new Color(58,162,244));
        configurarBotones(boton_VerFactura, new Color(46,204,113),new Color(39,174,96));
        new Controlador_Historial_de_Reportes(this);
    }

    public JButton botonDetalle(){
        return boton_VerFactura;
    }
    
    public JTable tablaDetalle(){
        return tablaDetalle;
    }
    
    public JTextField cajaFecha(){
        return cajaFecha;
    }
    
     public JTextField cajaNombre(){
        return cajaBusquedaNombre;
    }
    
    public void getMensaje(String m){
        JOptionPane.showMessageDialog(this, m);
    }
    
     public JButton botonRegresar(){
        return boton_Regresar;
    }
     
     public void disenioDetalleCompra() {
    this.setLocationRelativeTo(null);

    // ========================================================
    // 1. MEJORAR LA TABLA (JTable y JScrollPane)
    // ========================================================
    // Nota: Reemplaza 'tablaDetalle' y 'scrollPaneTabla' con los nombres de tus variables
    
    // Darle más "aire" a las filas aumentando su altura (Padding vertical)
    tablaDetalle.setRowHeight(30);
    
    // Mostrar solo líneas horizontales sutiles (opcional, para un look más limpio)
    tablaDetalle.setShowHorizontalLines(true);
    tablaDetalle.setShowVerticalLines(false);
    tablaDetalle.setGridColor(new java.awt.Color(230, 235, 240));

    // Desactivar el borde cuadrado del JScrollPane
    
    
    // Estilizar el encabezado de la tabla (JTableHeader) con FlatLaf
    tablaDetalle.getTableHeader().putClientProperty("FlatLaf.style", 
        "separatorColor: #E2E8F0; font: bold 12 $sansserif.font;");
    
     // ========================================================
        // COLORES PASTEL PARA LA TABLA
        // ========================================================
        // Fondo general de la tabla (Blanco o un hueso muy suave)
        java.awt.Color fondoTabla = new java.awt.Color(255, 255, 255);

        // Color Pastel para filas alternas (Celeste pastel / Menta suave)
        // Puedes probar con: 
        // - Celeste Pastel: new Color(240, 244, 248)
        // - Verde Menta Pastel: new Color(242, 248, 245)
        java.awt.Color filaPastelAlterna = new java.awt.Color(240, 244, 248); 

        // Color de selección (Cuando haces clic en una fila - Azul pastel más marcado)
        java.awt.Color seleccionPastel = new java.awt.Color(217, 230, 242);
        java.awt.Color textoSeleccion = new java.awt.Color(30, 41, 59); // Gris oscuro para que se lea bien

        // Aplicar los colores a la JTable
        tablaDetalle.setBackground(fondoTabla);
        tablaDetalle.setSelectionBackground(seleccionPastel);
        tablaDetalle.setSelectionForeground(textoSeleccion);

        // Habilitar el renderizado alterno nativo de FlatLaf
        tablaDetalle.putClientProperty("JTable.alternateRowColor", filaPastelAlterna);

        // ========================================================
        // ESTILIZAR EL ENCABEZADO (Header) CON TONO PASTEL
        // ========================================================
        // Un gris/azul pastel sutil para los títulos de las columnas
        java.awt.Color headerPastel = new java.awt.Color(226, 232, 240); 
        java.awt.Color headerTexto = new java.awt.Color(71, 85, 105);

        tablaDetalle.getTableHeader().setBackground(headerPastel);
        tablaDetalle.getTableHeader().setForeground(headerTexto);

        // Ajustes de líneas adicionales para look moderno
        tablaDetalle.setShowHorizontalLines(true);
        tablaDetalle.setShowVerticalLines(false); // Quitar líneas verticales se ve más minimalista
        tablaDetalle.setGridColor(new java.awt.Color(241, 245, 249)); // Línea divisoria muy tenue
     }
     
     private void configurarBotones(JButton boton, Color normal, Color especial) {
        //Quita el borde cuando le haces click
        boton.setFocusPainted(false);
        //Eliminar el brode 3d
        boton.setBorderPainted(false);
        //Quita el relieve interno
       // boton.setContentAreaFilled(false);
        //Permite pintar el fondo
        boton.setOpaque(true);
        //Pinta el fondo
        boton.setBackground(especial);
        //Pinta el texto
        boton.setForeground(Color.WHITE);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(especial);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                boton.setBackground(normal);
            }
        });
      }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jToggleButton1 = new javax.swing.JToggleButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaDetalle = new javax.swing.JTable();
        cajaFecha = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        boton_VerFactura = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        cajaBusquedaNombre = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        boton_Regresar = new javax.swing.JButton();

        jToggleButton1.setText("jToggleButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        tablaDetalle.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "FECHA", "NOMBRES", "CÉDULA", "NÚMERO FACTURA", "TOTAL"
            }
        ));
        jScrollPane1.setViewportView(tablaDetalle);

        jLabel1.setText("Filtrar por fecha");

        boton_VerFactura.setText("Ver Detalles");

        jLabel2.setText("Ingrese el nombre");

        jPanel2.setBackground(new java.awt.Color(242, 38, 77));

        jLabel3.setFont(new java.awt.Font("Mongolian Baiti", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Historial de Compra ");

        boton_Regresar.setText("Regresar");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(boton_Regresar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(244, 244, 244))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(boton_Regresar)
                    .addComponent(jLabel3))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cajaFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cajaBusquedaNombre)
                .addGap(35, 35, 35)
                .addComponent(boton_VerFactura)
                .addGap(34, 34, 34))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 698, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cajaFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(cajaBusquedaNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(boton_VerFactura))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton boton_Regresar;
    private javax.swing.JButton boton_VerFactura;
    private javax.swing.JTextField cajaBusquedaNombre;
    private javax.swing.JTextField cajaFecha;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JTable tablaDetalle;
    // End of variables declaration//GEN-END:variables
}
