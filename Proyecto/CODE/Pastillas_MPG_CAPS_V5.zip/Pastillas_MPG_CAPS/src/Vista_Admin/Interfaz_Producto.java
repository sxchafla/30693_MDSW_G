package Vista_Admin;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JTextField;

public interface Interfaz_Producto {

    // ===== BUSQUEDA =====
    JTextField getNumeroSerieBuscado();

    // ===== DATOS DEL PRODUCTO =====
    String getNumeroSerie();
    String getNombreProducto();
    String getCantidadProducto();
    String getPrecioProducto();

    // ===== UTILIDADES =====
    void getLimpiarProducto();
    void getMensaje(String mensaje);
    int getMensajeConfirmacion(String mensaje);

    // ===== BOTONES =====
    JButton getGuardarProducto();
    JButton getEditarProducto();
    JButton getEliminarProducto();
    JButton getRegresarProducto();
    JButton getEditarImagen();

    // ===== TABLA =====
    JTable getTablaProducto();
}