package Vista_Admin;

import Controlador_Admin.ControladorProducto;
import GUI.Filtro_Letras;
import GUI.Filtro_Caracteres;
import GUI.Filtro_Numeros;
import GUI.Filtro_LetrasPrecios;
import GUI.FiltroCaracteresNumeros;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.text.AbstractDocument;
import javax.swing.JButton;
import java.io.File;
import java.nio.file.Paths;


/**
 *
 * @author User
 */
public class Vista_Producto extends javax.swing.JFrame implements Interfaz_Producto{

    
    public Vista_Producto() {
        initComponents();
        new ControladorProducto(this);
        botonesPersonalizados();
        setLocationRelativeTo(null);
        setResizable(false);
((AbstractDocument) cajaPrecioProducto.getDocument()).setDocumentFilter(new Filtro_LetrasPrecios());
((AbstractDocument) cajaStockProducto.getDocument()).setDocumentFilter(new Filtro_Letras());
((AbstractDocument) cajaNombreProducto.getDocument()).setDocumentFilter(new FiltroCaracteresNumeros());
((AbstractDocument) cajaNumeroSerieBuscado.getDocument()).setDocumentFilter(new Filtro_Caracteres());
        
        
    }
    
    @Override
    public String getNombreProducto(){
        return cajaNombreProducto.getText();
    }
    
   
    
    @Override
    public String getCantidadProducto(){
        return cajaStockProducto.getText();
    }
    
    @Override
    public String getPrecioProducto(){
        return cajaPrecioProducto.getText();
    }
    
    
    @Override
    public JTextField getNumeroSerieBuscado(){
        return cajaNumeroSerieBuscado;
    }
    
    @Override
    public String getNumeroSerie(){
        return cajaNumeroSerieBuscado.getText();
    }
    
    
    @Override
    public void getLimpiarProducto(){
        cajaNumeroSerieBuscado.setText("");
        cajaPrecioProducto.setText("");
        cajaNombreProducto.setText("");
        cajaStockProducto.setText("");
        
        
    }
    
    @Override
   public void getMensaje(String mensaje){
       JOptionPane.showMessageDialog(this, mensaje);
   }
    
    @Override
   public int getMensajeConfirmacion(String m){
       return JOptionPane.showConfirmDialog(this, m, "Elija", JOptionPane.YES_NO_OPTION);
   }
   
    @Override
    public JTable getTablaProducto(){
        return TablaProducto;
    }
    
    
    @Override
    public JButton getGuardarProducto(){
        return boton_GuardarProducto; 
    }
    
   
    
    @Override
    public JButton getEditarProducto(){
        return boton_EditarProducto;
    }
    
    @Override
    public JButton getEditarImagen(){
        return boton_EditarImagen;
    }
    
    @Override
    public JButton getEliminarProducto(){
       return boton_EliminarProducto;
    }
    
    @Override
   public JButton getRegresarProducto(){
       return boton_Regresar;
   }
    
    /**
     * Clase interna para dibujar imagen como fondo
     */
    public static class JPanelConFondo extends javax.swing.JPanel {
        private Image fondo;
        
        public JPanelConFondo(String rutaImagen) {
            try {
                java.io.File imagenFile = new java.io.File(rutaImagen);
                if (!imagenFile.exists()) {
                    // Intentar desde build/classes
                    imagenFile = new java.io.File("build/classes/Imagenes/" + java.nio.file.Paths.get(rutaImagen).getFileName());
                }
                if (imagenFile.exists()) {
                    ImageIcon imagen = new ImageIcon(imagenFile.getAbsolutePath());
                    fondo = imagen.getImage();
                } else {
                    System.err.println("Imagen no encontrada: " + rutaImagen);
                }
            } catch (Exception e) {
                System.err.println("Error al cargar la imagen: " + e.getMessage());
            }
        }
        
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (fondo != null) {
                g.drawImage(fondo, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }
    
    public void botonesPersonalizados(){
    /*configurarBotones(boton_Buscar, 
        new Color(52,152,219), 
        new Color(41,128,185));*/
        
        configurarBotones(boton_EditarProducto, 
        new Color(46,204,113), 
        new Color(39,174,96));
        
        configurarBotones(boton_EliminarProducto, 
        new Color(231,76,60), 
        new Color(192,57,43));
        
        configurarBotones(boton_GuardarProducto, 
        new Color(215,126,10), 
        new Color(12,127,203));
        
        configurarBotones(boton_EditarImagen, 
        new Color(46,204,113), 
        new Color(39,174,96));
        
        
        
    }
    
    private void configurarBotones(JButton boton, Color normal, Color especial){
        
        boton.setFocusPainted(false);
        boton.setBorderPainted(false);
       // boton.setContentAreaFilled(false);
        boton.setOpaque(true);
        boton.setBackground(especial);
        boton.setForeground(Color.WHITE);
        
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        boton.putClientProperty("JButton.buttonType", "roundRect");
        boton.addMouseListener(new MouseAdapter(){
        
            @Override
            public void mouseEntered(MouseEvent e){
                boton.setBackground(especial);
            }
        
            @Override
            public void mouseExited(MouseEvent e){
                boton.setBackground(normal);
            }
        
        });
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaProducto = new javax.swing.JTable();
        boton_EliminarProducto = new javax.swing.JButton();
        boton_EditarProducto = new javax.swing.JButton();
        cajaNumeroSerieBuscado = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        boton_EditarImagen = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        boton_GuardarProducto = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        cajaPrecioProducto = new javax.swing.JTextField();
        cajaStockProducto = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        cajaNombreProducto = new javax.swing.JTextField();
        boton_Regresar = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(242, 245, 252));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Lista Productos"));

        TablaProducto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "N-SERIE", "NOMBRE", "CANTIDAD", "PRECIO UNITARIO", "IMAGEN?"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, true, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TablaProducto.setGridColor(new java.awt.Color(255, 255, 255));
        jScrollPane1.setViewportView(TablaProducto);

        boton_EliminarProducto.setBackground(new java.awt.Color(239, 68, 68));
        boton_EliminarProducto.setForeground(new java.awt.Color(255, 255, 255));
        boton_EliminarProducto.setText("Eliminar");

        boton_EditarProducto.setText("Editar");

        jLabel5.setText("Buscar por N° serie");

        boton_EditarImagen.setText("Editar imagen");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 107, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(boton_EditarImagen, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(boton_EditarProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(boton_EliminarProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(17, 17, 17))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cajaNumeroSerieBuscado, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(161, 161, 161))))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cajaNumeroSerieBuscado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(boton_EliminarProducto)
                    .addComponent(boton_EditarProducto)
                    .addComponent(boton_EditarImagen))
                .addContainerGap())
        );

        jPanel3.setBackground(new java.awt.Color(242, 245, 252));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Registro Productos"));

        boton_GuardarProducto.setText("Guardar");

        jLabel4.setText("Ingrese el precio:");

        cajaPrecioProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cajaPrecioProductoActionPerformed(evt);
            }
        });

        cajaStockProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cajaStockProductoActionPerformed(evt);
            }
        });

        jLabel3.setText("Ingrese el stock:");

        jLabel1.setText("Nombre del producto:");

        boton_Regresar.setBackground(new java.awt.Color(100, 116, 139));
        boton_Regresar.setForeground(new java.awt.Color(255, 255, 255));
        boton_Regresar.setText("Regresar");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(74, 74, 74)
                        .addComponent(cajaStockProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(62, 62, 62)
                        .addComponent(cajaNombreProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(boton_Regresar, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(74, 74, 74)
                                .addComponent(cajaPrecioProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(boton_GuardarProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(42, 42, 42)))))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(cajaNombreProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cajaStockProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cajaPrecioProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(boton_Regresar)
                    .addComponent(boton_GuardarProducto))
                .addGap(85, 85, 85))
        );

        jPanel4.setBackground(new java.awt.Color(214, 91, 14));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 22)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Administrar Productos");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(418, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(330, 330, 330))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel2)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cajaPrecioProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cajaPrecioProductoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cajaPrecioProductoActionPerformed

    private void cajaStockProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cajaStockProductoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cajaStockProductoActionPerformed

  
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaProducto;
    private javax.swing.JButton boton_EditarImagen;
    private javax.swing.JButton boton_EditarProducto;
    private javax.swing.JButton boton_EliminarProducto;
    private javax.swing.JButton boton_GuardarProducto;
    private javax.swing.JButton boton_Regresar;
    private javax.swing.JTextField cajaNombreProducto;
    private javax.swing.JTextField cajaNumeroSerieBuscado;
    private javax.swing.JTextField cajaPrecioProducto;
    private javax.swing.JTextField cajaStockProducto;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
