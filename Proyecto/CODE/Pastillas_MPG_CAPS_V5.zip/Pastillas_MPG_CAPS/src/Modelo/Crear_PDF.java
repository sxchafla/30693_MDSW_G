package Modelo;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import javax.swing.JTable;

public class Crear_PDF {

    public String generarPDF(Factura datos) {

        // Ruta relativa para guardar los PDF en la carpeta del proyecto
        String nombreArchivo = "Factura " + datos.getIdFactura() + ".pdf";
        String rutaDestino = "PDF/" + nombreArchivo;

        BaseColor azulFondo = new BaseColor(247, 122, 21);
        BaseColor blanco = BaseColor.WHITE;

        try {
            // 1. Crear carpeta PDF si no existe
            File carpeta = new File("PDF");
            if (!carpeta.exists()) {
                carpeta.mkdir();
            }

            // Documento en formato horizontal (A4.rotate())
            Document documento = new Document(PageSize.A4.rotate(), 0, 0, 30, 30);
            PdfWriter.getInstance(documento, new FileOutputStream(rutaDestino));

            documento.open();

            // --- 1. ENCABEZADO BANNER ---
            PdfPTable banner = new PdfPTable(2);
            banner.setWidthPercentage(100);
            banner.setWidths(new float[]{60, 40});

            PdfPCell cellTitulo = new PdfPCell(new Phrase("FACTURA", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 32, blanco)));
            cellTitulo.setBackgroundColor(azulFondo);
            cellTitulo.setBorder(Rectangle.NO_BORDER);
            cellTitulo.setPadding(30);
            banner.addCell(cellTitulo);

            PdfPCell cellNum = new PdfPCell(new Phrase("Número: " + datos.getIdFactura(), FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14, blanco)));
            cellNum.setBackgroundColor(azulFondo);
            cellNum.setBorder(Rectangle.NO_BORDER);
            cellNum.setPadding(30);
            cellNum.setHorizontalAlignment(Element.ALIGN_RIGHT);
            cellNum.setVerticalAlignment(Element.ALIGN_BOTTOM);
            banner.addCell(cellNum);

            documento.add(banner);

            // --- 2. DATOS DEL CLIENTE ---
            PdfPTable infoSeccion = new PdfPTable(2);
            infoSeccion.setWidthPercentage(90);
            infoSeccion.setSpacingBefore(20);

            Font fNegrita = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12);
            Font fNormal = FontFactory.getFont(FontFactory.HELVETICA, 11);

            Paragraph p = new Paragraph();
            p.add(new Chunk("Datos del Cliente:\n", fNegrita));
            p.add(new Chunk("Nombre: " + datos.getDatos_cliente().getApellido() + " " + datos.getDatos_cliente().getNombre() + "\n", fNormal));
            p.add(new Chunk("Cédula: " + datos.getDatos_cliente().getCedula() + "\n", fNormal));
            p.add(new Chunk("Correo: " + datos.getDatos_cliente().getCorreoElectronico() + "\n", fNormal));
            p.add(new Chunk("Dirección: " + datos.getDatos_cliente().getDireccion() + "\n", fNormal));

            PdfPCell celdaDatos = new PdfPCell(p);
            celdaDatos.setBorder(Rectangle.NO_BORDER);
            infoSeccion.addCell(celdaDatos);

            // Logo (Opcional)
            try {
                Image logo = Image.getInstance("src/icons/logo.png"); // Cambia la ruta si usas logo
                logo.scaleToFit(100, 100);
                PdfPCell celdaLogo = new PdfPCell(logo);
                celdaLogo.setBorder(Rectangle.NO_BORDER);
                celdaLogo.setHorizontalAlignment(Element.ALIGN_RIGHT);
                infoSeccion.addCell(celdaLogo);
            } catch (Exception e) {
                // Celda vacía si no encuentra la imagen
                infoSeccion.addCell(celdaVacia());
            }
            documento.add(infoSeccion);

            // Fecha
            Paragraph fecha = new Paragraph("Fecha de emisión: " + datos.getLocaldate(), fNormal);
            fecha.setIndentationLeft(30);
            fecha.setSpacingBefore(10);
            documento.add(fecha);

            // --- 3. TABLA DE DETALLE DE PRODUCTOS ---
            PdfPTable tablaProductos = new PdfPTable(4);
            tablaProductos.setWidthPercentage(90);
            tablaProductos.setSpacingBefore(15);
            tablaProductos.setSpacingAfter(10);
            tablaProductos.setWidths(new float[]{45, 15, 20, 20});

            // Encabezados de la tabla
            String[] encabezados = {"Producto / Descripción", "Cantidad", "Precio Unitario", "Subtotal"};
            Font fEncabezado = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 11, blanco);

            for (String tituloCol : encabezados) {
                PdfPCell cellHeader = new PdfPCell(new Phrase(tituloCol, fEncabezado));
                cellHeader.setBackgroundColor(azulFondo);
                cellHeader.setPadding(8);
                cellHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
                tablaProductos.addCell(cellHeader);
            }

            // Recorrer el ArrayList 'detalle' de la Factura
            for (DetalleFactura d : datos.getDetalle()) {
                
                // Columna 1: Nombre / Producto (Asegúrate que el getter coincida con DetalleFactura)
                PdfPCell cellNombre = new PdfPCell(new Phrase(d.getNombreProducto(), fNormal));
                cellNombre.setPadding(6);
                tablaProductos.addCell(cellNombre);

                // Columna 2: Cantidad
                PdfPCell cellCantidad = new PdfPCell(new Phrase(String.valueOf(d.getCantidad()), fNormal));
                cellCantidad.setHorizontalAlignment(Element.ALIGN_CENTER);
                cellCantidad.setPadding(6);
                tablaProductos.addCell(cellCantidad);

                // Columna 3: Precio Unitario
                PdfPCell cellPrecio = new PdfPCell(new Phrase("$ " + String.format("%.2f", d.getPrecioUnitario()), fNormal));
                cellPrecio.setHorizontalAlignment(Element.ALIGN_RIGHT);
                cellPrecio.setPadding(6);
                tablaProductos.addCell(cellPrecio);

                // Columna 4: Subtotal por ítem
                double subtotalItem = d.getCantidad() * d.getPrecioUnitario();
                PdfPCell cellSubtotalItem = new PdfPCell(new Phrase("$ " + String.format("%.2f", subtotalItem), fNormal));
                cellSubtotalItem.setHorizontalAlignment(Element.ALIGN_RIGHT);
                cellSubtotalItem.setPadding(6);
                tablaProductos.addCell(cellSubtotalItem);
            }

            documento.add(tablaProductos);

            // --- 4. SECCIÓN DE TOTALES ---
            PdfPTable tablaTotales = new PdfPTable(2);
            tablaTotales.setWidthPercentage(90);
            tablaTotales.setWidths(new float[]{70, 30});
            tablaTotales.setSpacingBefore(5);

            // Subtotal
            PdfPCell cSub = new PdfPCell(new Phrase("Subtotal:  $ " + String.format("%.2f", datos.calcularSubtotal()), fNormal));
            cSub.setHorizontalAlignment(Element.ALIGN_RIGHT);
            cSub.setBorder(Rectangle.NO_BORDER);
            tablaTotales.addCell(celdaVacia());
            tablaTotales.addCell(cSub);

            // IVA 15%
            PdfPCell cIva = new PdfPCell(new Phrase("IVA (15%):  $ " + String.format("%.2f", datos.subTotalIva()), fNormal));
            cIva.setHorizontalAlignment(Element.ALIGN_RIGHT);
            cIva.setBorder(Rectangle.NO_BORDER);
            tablaTotales.addCell(celdaVacia());
            tablaTotales.addCell(cIva);

            // Total Final
            PdfPCell cTotal = new PdfPCell(new Phrase("TOTAL:  $ " + String.format("%.2f", datos.precioTotal()), 
                    FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, blanco)));
            cTotal.setBackgroundColor(azulFondo);
            cTotal.setHorizontalAlignment(Element.ALIGN_RIGHT);
            cTotal.setPadding(6);

            tablaTotales.addCell(celdaVacia());
            tablaTotales.addCell(cTotal);

            documento.add(tablaTotales);

            // Mensaje final
            Paragraph fin = new Paragraph("\n\n¡Gracias por su compra!", fNegrita);
            fin.setAlignment(Element.ALIGN_CENTER);
            documento.add(fin);

            documento.close();
            System.out.println("PDF generado exitosamente en: " + rutaDestino);

            return rutaDestino;

        } catch (DocumentException | FileNotFoundException e) {
            System.err.println("Error de archivo o iText: " + e.getMessage());
            return null;
        } catch (Exception e) {
            System.err.println("Error general al crear PDF: " + e.getMessage());
            return null;
        }
    }

    // --- MÉTODOS AUXILIARES ---
    private PdfPCell celdaVacia() {
        PdfPCell c = new PdfPCell(new Phrase(""));
        c.setBorder(Rectangle.NO_BORDER);
        return c;
    }
}