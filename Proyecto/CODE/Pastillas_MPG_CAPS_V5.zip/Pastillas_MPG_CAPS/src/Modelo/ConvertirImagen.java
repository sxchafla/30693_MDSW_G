
package Modelo;

import java.awt.Image;
import java.io.File;
import java.nio.file.Files;
import java.util.Base64;
import javax.swing.ImageIcon;


public class ConvertirImagen {
    
    // 1. Convierte el archivo seleccionado por el JFileChooser a String Base64
    public static String convertirABase64(File archivo) {
        try {
            byte[] fileContent = Files.readAllBytes(archivo.toPath());
            return Base64.getEncoder().encodeToString(fileContent);
        } catch (Exception e) {
            System.err.println("Error al convertir imagen a Base64: " + e.getMessage());
            return ""; // Retorna vacío si no se pudo
        }
    }

    // 2. Convierte el String Base64 de Mongo Atlas a un ImageIcon escalado para tu JLabel
    public static ImageIcon decodificarAIcono(String base64, int ancho, int alto) {
        try {
            if (base64 == null || base64.isEmpty()) return null;
            byte[] imageBytes = Base64.getDecoder().decode(base64);
            Image img = java.awt.Toolkit.getDefaultToolkit().createImage(imageBytes);
            ImageIcon icono = new ImageIcon(img);
            // Escalar la imagen para que encaje perfecto en el JLabel de la tarjeta
            Image escalada = icono.getImage().getScaledInstance(ancho, alto, Image.SCALE_FAST);
            return new ImageIcon(escalada);
        } catch (Exception e) {
            System.err.println("Error al decodificar Base64: " + e.getMessage());
            return null;
        }
    }
}
