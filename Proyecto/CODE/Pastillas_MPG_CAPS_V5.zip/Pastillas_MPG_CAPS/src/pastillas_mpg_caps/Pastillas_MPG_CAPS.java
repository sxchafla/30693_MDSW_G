
package pastillas_mpg_caps;
import Vista_Login.Vista_Login;

public class Pastillas_MPG_CAPS {

    
    public static void main(String[] args) {
        
        
        // 1. Activar el tema de FlatLaf (Claro)
        com.formdev.flatlaf.FlatLightLaf.setup();

        // Si prefieres tema oscuro, usa esta línea en su lugar:
        // com.formdev.flatlaf.FlatDarkLaf.setup();

        // 2. Aquí va tu código habitual para abrir la ventana
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                Vista_Login login = new Vista_Login();
                login.setVisible(true);
            }
        });
    }
    
}
